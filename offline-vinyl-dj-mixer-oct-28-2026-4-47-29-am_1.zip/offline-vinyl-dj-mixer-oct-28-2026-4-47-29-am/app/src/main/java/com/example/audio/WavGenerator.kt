package com.example.audio

import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.sin

object WavGenerator {

  enum class SampleType {
    AIRHORN,
    KICK,
    SNARE,
    HIHAT,
    SCRATCH,
    LASER,
    SUB_DROP,
    SIREN,
    SCRATCH_FORWARD,
    SCRATCH_BACKWARD,
    VINYL_BRAKE
  }

  fun writeWavHeader(out: FileOutputStream, totalAudioLen: Long, sampleRate: Int = 44100, channels: Int = 2) {
    val totalDataLen = totalAudioLen + 36
    val byteRate = sampleRate * channels * 2

    val header = ByteArray(44)
    val bb = ByteBuffer.wrap(header).order(ByteOrder.LITTLE_ENDIAN)

    // RIFF/WAVE header
    header[0] = 'R'.code.toByte()
    header[1] = 'I'.code.toByte()
    header[2] = 'F'.code.toByte()
    header[3] = 'F'.code.toByte()
    bb.putInt(4, totalDataLen.toInt())
    header[8] = 'W'.code.toByte()
    header[9] = 'A'.code.toByte()
    header[10] = 'V'.code.toByte()
    header[11] = 'E'.code.toByte()

    // 'fmt ' chunk
    header[12] = 'f'.code.toByte()
    header[13] = 'm'.code.toByte()
    header[14] = 't'.code.toByte()
    header[15] = ' '.code.toByte()
    bb.putInt(16, 16) // Subchunk1Size for PCM
    bb.putShort(20, 1.toShort()) // AudioFormat 1 = PCM
    bb.putShort(22, channels.toShort())
    bb.putInt(24, sampleRate)
    bb.putInt(28, byteRate)
    bb.putShort(32, (channels * 2).toShort()) // BlockAlign
    bb.putShort(34, 16.toShort()) // BitsPerSample

    // 'data' chunk
    header[36] = 'd'.code.toByte()
    header[37] = 'a'.code.toByte()
    header[38] = 't'.code.toByte()
    header[39] = 'a'.code.toByte()
    bb.putInt(40, totalAudioLen.toInt())

    out.write(header, 0, 44)
  }

  fun generateDemoTrackA(file: File, bpm: Double = 125.0, bars: Int = 16) {
    if (file.exists() && file.length() > 1000) return

    val sampleRate = 44100
    val beatDuration = 60.0 / bpm
    val barDuration = beatDuration * 4.0
    val totalDuration = barDuration * bars
    val totalSamples = (totalDuration * sampleRate).toInt()
    val totalAudioBytes = totalSamples * 2 * 2L // 16-bit stereo

    FileOutputStream(file).use { fos ->
      writeWavHeader(fos, totalAudioBytes, sampleRate, 2)
      val buffer = ByteArray(4096)
      var bufIdx = 0

      val twoPi = 2.0 * PI

      for (i in 0 until totalSamples) {
        val t = i.toDouble() / sampleRate
        val beatTime = (t % beatDuration) / beatDuration
        val barTime = (t % barDuration) / barDuration
        val currentBeat = ((t / beatDuration) % 4).toInt()

        var left = 0.0
        var right = 0.0

        // 1. Kick Drum on every beat (4-on-the-floor)
        val kickT = t % beatDuration
        if (kickT < 0.28) {
          val kickFreq = 140.0 * exp(-kickT * 28.0) + 42.0
          val kickEnv = exp(-kickT * 12.0)
          val kickVal = sin(twoPi * kickFreq * kickT) * kickEnv * 0.75
          left += kickVal
          right += kickVal
        }

        // 2. Offbeat Hi-Hat (on half-beat e.g. 0.5)
        val hatT = (t + beatDuration * 0.5) % beatDuration
        if (hatT < 0.09) {
          val noise = ((i * 1103515245 + 12345) and 0x7FFF).toDouble() / 0x7FFF * 2.0 - 1.0
          val hatEnv = exp(-hatT * 45.0)
          val hatVal = noise * hatEnv * 0.22
          left += hatVal * 0.8
          right += hatVal * 1.2
        }

        // 3. Synth Bassline (16th notes with groovy pentatonic root)
        val sixteenthT = (t % (beatDuration / 4.0)) / (beatDuration / 4.0)
        val sixteenthIndex = ((t / (beatDuration / 4.0)) % 16).toInt()
        val bassFreq = when (sixteenthIndex) {
          0, 3, 6, 8, 11, 14 -> 65.41 // C2
          1, 7, 12 -> 77.78 // Eb2
          4, 10 -> 87.31 // F2
          else -> 65.41
        }
        val noteTime = (t % (beatDuration / 4.0))
        if (noteTime < 0.2) {
          val bassEnv = exp(-noteTime * 14.0)
          val bassWave = sin(twoPi * bassFreq * t) + 0.5 * sin(twoPi * bassFreq * 2.0 * t)
          val bassVal = bassWave * bassEnv * 0.35
          left += bassVal
          right += bassVal
        }

        // 4. Stereo Chord Stabs on beats 2 and 4
        if ((currentBeat == 1 || currentBeat == 3) && beatTime < 0.22) {
          val chordEnv = exp(-beatTime * 10.0)
          val cVal = (sin(twoPi * 261.63 * t) + sin(twoPi * 329.63 * t) + sin(twoPi * 392.00 * t)) * 0.12 * chordEnv
          left += cVal * 1.1
          right += cVal * 0.9
        }

        // Clamp to 16-bit signed integer
        val leftSample = (left.coerceIn(-1.0, 1.0) * 32760.0).toInt().toShort()
        val rightSample = (right.coerceIn(-1.0, 1.0) * 32760.0).toInt().toShort()

        buffer[bufIdx++] = (leftSample.toInt() and 0xFF).toByte()
        buffer[bufIdx++] = ((leftSample.toInt() shr 8) and 0xFF).toByte()
        buffer[bufIdx++] = (rightSample.toInt() and 0xFF).toByte()
        buffer[bufIdx++] = ((rightSample.toInt() shr 8) and 0xFF).toByte()

        if (bufIdx >= buffer.size) {
          fos.write(buffer, 0, bufIdx)
          bufIdx = 0
        }
      }
      if (bufIdx > 0) {
        fos.write(buffer, 0, bufIdx)
      }
    }
  }

  fun generateDemoTrackB(file: File, bpm: Double = 125.0, bars: Int = 16) {
    if (file.exists() && file.length() > 1000) return

    val sampleRate = 44100
    val beatDuration = 60.0 / bpm
    val barDuration = beatDuration * 4.0
    val totalDuration = barDuration * bars
    val totalSamples = (totalDuration * sampleRate).toInt()
    val totalAudioBytes = totalSamples * 2 * 2L

    FileOutputStream(file).use { fos ->
      writeWavHeader(fos, totalAudioBytes, sampleRate, 2)
      val buffer = ByteArray(4096)
      var bufIdx = 0
      val twoPi = 2.0 * PI

      for (i in 0 until totalSamples) {
        val t = i.toDouble() / sampleRate
        val beatTime = (t % beatDuration) / beatDuration
        val currentBeat = ((t / beatDuration) % 4).toInt()

        var left = 0.0
        var right = 0.0

        // 1. Tech Kick on 1 and 3
        val kickT = t % (beatDuration * 2.0)
        if (kickT < 0.25) {
          val kickFreq = 160.0 * exp(-kickT * 32.0) + 48.0
          val kickEnv = exp(-kickT * 14.0)
          val kickVal = sin(twoPi * kickFreq * kickT) * kickEnv * 0.78
          left += kickVal
          right += kickVal
        }

        // 2. Snappy Clap / Snare on 2 and 4
        if ((currentBeat == 1 || currentBeat == 3) && beatTime < 0.18) {
          val noise = ((i * 1664525 + 1013904223) and 0x7FFF).toDouble() / 0x7FFF * 2.0 - 1.0
          val clapEnv = exp(-beatTime * 22.0)
          val clapVal = noise * clapEnv * 0.32
          left += clapVal * 0.95
          right += clapVal * 1.05
        }

        // 3. Shaker 16th notes
        val sixteenthT = (t % (beatDuration / 4.0)) / (beatDuration / 4.0)
        val sTime = t % (beatDuration / 4.0)
        if (sTime < 0.05) {
          val noise = ((i * 22695477 + 1) and 0x7FFF).toDouble() / 0x7FFF * 2.0 - 1.0
          val sVal = noise * exp(-sTime * 60.0) * 0.14
          left += sVal
          right += sVal
        }

        // 4. Acid Synth Lead / Arpeggiator
        val arpStep = ((t / (beatDuration / 2.0)) % 8).toInt()
        val arpFreq = when (arpStep) {
          0 -> 196.00 // G3
          1 -> 220.00 // A3
          2 -> 261.63 // C4
          3 -> 293.66 // D4
          4 -> 329.63 // E4
          5 -> 392.00 // G4
          6 -> 329.63 // E4
          else -> 293.66 // D4
        }
        val noteT = t % (beatDuration / 2.0)
        if (noteT < 0.22) {
          val env = exp(-noteT * 11.0)
          val synthVal = (sin(twoPi * arpFreq * t) + 0.4 * sin(twoPi * arpFreq * 2.0 * t)) * env * 0.26
          left += synthVal * (0.8 + 0.4 * sin(twoPi * 0.5 * t))
          right += synthVal * (0.8 - 0.4 * sin(twoPi * 0.5 * t))
        }

        val leftSample = (left.coerceIn(-1.0, 1.0) * 32760.0).toInt().toShort()
        val rightSample = (right.coerceIn(-1.0, 1.0) * 32760.0).toInt().toShort()

        buffer[bufIdx++] = (leftSample.toInt() and 0xFF).toByte()
        buffer[bufIdx++] = ((leftSample.toInt() shr 8) and 0xFF).toByte()
        buffer[bufIdx++] = (rightSample.toInt() and 0xFF).toByte()
        buffer[bufIdx++] = ((rightSample.toInt() shr 8) and 0xFF).toByte()

        if (bufIdx >= buffer.size) {
          fos.write(buffer, 0, bufIdx)
          bufIdx = 0
        }
      }
      if (bufIdx > 0) {
        fos.write(buffer, 0, bufIdx)
      }
    }
  }

  fun generateSample(file: File, type: SampleType) {
    if (file.exists() && file.length() > 500) return

    val sampleRate = 44100
    val duration = when (type) {
      SampleType.AIRHORN -> 1.1
      SampleType.KICK -> 0.4
      SampleType.SNARE -> 0.35
      SampleType.HIHAT -> 0.15
      SampleType.SCRATCH -> 0.3
      SampleType.LASER -> 0.6
      SampleType.SUB_DROP -> 1.4
      SampleType.SIREN -> 1.2
      SampleType.SCRATCH_FORWARD -> 0.22
      SampleType.SCRATCH_BACKWARD -> 0.28
      SampleType.VINYL_BRAKE -> 0.45
    }
    val totalSamples = (duration * sampleRate).toInt()
    val totalAudioBytes = totalSamples * 2 * 2L
    val twoPi = 2.0 * PI

    FileOutputStream(file).use { fos ->
      writeWavHeader(fos, totalAudioBytes, sampleRate, 2)
      val buffer = ByteArray(4096)
      var bufIdx = 0

      for (i in 0 until totalSamples) {
        val t = i.toDouble() / sampleRate
        var signal = 0.0

        when (type) {
          SampleType.AIRHORN -> {
            // Reggae / DJ Airhorn blast: multiple rich trumpet-like brass harmonics
            val baseFreq = 466.16 // Bb4
            val hornEnv = if (t < 0.04) t / 0.04 else exp(-(t - 0.04) * 2.2)
            val flutter = 1.0 + 0.03 * sin(twoPi * 38.0 * t)
            signal = (sin(twoPi * baseFreq * flutter * t) +
                0.7 * sin(twoPi * baseFreq * 1.5 * flutter * t) +
                0.5 * sin(twoPi * baseFreq * 2.0 * flutter * t) +
                0.3 * sin(twoPi * baseFreq * 2.5 * flutter * t)) * hornEnv * 0.45
          }
          SampleType.KICK -> {
            val freq = 180.0 * exp(-t * 36.0) + 40.0
            val env = exp(-t * 12.0)
            signal = sin(twoPi * freq * t) * env * 0.95
          }
          SampleType.SNARE -> {
            val tone = sin(twoPi * (220.0 * exp(-t * 28.0)) * t) * exp(-t * 18.0) * 0.5
            val noise = (((i * 1103515245 + 12345) and 0x7FFF).toDouble() / 0x7FFF * 2.0 - 1.0) * exp(-t * 14.0) * 0.6
            signal = (tone + noise) * 0.8
          }
          SampleType.HIHAT -> {
            val noise = (((i * 1664525 + 1013904223) and 0x7FFF).toDouble() / 0x7FFF * 2.0 - 1.0)
            signal = noise * exp(-t * 40.0) * 0.45
          }
          SampleType.SCRATCH -> {
            // Vinyl scratch chirp: pitch ramps up and down rapidly
            val sweepFreq = 300.0 + 900.0 * sin(PI * (t / duration))
            val scratchEnv = sin(PI * (t / duration))
            signal = sin(twoPi * sweepFreq * t) * scratchEnv * 0.85
          }
          SampleType.SCRATCH_FORWARD -> {
            // Forward baby scratch: quick upward chirp with needle contact transient
            val p = (t / duration).coerceIn(0.0, 1.0)
            val freq = 380.0 + 1300.0 * (p * p)
            val env = sin(PI * p) * (1.0 - 0.2 * p)
            val friction = (((i * 1664525 + 1013904223) and 0x7FFF).toDouble() / 0x7FFF * 2.0 - 1.0) * 0.25
            signal = (sin(twoPi * freq * t) + friction) * env * 0.9
          }
          SampleType.SCRATCH_BACKWARD -> {
            // Backward pull tear: deep dragging tear with gritty vinyl crackle
            val p = (t / duration).coerceIn(0.0, 1.0)
            val freq = 1200.0 * (1.0 - p * 0.75) + 80.0
            val env = sin(PI * p)
            val crackle = if ((i % 170) == 0) 0.6 else 0.0
            val friction = (((i * 1103515245 + 12345) and 0x7FFF).toDouble() / 0x7FFF * 2.0 - 1.0) * 0.35
            signal = (sin(twoPi * freq * t) + friction + crackle) * env * 0.92
          }
          SampleType.VINYL_BRAKE -> {
            // Technics 1200 motor spin-down: deceleration pitch drop from 1.0 to 0.05
            val p = (t / duration).coerceIn(0.0, 1.0)
            val decel = (1.0 - p) * (1.0 - p)
            val motorFreq = (140.0 * decel) + 20.0
            val rumble = sin(twoPi * 55.0 * t) * decel * 0.3
            val motor = (sin(twoPi * motorFreq * t) + rumble) * decel * 0.7
            signal = motor
          }
          SampleType.LASER -> {
            // Retro synth arcade laser zap
            val laserFreq = 1600.0 * exp(-t * 12.0) + 120.0
            signal = sin(twoPi * laserFreq * t) * exp(-t * 4.0) * 0.7
          }
          SampleType.SUB_DROP -> {
            // 808 Sub Boom downward pitch sweep
            val subFreq = 120.0 * exp(-t * 2.8) + 28.0
            val subEnv = exp(-t * 1.5)
            signal = sin(twoPi * subFreq * t) * subEnv * 0.95
          }
          SampleType.SIREN -> {
            // Dancehall Dub Siren: modulated LFO pitch
            val sirenFreq = 650.0 + 350.0 * sin(twoPi * 5.0 * t)
            signal = (sin(twoPi * sirenFreq * t) + 0.3 * sin(twoPi * sirenFreq * 2.0 * t)) * exp(-t * 1.8) * 0.6
          }
        }

        val sampleVal = (signal.coerceIn(-1.0, 1.0) * 32760.0).toInt().toShort()

        buffer[bufIdx++] = (sampleVal.toInt() and 0xFF).toByte()
        buffer[bufIdx++] = ((sampleVal.toInt() shr 8) and 0xFF).toByte()
        buffer[bufIdx++] = (sampleVal.toInt() and 0xFF).toByte()
        buffer[bufIdx++] = ((sampleVal.toInt() shr 8) and 0xFF).toByte()

        if (bufIdx >= buffer.size) {
          fos.write(buffer, 0, bufIdx)
          bufIdx = 0
        }
      }
      if (bufIdx > 0) {
        fos.write(buffer, 0, bufIdx)
      }
    }
  }
}
