package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DeckId
import com.example.model.SideTab
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPink
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite

@Composable
fun SideNavTabs(
  deckId: DeckId,
  activeTab: SideTab,
  customAccentColor: Color? = null,
  onTabClick: (SideTab) -> Unit,
  modifier: Modifier = Modifier
) {
  val isDeckA = deckId == DeckId.DECK_A
  val accentColor = customAccentColor ?: (if (isDeckA) NeonCyan else NeonPink)
  val prefix = if (isDeckA) "deck_a_" else "deck_b_"

  val tabs = listOf(
    Pair(SideTab.FX, "FX"),
    Pair(SideTab.LOOP, "LOOP"),
    Pair(SideTab.EQ, "EQ"),
    Pair(SideTab.HOT_CUES, "HOT\nCUES")
  )

  Column(
    modifier = modifier
      .width(42.dp)
      .fillMaxHeight()
      .padding(vertical = 4.dp),
    verticalArrangement = Arrangement.SpaceEvenly,
    horizontalAlignment = Alignment.CenterHorizontally
  ) {
    tabs.forEach { (tab, label) ->
      val isActive = activeTab == tab
      Box(
        modifier = Modifier
          .weight(1f)
          .width(38.dp)
          .padding(vertical = 2.dp)
          .clip(RoundedCornerShape(6.dp))
          .background(
            if (isActive) accentColor.copy(alpha = 0.22f)
            else Color(0xFF141720)
          )
          .border(
            width = if (isActive) 1.5.dp else 1.dp,
            color = if (isActive) accentColor else Color(0xFF262C3A),
            shape = RoundedCornerShape(6.dp)
          )
          .clickable { onTabClick(tab) }
          .testTag("${prefix}tab_${tab.name.lowercase()}"),
        contentAlignment = Alignment.Center
      ) {
        Text(
          text = label,
          color = if (isActive) accentColor else TextMuted,
          fontSize = if (label.contains("\n")) 8.5.sp else 10.sp,
          fontWeight = if (isActive) FontWeight.ExtraBold else FontWeight.Bold,
          fontFamily = FontFamily.Monospace,
          lineHeight = 10.sp,
          textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
      }
    }
  }
}
