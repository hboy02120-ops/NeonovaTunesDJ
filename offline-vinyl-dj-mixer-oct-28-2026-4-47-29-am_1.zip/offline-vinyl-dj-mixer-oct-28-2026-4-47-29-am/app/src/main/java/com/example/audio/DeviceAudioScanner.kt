package com.example.audio

import android.content.ContentUris
import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.Locale

data class ScannedAudioTrack(
  val id: String,
  val title: String,
  val artist: String,
  val durationMs: Int,
  val bpm: Double = 125.0,
  val uri: Uri,
  val filePath: String? = null,
  val folderName: String = "Device Storage",
  val fileExtension: String = "MP3",
  val sizeBytes: Long = 0L,
  val fileSizeFormatted: String = "",
  val isImported: Boolean = false,
  val isBuiltIn: Boolean = false,
  val isRecording: Boolean = false
)

object DeviceAudioScanner {

  private const val TAG = "DeviceAudioScanner"

  private val SUPPORTED_EXTENSIONS = setOf(
    "mp3", "wav", "m4a", "aac", "flac", "ogg", "opus", "wma", "mid"
  )

  /**
   * Scans all audio sources on the phone:
   * 1. MediaStore Audio (external and internal)
   * 2. MediaStore Files (with audio MIME type or audio extensions)
   * 3. Direct file scan of public directories (/Music, /Download, /Audio, etc.)
   * 4. Internal app cache of previously imported songs (/files/imported_music)
   */
  fun scanAllAudio(context: Context): List<ScannedAudioTrack> {
    val resultsMap = LinkedHashMap<String, ScannedAudioTrack>()

    // 1. App's persistent imported music folder
    scanAppImportedFolder(context, resultsMap)

    // 2. MediaStore Audio Query (EXTERNAL_CONTENT_URI)
    scanMediaStoreAudio(context, MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, resultsMap)

    // 3. MediaStore Audio Query (INTERNAL_CONTENT_URI)
    try {
      scanMediaStoreAudio(context, MediaStore.Audio.Media.INTERNAL_CONTENT_URI, resultsMap)
    } catch (e: Exception) {
      Log.w(TAG, "Internal MediaStore not accessible: ${e.message}")
    }

    // 4. MediaStore Files Query (Finds un-indexed audio files)
    scanMediaStoreFiles(context, resultsMap)

    // 5. Direct Directory Scanning (Bypasses MediaStore indexer delays)
    scanDirectStorageDirectories(context, resultsMap)

    return resultsMap.values.toList().sortedBy { it.title.lowercase(Locale.ROOT) }
  }

  private fun scanAppImportedFolder(context: Context, outMap: LinkedHashMap<String, ScannedAudioTrack>) {
    try {
      val importedDir = File(context.filesDir, "imported_music").apply { mkdirs() }
      importedDir.listFiles()?.forEach { file ->
        if (file.isFile && SUPPORTED_EXTENSIONS.contains(file.extension.lowercase(Locale.ROOT))) {
          val track = extractTrackFromFile(file, isImported = true)
          outMap[file.absolutePath] = track
        }
      }
    } catch (e: Exception) {
      Log.e(TAG, "Error scanning imported folder", e)
    }
  }

  private fun scanMediaStoreAudio(
    context: Context,
    contentUri: Uri,
    outMap: LinkedHashMap<String, ScannedAudioTrack>
  ) {
    try {
      val projection = arrayOf(
        MediaStore.Audio.Media._ID,
        MediaStore.Audio.Media.TITLE,
        MediaStore.Audio.Media.ARTIST,
        MediaStore.Audio.Media.DURATION,
        MediaStore.Audio.Media.DATA,
        MediaStore.Audio.Media.DISPLAY_NAME,
        MediaStore.Audio.Media.SIZE,
        MediaStore.Audio.Media.IS_NOTIFICATION,
        MediaStore.Audio.Media.IS_RINGTONE,
        MediaStore.Audio.Media.IS_ALARM
      )

      context.contentResolver.query(
        contentUri,
        projection,
        null,
        null,
        "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
      )?.use { cursor ->
        val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
        val titleCol = cursor.getColumnIndex(MediaStore.Audio.Media.TITLE)
        val artistCol = cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST)
        val durationCol = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION)
        val dataCol = cursor.getColumnIndex(MediaStore.Audio.Media.DATA)
        val displayCol = cursor.getColumnIndex(MediaStore.Audio.Media.DISPLAY_NAME)
        val sizeCol = cursor.getColumnIndex(MediaStore.Audio.Media.SIZE)
        val notifCol = cursor.getColumnIndex(MediaStore.Audio.Media.IS_NOTIFICATION)
        val ringCol = cursor.getColumnIndex(MediaStore.Audio.Media.IS_RINGTONE)
        val alarmCol = cursor.getColumnIndex(MediaStore.Audio.Media.IS_ALARM)

        while (cursor.moveToNext()) {
          val isNotification = if (notifCol >= 0) cursor.getInt(notifCol) != 0 else false
          val isRingtone = if (ringCol >= 0) cursor.getInt(ringCol) != 0 else false
          val isAlarm = if (alarmCol >= 0) cursor.getInt(alarmCol) != 0 else false

          val rawData = if (dataCol >= 0) cursor.getString(dataCol) else null

          // Skip system ringtones, alarms, and notifications
          if (isNotification || isRingtone || isAlarm) continue
          if (rawData != null && isSystemChimePath(rawData)) continue

          val id = cursor.getLong(idCol)
          val uri = ContentUris.withAppendedId(contentUri, id)

          val displayName = if (displayCol >= 0) cursor.getString(displayCol) else null
          val title = if (titleCol >= 0) cursor.getString(titleCol) else null
          val artist = if (artistCol >= 0) cursor.getString(artistCol) else null
          val dur = if (durationCol >= 0) cursor.getInt(durationCol) else 0
          val sizeBytes = if (sizeCol >= 0) cursor.getLong(sizeCol) else 0L

          val cleanTitle = when {
            !title.isNullOrBlank() -> title
            !displayName.isNullOrBlank() -> displayName.substringBeforeLast(".")
            !rawData.isNullOrBlank() -> File(rawData).nameWithoutExtension
            else -> "Audio Track $id"
          }

          val cleanArtist = if (!artist.isNullOrBlank() && artist != "<unknown>") artist else "Device Storage"

          val ext = displayName?.substringAfterLast(".", "")
            ?: rawData?.substringAfterLast(".", "")
            ?: "MP3"

          val folder = if (!rawData.isNullOrBlank()) {
            File(rawData).parentFile?.name ?: "Storage"
          } else "Device Music"

          val sizeFormatted = formatFileSize(sizeBytes)

          val key = rawData ?: uri.toString()
          if (!outMap.containsKey(key)) {
            outMap[key] = ScannedAudioTrack(
              id = id.toString(),
              title = cleanTitle,
              artist = cleanArtist,
              durationMs = if (dur > 0) dur else 180000,
              uri = uri,
              filePath = rawData,
              folderName = folder,
              fileExtension = ext.uppercase(Locale.ROOT),
              sizeBytes = sizeBytes,
              fileSizeFormatted = sizeFormatted
            )
          }
        }
      }
    } catch (e: Exception) {
      Log.w(TAG, "Error in scanMediaStoreAudio: ${e.message}")
    }
  }

  private fun isSystemChimePath(path: String): Boolean {
    val lower = path.lowercase(Locale.ROOT)
    return lower.contains("/notifications/") ||
        lower.contains("/ringtones/") ||
        lower.contains("/alarms/") ||
        lower.contains("/system/media/audio") ||
        lower.contains("android/media/com.google.android.talk") ||
        lower.contains("whatsapp/media/.statuses")
  }

  private fun scanMediaStoreFiles(context: Context, outMap: LinkedHashMap<String, ScannedAudioTrack>) {
    try {
      val filesUri = MediaStore.Files.getContentUri("external")
      val projection = arrayOf(
        MediaStore.Files.FileColumns._ID,
        MediaStore.Files.FileColumns.TITLE,
        MediaStore.Files.FileColumns.DATA,
        MediaStore.Files.FileColumns.DISPLAY_NAME,
        MediaStore.Files.FileColumns.SIZE,
        MediaStore.Files.FileColumns.MIME_TYPE
      )

      val selection = "${MediaStore.Files.FileColumns.MIME_TYPE} LIKE 'audio/%' " +
          "OR ${MediaStore.Files.FileColumns.DATA} LIKE '%.mp3' " +
          "OR ${MediaStore.Files.FileColumns.DATA} LIKE '%.wav' " +
          "OR ${MediaStore.Files.FileColumns.DATA} LIKE '%.m4a'"

      context.contentResolver.query(filesUri, projection, selection, null, null)?.use { cursor ->
        val idCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns._ID)
        val dataCol = cursor.getColumnIndex(MediaStore.Files.FileColumns.DATA)
        val nameCol = cursor.getColumnIndex(MediaStore.Files.FileColumns.DISPLAY_NAME)
        val titleCol = cursor.getColumnIndex(MediaStore.Files.FileColumns.TITLE)
        val sizeCol = cursor.getColumnIndex(MediaStore.Files.FileColumns.SIZE)

        while (cursor.moveToNext()) {
          val id = cursor.getLong(idCol)
          val rawData = if (dataCol >= 0) cursor.getString(dataCol) else null

          if (rawData != null && isSystemChimePath(rawData)) continue

          val key = rawData ?: "file_$id"

          if (!outMap.containsKey(key)) {
            val displayName = if (nameCol >= 0) cursor.getString(nameCol) else null
            val title = if (titleCol >= 0) cursor.getString(titleCol) else null
            val size = if (sizeCol >= 0) cursor.getLong(sizeCol) else 0L

            val cleanTitle = when {
              !title.isNullOrBlank() -> title
              !displayName.isNullOrBlank() -> displayName.substringBeforeLast(".")
              !rawData.isNullOrBlank() -> File(rawData).nameWithoutExtension
              else -> "Track $id"
            }

            val uri = ContentUris.withAppendedId(filesUri, id)
            val ext = rawData?.substringAfterLast(".", "MP3") ?: "MP3"
            val folder = if (!rawData.isNullOrBlank()) File(rawData).parentFile?.name ?: "Storage" else "Files"

            outMap[key] = ScannedAudioTrack(
              id = id.toString(),
              title = cleanTitle,
              artist = "Storage Audio",
              durationMs = 180000,
              uri = uri,
              filePath = rawData,
              folderName = folder,
              fileExtension = ext.uppercase(Locale.ROOT),
              sizeBytes = size,
              fileSizeFormatted = formatFileSize(size)
            )
          }
        }
      }
    } catch (e: Exception) {
      Log.w(TAG, "Error querying MediaStore.Files: ${e.message}")
    }
  }

  private fun scanDirectStorageDirectories(
    context: Context,
    outMap: LinkedHashMap<String, ScannedAudioTrack>
  ) {
    try {
      val candidateDirs = mutableListOf<File>()

      // Standard public directories (Music & Downloads only - Ringtones & Notifications excluded)
      try {
        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC)?.let { candidateDirs.add(it) }
        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)?.let { candidateDirs.add(it) }
      } catch (e: Exception) {
        // Ignored
      }

      // Hardcoded well-known root storage paths
      val wellKnownPaths = listOf(
        "/storage/emulated/0/Music",
        "/storage/emulated/0/Download",
        "/storage/emulated/0/Downloads",
        "/storage/emulated/0/Audio",
        "/storage/emulated/0/Songs",
        "/storage/emulated/0/Recordings",
        "/storage/emulated/0/Documents",
        "/sdcard/Music",
        "/sdcard/Download"
      )

      for (path in wellKnownPaths) {
        val f = File(path)
        if (f.exists() && f.isDirectory && f.canRead()) {
          candidateDirs.add(f)
        }
      }

      for (dir in candidateDirs) {
        crawlDirectory(dir, maxDepth = 2, outMap)
      }
    } catch (e: Exception) {
      Log.w(TAG, "Error in direct directory scan: ${e.message}")
    }
  }

  private fun crawlDirectory(
    dir: File,
    maxDepth: Int,
    outMap: LinkedHashMap<String, ScannedAudioTrack>
  ) {
    if (maxDepth < 0 || !dir.exists() || !dir.isDirectory || !dir.canRead()) return

    // Never crawl notification or ringtone directories
    val dirName = dir.name.lowercase(Locale.ROOT)
    if (dirName == "ringtones" || dirName == "notifications" || dirName == "alarms" || dirName == "ui") return

    try {
      val files = dir.listFiles() ?: return
      for (file in files) {
        if (file.isFile) {
          val ext = file.extension.lowercase(Locale.ROOT)
          if (SUPPORTED_EXTENSIONS.contains(ext)) {
            val key = file.absolutePath
            if (!outMap.containsKey(key)) {
              outMap[key] = extractTrackFromFile(file, isImported = false)
            }
          }
        } else if (file.isDirectory && !file.name.startsWith(".")) {
          // Recurse into subfolders up to maxDepth
          crawlDirectory(file, maxDepth - 1, outMap)
        }
      }
    } catch (e: Exception) {
      // Ignored
    }
  }

  private fun extractTrackFromFile(file: File, isImported: Boolean): ScannedAudioTrack {
    var title = file.nameWithoutExtension
    var artist = if (isImported) "Imported Music" else file.parentFile?.name ?: "Local File"
    var durationMs = 180000

    try {
      val mmr = MediaMetadataRetriever()
      mmr.setDataSource(file.absolutePath)
      val metaTitle = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
      val metaArtist = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)
      val metaDur = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toIntOrNull()
      mmr.release()

      if (!metaTitle.isNullOrBlank()) title = metaTitle
      if (!metaArtist.isNullOrBlank()) artist = metaArtist
      if (metaDur != null && metaDur > 0) durationMs = metaDur
    } catch (e: Exception) {
      // Fallback to filename
    }

    val length = file.length()
    return ScannedAudioTrack(
      id = file.absolutePath.hashCode().toString(),
      title = title,
      artist = artist,
      durationMs = durationMs,
      uri = Uri.fromFile(file),
      filePath = file.absolutePath,
      folderName = file.parentFile?.name ?: "Storage",
      fileExtension = file.extension.uppercase(Locale.ROOT),
      sizeBytes = length,
      fileSizeFormatted = formatFileSize(length),
      isImported = isImported
    )
  }

  /**
   * Imports a Uri picked via SAF into app's persistent storage so it stays permanently in library.
   */
  fun importPickedAudioToAppStorage(context: Context, sourceUri: Uri): ScannedAudioTrack? {
    return try {
      val resolver = context.contentResolver
      val fileName = resolveFileName(context, sourceUri)
      val targetDir = File(context.filesDir, "imported_music").apply { mkdirs() }
      val targetFile = File(targetDir, fileName)

      resolver.openInputStream(sourceUri)?.use { input ->
        FileOutputStream(targetFile).use { output ->
          input.copyTo(output)
        }
      }

      extractTrackFromFile(targetFile, isImported = true)
    } catch (e: Exception) {
      Log.e(TAG, "Failed to copy picked audio to app storage", e)
      null
    }
  }

  private fun resolveFileName(context: Context, uri: Uri): String {
    var name: String? = null
    try {
      val cursor = context.contentResolver.query(uri, null, null, null, null)
      cursor?.use {
        if (it.moveToFirst()) {
          val idx = it.getColumnIndex(MediaStore.MediaColumns.DISPLAY_NAME)
          if (idx >= 0) {
            name = it.getString(idx)
          }
        }
      }
    } catch (e: Exception) {
      // Ignored
    }

    if (name.isNullOrBlank()) {
      name = uri.lastPathSegment ?: "track_${System.currentTimeMillis()}.mp3"
    }

    // Sanitize
    return name!!.replace(Regex("[^a-zA-Z0-9._-]"), "_")
  }

  private fun formatFileSize(bytes: Long): String {
    if (bytes <= 0) return ""
    val mb = bytes / (1024.0 * 1024.0)
    return String.format(Locale.US, "%.1f MB", mb)
  }
}
