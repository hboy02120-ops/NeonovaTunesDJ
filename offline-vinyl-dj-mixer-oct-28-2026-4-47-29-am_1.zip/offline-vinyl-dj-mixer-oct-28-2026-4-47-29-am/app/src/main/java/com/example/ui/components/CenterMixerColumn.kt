package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FileOpen
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DeckId
import com.example.model.DeckState
import com.example.ui.theme.BorderDark
import com.example.ui.theme.CarbonBlack
import com.example.ui.theme.LedGreen
import com.example.ui.theme.LedRed
import com.example.ui.theme.LedYellow
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPink
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite

@Composable
fun CenterMixerColumn(
  deckA: DeckState,
  deckB: DeckState,
  deckAColor: Color = NeonCyan,
  deckBColor: Color = NeonPink,
  onVolumeAChange: (Float) -> Unit,
  onVolumeBChange: (Float) -> Unit,
  onCueHeadphoneAToggle: () -> Unit,
  onCueHeadphoneBToggle: () -> Unit,
  onSyncClick: () -> Unit,
  onLoadTrackAClick: () -> Unit,
  onLoadTrackBClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  Column(
    modifier = modifier
      .width(108.dp)
      .fillMaxHeight()
      .background(Color(0xFF0F1218))
      .border(1.dp, BorderDark)
      .padding(horizontal = 6.dp, vertical = 4.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.SpaceBetween
  ) {
    // 1. Dual Circular Audio Source / File Picker Buttons
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(top = 2.dp),
      horizontalArrangement = Arrangement.SpaceEvenly,
      verticalAlignment = Alignment.CenterVertically
    ) {
      AudioSourceButton(
        label = "LOAD A",
        accentColor = deckAColor,
        onClick = onLoadTrackAClick,
        testTag = "deck_a_load_button"
      )
      AudioSourceButton(
        label = "LOAD B",
        accentColor = deckBColor,
        onClick = onLoadTrackBClick,
        testTag = "deck_b_load_button"
      )
    }

    Spacer(modifier = Modifier.height(4.dp))

    // 2. Tactile Center "SYNC" Button
    val isBpmMatched = kotlin.math.abs(deckA.bpm * (1.0 + deckA.pitchPercent / 100.0) -
        deckB.bpm * (1.0 + deckB.pitchPercent / 100.0)) < 0.1
    Box(
      modifier = Modifier
        .clip(RoundedCornerShape(6.dp))
        .background(
          if (isBpmMatched) LedGreen.copy(alpha = 0.25f)
          else Color(0xFF1E2330)
        )
        .border(
          width = 1.5.dp,
          color = if (isBpmMatched) LedGreen else Color(0xFF3E475A),
          shape = RoundedCornerShape(6.dp)
        )
        .clickable { onSyncClick() }
        .testTag("sync_button")
        .padding(horizontal = 12.dp, vertical = 4.dp),
      contentAlignment = Alignment.Center
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
          imageVector = Icons.Default.Sync,
          contentDescription = "Sync",
          tint = if (isBpmMatched) LedGreen else TextWhite,
          modifier = Modifier.size(13.dp)
        )
        Spacer(modifier = Modifier.width(3.dp))
        Text(
          text = "SYNC",
          color = if (isBpmMatched) LedGreen else TextWhite,
          fontSize = 10.sp,
          fontWeight = FontWeight.Black,
          fontFamily = FontFamily.Monospace
        )
      }
    }

    Spacer(modifier = Modifier.height(4.dp))

    // 3. Two Independent Vertical Channel Volume Sliders with VU Meters
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .weight(1f),
      horizontalArrangement = Arrangement.SpaceEvenly,
      verticalAlignment = Alignment.CenterVertically
    ) {
      // Deck A Channel Fader
      VerticalChannelFader(
        level = deckA.channelVolume,
        vuLevel = deckA.vuLevel,
        trackColor = deckAColor,
        onLevelChange = onVolumeAChange,
        testTag = "volume_fader_a",
        modifier = Modifier.weight(1f)
      )

      Spacer(modifier = Modifier.width(4.dp))

      // Deck B Channel Fader
      VerticalChannelFader(
        level = deckB.channelVolume,
        vuLevel = deckB.vuLevel,
        trackColor = deckBColor,
        onLevelChange = onVolumeBChange,
        testTag = "volume_fader_b",
        modifier = Modifier.weight(1f)
      )
    }

    Spacer(modifier = Modifier.height(4.dp))

    // 4. Dual Headphone CUE Monitor Toggles
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(bottom = 2.dp),
      horizontalArrangement = Arrangement.SpaceEvenly,
      verticalAlignment = Alignment.CenterVertically
    ) {
      CueMonitorButton(
        label = "CUE A",
        isActive = deckA.cueHeadphone,
        activeColor = deckAColor,
        onClick = onCueHeadphoneAToggle,
        testTag = "cue_headphone_a"
      )
      CueMonitorButton(
        label = "CUE B",
        isActive = deckB.cueHeadphone,
        activeColor = deckBColor,
        onClick = onCueHeadphoneBToggle,
        testTag = "cue_headphone_b"
      )
    }
  }
}

@Composable
private fun AudioSourceButton(
  label: String,
  accentColor: Color,
  onClick: () -> Unit,
  testTag: String
) {
  Box(
    modifier = Modifier
      .size(34.dp)
      .clip(CircleShape)
      .background(Color(0xFF191C25))
      .border(1.5.dp, accentColor, CircleShape)
      .clickable { onClick() }
      .testTag(testTag),
    contentAlignment = Alignment.Center
  ) {
    Icon(
      imageVector = Icons.Default.FileOpen,
      contentDescription = label,
      tint = accentColor,
      modifier = Modifier.size(16.dp)
    )
  }
}

@Composable
private fun VerticalChannelFader(
  level: Float,
  vuLevel: Float,
  trackColor: Color,
  onLevelChange: (Float) -> Unit,
  testTag: String,
  modifier: Modifier = Modifier
) {
  BoxWithConstraints(
    modifier = modifier
      .fillMaxHeight()
      .padding(horizontal = 2.dp),
    contentAlignment = Alignment.Center
  ) {
    val totalHeightPx = maxHeight.value

    Row(
      modifier = Modifier.fillMaxSize(),
      horizontalArrangement = Arrangement.Center,
      verticalAlignment = Alignment.CenterVertically
    ) {
      // Fader Track & Knob
      Box(
        modifier = Modifier
          .width(22.dp)
          .fillMaxHeight()
          .pointerInput(Unit) {
            detectDragGestures { change, _ ->
              change.consume()
              // Invert Y: top is 1.0, bottom is 0.0
              val fraction = 1.0f - (change.position.y / size.height).coerceIn(0f, 1f)
              onLevelChange(fraction)
            }
          }
          .clickable {
            // Quick tap jump
          }
          .testTag(testTag),
        contentAlignment = Alignment.BottomCenter
      ) {
        // Track Slot
        Box(
          modifier = Modifier
            .width(6.dp)
            .fillMaxHeight()
            .clip(RoundedCornerShape(3.dp))
            .background(Color(0xFF0A0C10))
            .border(0.8.dp, Color(0xFF282E3E), RoundedCornerShape(3.dp))
        ) {
          // Colored fill
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .fillMaxHeight(level.coerceIn(0f, 1f))
              .align(Alignment.BottomCenter)
              .background(trackColor.copy(alpha = 0.65f))
          )
        }

        // Fader Knob (Physical Metallic Cap)
        Box(
          modifier = Modifier
            .fillMaxHeight()
            .fillMaxWidth()
        ) {
          Box(
            modifier = Modifier
              .align(Alignment.BottomCenter)
              .fillMaxHeight(level.coerceIn(0f, 1f))
          ) {
            Box(
              modifier = Modifier
                .align(Alignment.TopCenter)
                .size(width = 22.dp, height = 14.dp)
                .clip(RoundedCornerShape(3.dp))
                .background(
                  Brush.verticalGradient(
                    colors = listOf(Color(0xFF6B7280), Color(0xFF374151), Color(0xFF1F2937))
                  )
                )
                .border(1.dp, Color(0xFF9CA3AF), RoundedCornerShape(3.dp))
            ) {
              // Center knurl line
              Box(
                modifier = Modifier
                  .align(Alignment.Center)
                  .width(14.dp)
                  .height(1.5.dp)
                  .background(trackColor)
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.width(3.dp))

      // LED VU Meter (Vertical 10-segment strip)
      Column(
        modifier = Modifier
          .width(5.dp)
          .fillMaxHeight()
          .padding(vertical = 4.dp),
        verticalArrangement = Arrangement.SpaceBetween,
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        val segmentCount = 10
        for (i in (segmentCount - 1) downTo 0) {
          val threshold = i.toFloat() / segmentCount
          val isLit = vuLevel >= threshold
          val segmentColor = when {
            i >= 8 -> LedRed
            i >= 6 -> LedYellow
            else -> LedGreen
          }
          Box(
            modifier = Modifier
              .size(width = 4.dp, height = 2.dp)
              .clip(RoundedCornerShape(1.dp))
              .background(if (isLit) segmentColor else Color(0xFF1A1F2B))
          )
        }
      }
    }
  }
}

@Composable
private fun CueMonitorButton(
  label: String,
  isActive: Boolean,
  activeColor: Color,
  onClick: () -> Unit,
  testTag: String
) {
  Box(
    modifier = Modifier
      .clip(RoundedCornerShape(4.dp))
      .background(if (isActive) activeColor.copy(alpha = 0.22f) else Color(0xFF181B24))
      .border(
        width = 1.dp,
        color = if (isActive) activeColor else Color(0xFF2E3444),
        shape = RoundedCornerShape(4.dp)
      )
      .clickable { onClick() }
      .testTag(testTag)
      .padding(horizontal = 6.dp, vertical = 3.dp),
    contentAlignment = Alignment.Center
  ) {
    Row(verticalAlignment = Alignment.CenterVertically) {
      Icon(
        imageVector = Icons.Default.Headphones,
        contentDescription = label,
        tint = if (isActive) activeColor else TextMuted,
        modifier = Modifier.size(11.dp)
      )
      Spacer(modifier = Modifier.width(2.dp))
      Text(
        text = label,
        color = if (isActive) activeColor else TextMuted,
        fontSize = 8.sp,
        fontWeight = FontWeight.Bold,
        fontFamily = FontFamily.Monospace
      )
    }
  }
}
