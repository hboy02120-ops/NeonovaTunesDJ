package com.example.model

enum class DeckId {
  DECK_A,
  DECK_B
}

enum class SideTab {
  NONE,
  FX,
  LOOP,
  EQ,
  HOT_CUES
}

enum class DjSkin(
  val displayName: String,
  val deckAColorHex: Long,
  val deckAGlowHex: Long,
  val deckBColorHex: Long,
  val deckBGlowHex: Long
) {
  CYBER_NEON(
    displayName = "Cyber Neon (Cyan / Pink)",
    deckAColorHex = 0xFF00E5FF,
    deckAGlowHex = 0xFF80D8FF,
    deckBColorHex = 0xFFFF007F,
    deckBGlowHex = 0xFFFF80AB
  ),
  TOXIC_GOLD(
    displayName = "Toxic Gold (Green / Amber)",
    deckAColorHex = 0xFF00FF66,
    deckAGlowHex = 0xFF69F0AE,
    deckBColorHex = 0xFFFFD600,
    deckBGlowHex = 0xFFFFE57F
  ),
  CLASSIC_CARBON(
    displayName = "Classic Carbon (Cyan / White)",
    deckAColorHex = 0xFF00D2FF,
    deckAGlowHex = 0xFF80DEEA,
    deckBColorHex = 0xFFF1F5F9,
    deckBGlowHex = 0xFFFFFFFF
  ),
  ULTRAVIOLET(
    displayName = "Ultraviolet (Violet / Magenta)",
    deckAColorHex = 0xFFA855F7,
    deckAGlowHex = 0xFFD8B4FE,
    deckBColorHex = 0xFFEC4899,
    deckBGlowHex = 0xFFF472B6
  ),
  INFERNO_EMBER(
    displayName = "Inferno Ember (Red / Orange)",
    deckAColorHex = 0xFFFF2A55,
    deckAGlowHex = 0xFFFF8A80,
    deckBColorHex = 0xFFFF8A00,
    deckBGlowHex = 0xFFFFD180
  ),
  ACID_MATRIX(
    displayName = "Acid Matrix (Lime / Electric)",
    deckAColorHex = 0xFF76FF03,
    deckAGlowHex = 0xFFB2FF59,
    deckBColorHex = 0xFF00E5FF,
    deckBGlowHex = 0xFF84FFFF
  )
}

enum class CrossfaderCurve(val displayName: String) {
  EQUAL_POWER("Equal Power (-3dB)"),
  LINEAR("Linear"),
  CUT_SCRATCH("Cut / Scratch")
}

enum class SlipmatStyle(val displayName: String) {
  RAINBOW_TARGET("Rainbow Target Grooves"),
  PSYCHEDELIC("Psychedelic Spiral"),
  NEON_CYBER("Neon Cyberpunk"),
  VINTAGE_VINYL("Vintage Black Groove"),
  ACID_SUN("Solar Flare")
}

data class HotCue(
  val index: Int, // 0..3
  val positionMs: Int,
  val label: String,
  val colorHex: Long
)

data class DeckState(
  val deckId: DeckId,
  val title: String = if (deckId == DeckId.DECK_A) "Midnight Rush [Demo A]" else "Neon Cyberbeat [Demo B]",
  val artist: String = if (deckId == DeckId.DECK_A) "DJ Cyberpulse" else "Groove Architect",
  val durationMs: Int = 30720, // ~30.7s seamless loop
  val positionMs: Int = 0,
  val isPlaying: Boolean = false,
  val bpm: Double = 125.0,
  val pitchPercent: Float = 0.0f, // -16% .. +16%
  val channelVolume: Float = 0.85f, // 0.0 .. 1.0
  val cueHeadphone: Boolean = false,
  val cuePositionMs: Int = 0,
  val isLoopActive: Boolean = false,
  val loopStartMs: Int = 0,
  val loopEndMs: Int = 0,
  val loopBeats: Float = 4f,
  val hotCues: List<HotCue> = emptyList(),
  val activeTab: SideTab = SideTab.NONE,
  val eqHigh: Float = 1.0f,
  val eqMid: Float = 1.0f,
  val eqLow: Float = 1.0f,
  val eqKillHigh: Boolean = false,
  val eqKillMid: Boolean = false,
  val eqKillLow: Boolean = false,
  val fxEnabled: Boolean = false,
  val fxType: String = "FILTER",
  val fxX: Float = 0.5f, // 0..1
  val fxY: Float = 0.5f, // 0..1
  val vinylAngleDegrees: Float = 0f,
  val isScratching: Boolean = false,
  val vuLevel: Float = 0f
)
