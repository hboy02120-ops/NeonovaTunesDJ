package com.example.ui.components

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.BasicAlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.model.DeckId
import com.example.ui.theme.CarbonBlack
import com.example.ui.theme.LedGreen
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPink
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import java.io.File
import java.util.Locale

data class AudioTrackItem(
  val id: String,
  val title: String,
  val artist: String,
  val durationMs: Int,
  val bpm: Double,
  val uri: Uri,
  val isBuiltIn: Boolean = false,
  val isRecording: Boolean = false
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TrackBrowserDialog(
  targetDeckId: DeckId,
  demoTrackAFile: File?,
  demoTrackBFile: File?,
  savedRecordings: List<File>,
  deckAColor: Color = NeonCyan,
  deckBColor: Color = NeonPink,
  onTrackSelected: (Uri) -> Unit,
  onLaunchSystemPicker: () -> Unit,
  onDismiss: () -> Unit
) {
  val context = LocalContext.current
  val isDeckA = targetDeckId == DeckId.DECK_A
  val accentColor = if (isDeckA) deckAColor else deckBColor

  var searchQuery by remember { mutableStateOf("") }
  var selectedTab by remember { mutableStateOf(0) } // 0: PHONE MUSIC, 1: DEMO TRACKS, 2: RECORDINGS

  val deviceTracks = remember { mutableStateListOf<AudioTrackItem>() }
  var isScanning by remember { mutableStateOf(false) }

  // Target Storage Permission depending on API level
  val requiredPermission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
    Manifest.permission.READ_MEDIA_AUDIO
  } else {
    Manifest.permission.READ_EXTERNAL_STORAGE
  }

  var hasStoragePermission by remember {
    mutableStateOf(
      ContextCompat.checkSelfPermission(context, requiredPermission) == PackageManager.PERMISSION_GRANTED
    )
  }

  fun scanDeviceAudio() {
    isScanning = true
    try {
      val projection = arrayOf(
        MediaStore.Audio.Media._ID,
        MediaStore.Audio.Media.TITLE,
        MediaStore.Audio.Media.ARTIST,
        MediaStore.Audio.Media.DURATION
      )
      // Query all music files >= 5s (excludes notification tones)
      var cursor = context.contentResolver.query(
        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
        projection,
        "${MediaStore.Audio.Media.DURATION} >= 5000",
        null,
        "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
      )

      // Fallback query if duration column is unavailable on some devices
      if (cursor == null || cursor.count == 0) {
        cursor?.close()
        cursor = context.contentResolver.query(
          MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
          projection,
          null,
          null,
          "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        )
      }

      cursor?.use { c ->
        val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
        val titleCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
        val artistCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
        val durCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)

        val scanned = mutableListOf<AudioTrackItem>()
        while (c.moveToNext()) {
          val id = c.getLong(idCol)
          val title = c.getString(titleCol) ?: "Track $id"
          val artist = c.getString(artistCol) ?: "Device Audio"
          val dur = c.getInt(durCol)
          val contentUri = Uri.withAppendedPath(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id.toString())

          scanned.add(
            AudioTrackItem(
              id = id.toString(),
              title = title,
              artist = artist,
              durationMs = dur,
              bpm = 125.0,
              uri = contentUri
            )
          )
        }
        deviceTracks.clear()
        deviceTracks.addAll(scanned)
      }
    } catch (e: Exception) {
      // Permission might be denied
    } finally {
      isScanning = false
    }
  }

  val permissionLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.RequestPermission()
  ) { isGranted ->
    hasStoragePermission = isGranted
    if (isGranted) {
      scanDeviceAudio()
    }
  }

  LaunchedEffect(Unit) {
    if (hasStoragePermission) {
      scanDeviceAudio()
    } else {
      // Automatically request permission on first library open
      permissionLauncher.launch(requiredPermission)
    }
  }

  // Pre-configured built-in demo EDM tracks
  val demoTracks = remember(demoTrackAFile, demoTrackBFile) {
    val list = mutableListOf<AudioTrackItem>()
    if (demoTrackAFile != null && demoTrackAFile.exists()) {
      list.add(
        AudioTrackItem(
          id = "demo_a",
          title = "Midnight Rush [Demo A]",
          artist = "DJ Cyberpulse",
          durationMs = 30720,
          bpm = 125.0,
          uri = Uri.fromFile(demoTrackAFile),
          isBuiltIn = true
        )
      )
    }
    if (demoTrackBFile != null && demoTrackBFile.exists()) {
      list.add(
        AudioTrackItem(
          id = "demo_b",
          title = "Neon Cyberbeat [Demo B]",
          artist = "Groove Architect",
          durationMs = 30720,
          bpm = 125.0,
          uri = Uri.fromFile(demoTrackBFile),
          isBuiltIn = true
        )
      )
    }
    list
  }

  val recordingItems = remember(savedRecordings) {
    savedRecordings.map { file ->
      AudioTrackItem(
        id = file.name,
        title = file.nameWithoutExtension,
        artist = "Live Recorded Mix",
        durationMs = 30000,
        bpm = 125.0,
        uri = Uri.fromFile(file),
        isRecording = true
      )
    }
  }

  val displayedTracks = when (selectedTab) {
    0 -> deviceTracks
    1 -> demoTracks
    else -> recordingItems
  }.filter {
    searchQuery.isEmpty() ||
        it.title.contains(searchQuery, ignoreCase = true) ||
        it.artist.contains(searchQuery, ignoreCase = true)
  }

  BasicAlertDialog(
    onDismissRequest = onDismiss,
    modifier = Modifier.testTag("track_browser_dialog")
  ) {
    Box(
      modifier = Modifier
        .fillMaxWidth(0.96f)
        .fillMaxHeight(0.94f)
        .clip(RoundedCornerShape(12.dp))
        .background(Color(0xFF0F1219))
        .border(1.5.dp, accentColor, RoundedCornerShape(12.dp))
        .padding(12.dp)
    ) {
      Column(modifier = Modifier.fillMaxSize()) {
        // Top Header
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(4.dp))
                .background(accentColor)
                .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
              Text(
                text = if (isDeckA) "DECK A" else "DECK B",
                color = CarbonBlack,
                fontSize = 9.5.sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace
              )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "SELECT MUSIC FOR ${if (isDeckA) "DECK A (LEFT)" else "DECK B (RIGHT)"}",
              color = accentColor,
              fontSize = 11.5.sp,
              fontWeight = FontWeight.Black,
              fontFamily = FontFamily.Monospace
            )
          }

          // Browse Files button & Close button
          Row(verticalAlignment = Alignment.CenterVertically) {
            // Refresh Library Scan
            if (hasStoragePermission) {
              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(6.dp))
                  .background(Color(0xFF1E2433))
                  .border(1.dp, Color(0xFF3E485D), RoundedCornerShape(6.dp))
                  .clickable { scanDeviceAudio() }
                  .padding(horizontal = 6.dp, vertical = 4.dp)
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Refresh",
                    tint = TextWhite,
                    modifier = Modifier.size(12.dp)
                  )
                  Spacer(modifier = Modifier.width(3.dp))
                  Text(
                    text = "RESCAN",
                    color = TextWhite,
                    fontSize = 8.5.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                  )
                }
              }

              Spacer(modifier = Modifier.width(6.dp))
            }

            // System Storage Folder Picker Fallback
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(6.dp))
                .background(Color(0xFF1E2433))
                .border(1.dp, Color(0xFF3E485D), RoundedCornerShape(6.dp))
                .clickable {
                  onLaunchSystemPicker()
                }
                .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                  imageVector = Icons.Default.FolderOpen,
                  contentDescription = "Browse Files",
                  tint = TextWhite,
                  modifier = Modifier.size(13.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                  text = "BROWSE FOLDERS",
                  color = TextWhite,
                  fontSize = 8.5.sp,
                  fontWeight = FontWeight.Bold,
                  fontFamily = FontFamily.Monospace
                )
              }
            }

            Spacer(modifier = Modifier.width(8.dp))

            Box(
              modifier = Modifier
                .size(24.dp)
                .clip(CircleShape)
                .background(Color(0xFF1D212D))
                .clickable { onDismiss() },
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Default.Close,
                contentDescription = "Close",
                tint = TextWhite,
                modifier = Modifier.size(13.dp)
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Permission Banner (if not yet granted)
        if (!hasStoragePermission) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(6.dp))
              .background(Color(0xFF261E14))
              .border(1.dp, Color(0xFFFFB300), RoundedCornerShape(6.dp))
              .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Row(
              modifier = Modifier.weight(1f),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(
                imageVector = Icons.Default.Security,
                contentDescription = "Permission",
                tint = Color(0xFFFFB300),
                modifier = Modifier.size(16.dp)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Column {
                Text(
                  text = "AUTO-SCAN DEVICE STORAGE",
                  color = Color(0xFFFFB300),
                  fontSize = 9.sp,
                  fontWeight = FontWeight.Black,
                  fontFamily = FontFamily.Monospace
                )
                Text(
                  text = "Grant storage access to automatically show all MP3s from your phone without manual import.",
                  color = TextWhite,
                  fontSize = 8.sp,
                  fontFamily = FontFamily.Monospace
                )
              }
            }

            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(4.dp))
                .background(Color(0xFFFFB300))
                .clickable { permissionLauncher.launch(requiredPermission) }
                .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
              Text(
                text = "GRANT PERMISSION",
                color = CarbonBlack,
                fontSize = 8.5.sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace
              )
            }
          }

          Spacer(modifier = Modifier.height(6.dp))
        }

        // Search Bar & Filter Tabs
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          // Search Box
          Box(
            modifier = Modifier
              .weight(1f)
              .height(34.dp)
              .clip(RoundedCornerShape(6.dp))
              .background(Color(0xFF151923))
              .border(1.dp, Color(0xFF2B3345), RoundedCornerShape(6.dp))
              .padding(horizontal = 8.dp),
            contentAlignment = Alignment.CenterStart
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Default.Search,
                contentDescription = "Search",
                tint = TextMuted,
                modifier = Modifier.size(14.dp)
              )
              Spacer(modifier = Modifier.width(6.dp))
              androidx.compose.foundation.text.BasicTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                textStyle = androidx.compose.ui.text.TextStyle(
                  color = TextWhite,
                  fontSize = 11.sp,
                  fontFamily = FontFamily.Monospace
                ),
                modifier = Modifier.fillMaxWidth(),
                decorationBox = { innerTextField ->
                  if (searchQuery.isEmpty()) {
                    Text(
                      text = "Filter songs, artists...",
                      color = Color(0xFF6B7280),
                      fontSize = 9.5.sp,
                      fontFamily = FontFamily.Monospace
                    )
                  }
                  innerTextField()
                }
              )
            }
          }

          // Tabs: 0 = ALL PHONE MUSIC, 1 = DEMO TRACKS, 2 = RECORDINGS
          Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            val tabs = listOf(
              "PHONE MUSIC (${deviceTracks.size})",
              "DEMO LOOPS (${demoTracks.size})",
              "RECORDINGS (${recordingItems.size})"
            )
            tabs.forEachIndexed { idx, label ->
              val isSelected = selectedTab == idx
              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(6.dp))
                  .background(if (isSelected) accentColor.copy(alpha = 0.25f) else Color(0xFF171B26))
                  .border(
                    width = 1.dp,
                    color = if (isSelected) accentColor else Color(0xFF282F40),
                    shape = RoundedCornerShape(6.dp)
                  )
                  .clickable { selectedTab = idx }
                  .padding(horizontal = 7.dp, vertical = 6.dp)
              ) {
                Text(
                  text = label,
                  color = if (isSelected) accentColor else TextMuted,
                  fontSize = 8.5.sp,
                  fontWeight = if (isSelected) FontWeight.Black else FontWeight.Bold,
                  fontFamily = FontFamily.Monospace
                )
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Track List
        if (displayedTracks.isEmpty()) {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .weight(1f),
            contentAlignment = Alignment.Center
          ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Text(
                text = if (selectedTab == 0) {
                  if (!hasStoragePermission) "Grant storage permission above to automatically list all your music."
                  else if (isScanning) "Scanning device music files..."
                  else "No audio tracks detected on this phone yet."
                } else if (selectedTab == 2) "No recordings saved yet. Tap MENU -> START REC to record a mix."
                else "No tracks found.",
                color = TextMuted,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace
              )
              Spacer(modifier = Modifier.height(6.dp))
              Text(
                text = "Tap 'BROWSE FOLDERS' to pick an audio file from any location.",
                color = Color(0xFF6B7280),
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace
              )
            }
          }
        } else {
          LazyColumn(
            modifier = Modifier
              .fillMaxWidth()
              .weight(1f),
            verticalArrangement = Arrangement.spacedBy(4.dp)
          ) {
            items(displayedTracks) { item ->
              TrackRowItem(
                track = item,
                accentColor = accentColor,
                targetDeckLabel = if (isDeckA) "LOAD A" else "LOAD B",
                onSelect = {
                  onTrackSelected(item.uri)
                  onDismiss()
                }
              )
            }
          }
        }
      }
    }
  }
}

@Composable
private fun TrackRowItem(
  track: AudioTrackItem,
  accentColor: Color,
  targetDeckLabel: String,
  onSelect: () -> Unit
) {
  val totalSec = track.durationMs / 1000
  val durationStr = String.format(Locale.US, "%02d:%02d", totalSec / 60, totalSec % 60)

  Row(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(6.dp))
      .background(Color(0xFF131722))
      .border(1.dp, Color(0xFF23293A), RoundedCornerShape(6.dp))
      .clickable { onSelect() }
      .padding(horizontal = 8.dp, vertical = 6.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Row(
      modifier = Modifier.weight(1f),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Box(
        modifier = Modifier
          .size(28.dp)
          .clip(CircleShape)
          .background(accentColor.copy(alpha = 0.2f)),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = Icons.Default.PlayArrow,
          contentDescription = "Load",
          tint = accentColor,
          modifier = Modifier.size(16.dp)
        )
      }

      Spacer(modifier = Modifier.width(8.dp))

      Column {
        Text(
          text = track.title,
          color = TextWhite,
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )
        Text(
          text = "${track.artist} • ${track.bpm.toInt()} BPM • $durationStr",
          color = TextMuted,
          fontSize = 9.sp,
          fontFamily = FontFamily.Monospace
        )
      }
    }

    Box(
      modifier = Modifier
        .clip(RoundedCornerShape(4.dp))
        .background(accentColor)
        .clickable { onSelect() }
        .padding(horizontal = 9.dp, vertical = 5.dp),
      contentAlignment = Alignment.Center
    ) {
      Text(
        text = targetDeckLabel,
        color = CarbonBlack,
        fontSize = 9.sp,
        fontWeight = FontWeight.Black,
        fontFamily = FontFamily.Monospace
      )
    }
  }
}
