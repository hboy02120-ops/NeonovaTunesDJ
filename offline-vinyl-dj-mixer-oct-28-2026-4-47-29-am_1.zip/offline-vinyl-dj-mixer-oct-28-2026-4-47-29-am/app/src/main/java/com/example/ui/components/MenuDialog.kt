package com.example.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.BasicAlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CrossfaderCurve
import com.example.model.DjSkin
import com.example.model.SlipmatStyle
import com.example.ui.theme.CarbonBlack
import com.example.ui.theme.LedGreen
import com.example.ui.theme.LedRed
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPink
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import androidx.compose.foundation.Image
import androidx.compose.ui.res.painterResource
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.example.R
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MenuDialog(
  currentCurve: CrossfaderCurve,
  currentSlipmat: SlipmatStyle,
  currentSkin: DjSkin = DjSkin.CYBER_NEON,
  isRecording: Boolean = false,
  recordingElapsedMs: Long = 0L,
  onToggleRecording: () -> Unit = {},
  onCurveSelect: (CrossfaderCurve) -> Unit,
  onSlipmatSelect: (SlipmatStyle) -> Unit,
  onSkinSelect: (DjSkin) -> Unit = {},
  onDismiss: () -> Unit
) {
  val infiniteTransition = rememberInfiniteTransition(label = "rec_blink")
  val recAlpha by infiniteTransition.animateFloat(
    initialValue = 1.0f,
    targetValue = 0.25f,
    animationSpec = infiniteRepeatable(
      animation = tween(600),
      repeatMode = RepeatMode.Reverse
    ),
    label = "rec_blink_anim"
  )

  var menuTab by remember { mutableStateOf(0) } // 0: CONTROLS & SKINS, 1: ABOUT NEONOVA

  BasicAlertDialog(
    onDismissRequest = onDismiss,
    modifier = Modifier.testTag("menu_dialog")
  ) {
    Box(
      modifier = Modifier
        .fillMaxWidth(0.96f)
        .clip(RoundedCornerShape(12.dp))
        .background(Color(0xFF0F1218))
        .border(1.5.dp, Color(0xFF2C3345), RoundedCornerShape(12.dp))
        .padding(14.dp)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .verticalScroll(rememberScrollState())
      ) {
        // Top Header
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.Settings,
              contentDescription = "Settings",
              tint = NeonCyan,
              modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "NEONOVA TUNES DJ • MENU",
              color = TextWhite,
              fontSize = 12.sp,
              fontWeight = FontWeight.Black,
              fontFamily = FontFamily.Monospace
            )
          }

          Box(
            modifier = Modifier
              .size(26.dp)
              .clip(CircleShape)
              .background(Color(0xFF1E2330))
              .clickable { onDismiss() },
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Default.Close,
              contentDescription = "Close",
              tint = TextWhite,
              modifier = Modifier.size(14.dp)
            )
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // TAB SELECTOR
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF0A0D14))
            .border(1.dp, Color(0xFF202738), RoundedCornerShape(8.dp))
            .padding(3.dp),
          horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
          Box(
            modifier = Modifier
              .weight(1f)
              .clip(RoundedCornerShape(6.dp))
              .background(if (menuTab == 0) NeonCyan.copy(alpha = 0.22f) else Color.Transparent)
              .border(1.dp, if (menuTab == 0) NeonCyan else Color.Transparent, RoundedCornerShape(6.dp))
              .clickable { menuTab = 0 }
              .padding(vertical = 7.dp),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = "⚙️ CONTROLS & SKINS",
              color = if (menuTab == 0) NeonCyan else TextMuted,
              fontSize = 10.sp,
              fontWeight = FontWeight.Black,
              fontFamily = FontFamily.Monospace
            )
          }

          Box(
            modifier = Modifier
              .weight(1f)
              .clip(RoundedCornerShape(6.dp))
              .background(if (menuTab == 1) NeonPink.copy(alpha = 0.25f) else Color.Transparent)
              .border(1.dp, if (menuTab == 1) NeonPink else Color.Transparent, RoundedCornerShape(6.dp))
              .clickable { menuTab = 1 }
              .padding(vertical = 7.dp),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = "🎧 ABOUT NEONOVA TUNES",
              color = if (menuTab == 1) NeonPink else TextMuted,
              fontSize = 10.sp,
              fontWeight = FontWeight.Black,
              fontFamily = FontFamily.Monospace
            )
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (menuTab == 0) {
          // CONTROLS & SKINS TAB CONTENT

        // 1. Live Mix Recording Section (Relocated into Menu for a cleaner waveform)
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(if (isRecording) Color(0x33FF1744) else Color(0xFF161A25))
            .border(
              width = 1.2.dp,
              color = if (isRecording) LedRed else Color(0xFF2B3346),
              shape = RoundedCornerShape(8.dp)
            )
            .padding(10.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(if (isRecording) LedRed.copy(alpha = recAlpha) else Color(0xFF6B7280))
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column {
              Text(
                text = if (isRecording) "RECORDING IN PROGRESS..." else "LIVE MIX RECORDER",
                color = if (isRecording) LedRed else TextWhite,
                fontSize = 10.sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace
              )
              Text(
                text = if (isRecording) "Elapsed: ${formatTime(recordingElapsedMs.toInt())} (Saved as HD WAV)"
                else "Record and save your live transitions to device storage",
                color = TextMuted,
                fontSize = 8.sp,
                fontFamily = FontFamily.Monospace
              )
            }
          }

          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(6.dp))
              .background(if (isRecording) LedRed else Color(0xFF252C3D))
              .border(
                width = 1.dp,
                color = if (isRecording) LedRed else Color(0xFF434E66),
                shape = RoundedCornerShape(6.dp)
              )
              .clickable { onToggleRecording() }
              .padding(horizontal = 10.dp, vertical = 6.dp),
            contentAlignment = Alignment.Center
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = if (isRecording) Icons.Default.Stop else Icons.Default.FiberManualRecord,
                contentDescription = "Record",
                tint = if (isRecording) CarbonBlack else LedRed,
                modifier = Modifier.size(12.dp)
              )
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = if (isRecording) "STOP REC" else "START REC",
                color = if (isRecording) CarbonBlack else TextWhite,
                fontSize = 9.sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // 2. DJ Console Skins & Themes (All 6 Skins included!)
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Default.Palette,
            contentDescription = "Skins",
            tint = NeonCyan,
            modifier = Modifier.size(13.dp)
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = "CONSOLE SKINS (6 THEMES)",
            color = TextMuted,
            fontSize = 9.sp,
            fontWeight = FontWeight.Black,
            fontFamily = FontFamily.Monospace
          )
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Grid of 6 Skins (2 rows of 3 columns)
        val allSkins = DjSkin.values().toList()
        Column(
          modifier = Modifier.fillMaxWidth(),
          verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          allSkins.chunked(3).forEach { rowSkins ->
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              rowSkins.forEach { skin ->
                val isSelected = currentSkin == skin
                val skinColorA = Color(skin.deckAColorHex)
                val skinColorB = Color(skin.deckBColorHex)

                Box(
                  modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(6.dp))
                    .background(if (isSelected) skinColorA.copy(alpha = 0.2f) else Color(0xFF141721))
                    .border(
                      width = if (isSelected) 1.5.dp else 1.dp,
                      color = if (isSelected) skinColorA else Color(0xFF282F40),
                      shape = RoundedCornerShape(6.dp)
                    )
                    .clickable { onSkinSelect(skin) }
                    .padding(horizontal = 6.dp, vertical = 7.dp),
                  contentAlignment = Alignment.Center
                ) {
                  Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                  ) {
                    Box(
                      modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(skinColorA)
                    )
                    Spacer(modifier = Modifier.width(2.dp))
                    Box(
                      modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(skinColorB)
                    )
                    Spacer(modifier = Modifier.width(5.dp))
                    Text(
                      text = skin.displayName.split(" ")[0] + " " + skin.displayName.split(" ").getOrElse(1) { "" },
                      color = if (isSelected) TextWhite else TextMuted,
                      fontSize = 8.sp,
                      fontWeight = if (isSelected) FontWeight.Black else FontWeight.Bold,
                      fontFamily = FontFamily.Monospace,
                      maxLines = 1
                    )
                  }
                }
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // 3. Crossfader Curve Setting
        Text(
          text = "CROSSFADER CURVE MATHEMATICS",
          color = TextMuted,
          fontSize = 9.sp,
          fontWeight = FontWeight.Bold,
          fontFamily = FontFamily.Monospace
        )
        Spacer(modifier = Modifier.height(6.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          CrossfaderCurve.values().forEach { curve ->
            val isSelected = currentCurve == curve
            Box(
              modifier = Modifier
                .weight(1f)
                .clip(RoundedCornerShape(6.dp))
                .background(if (isSelected) NeonCyan.copy(alpha = 0.2f) else Color(0xFF141721))
                .border(1.dp, if (isSelected) NeonCyan else Color(0xFF282F40), RoundedCornerShape(6.dp))
                .clickable { onCurveSelect(curve) }
                .padding(vertical = 7.dp, horizontal = 4.dp),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = curve.displayName,
                color = if (isSelected) NeonCyan else TextWhite,
                fontSize = 8.5.sp,
                fontWeight = if (isSelected) FontWeight.Black else FontWeight.Normal,
                fontFamily = FontFamily.Monospace,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // 4. Vinyl Slipmat Artwork
        Text(
          text = "VINYL SLIPMAT ARTWORK",
          color = TextMuted,
          fontSize = 9.sp,
          fontWeight = FontWeight.Bold,
          fontFamily = FontFamily.Monospace
        )
        Spacer(modifier = Modifier.height(6.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
          SlipmatStyle.values().forEach { style ->
            val isSelected = currentSlipmat == style
            Box(
              modifier = Modifier
                .weight(1f)
                .clip(RoundedCornerShape(6.dp))
                .background(if (isSelected) NeonPink.copy(alpha = 0.2f) else Color(0xFF141721))
                .border(1.dp, if (isSelected) NeonPink else Color(0xFF282F40), RoundedCornerShape(6.dp))
                .clickable { onSlipmatSelect(style) }
                .padding(vertical = 7.dp, horizontal = 2.dp),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = style.displayName.split(" ")[0],
                color = if (isSelected) NeonPink else TextWhite,
                fontSize = 8.sp,
                fontWeight = if (isSelected) FontWeight.Black else FontWeight.Normal,
                fontFamily = FontFamily.Monospace,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // 5. 100% Offline Status Card
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(Color(0xFF121620))
            .border(1.dp, LedGreen.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 6.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(
            imageVector = Icons.Default.Security,
            contentDescription = "Offline",
            tint = LedGreen,
            modifier = Modifier.size(15.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Column {
            Text(
              text = "100% OFFLINE AIR-GAPPED DSP ENGINE",
              color = LedGreen,
              fontSize = 9.sp,
              fontWeight = FontWeight.Black,
              fontFamily = FontFamily.Monospace
            )
            Text(
              text = "Zero network requests • Zero logins • Local internal media only",
              color = TextMuted,
              fontSize = 7.5.sp,
              fontFamily = FontFamily.Monospace
            )
          }
        }
      } else {
        // ABOUT NEONOVA TUNES DJ TAB
        AboutNeonovaTunesSection()
      }
      }
    }
  }
}

@Composable
private fun AboutNeonovaTunesSection() {
  Column(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 4.dp),
    horizontalAlignment = Alignment.CenterHorizontally
  ) {
    // App Logo Image with Glowing Cyan/Magenta Border
    Box(
      modifier = Modifier
        .size(80.dp)
        .clip(RoundedCornerShape(20.dp))
        .background(Color(0xFF090B10))
        .border(2.dp, NeonCyan, RoundedCornerShape(20.dp)),
      contentAlignment = Alignment.Center
    ) {
      Image(
        painter = painterResource(R.drawable.ic_neonova_logo),
        contentDescription = "Neonova Tunes DJ Logo",
        modifier = Modifier
          .size(76.dp)
          .clip(RoundedCornerShape(18.dp))
      )
    }

    Spacer(modifier = Modifier.height(10.dp))

    // User's exact requested heading
    Text(
      text = "🎧 About Neonova Tunes DJ 🎶",
      color = NeonCyan,
      fontSize = 15.sp,
      fontWeight = FontWeight.Black,
      fontFamily = FontFamily.Monospace,
      textAlign = androidx.compose.ui.text.style.TextAlign.Center
    )

    Spacer(modifier = Modifier.height(6.dp))

    // User's exact welcome description
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(8.dp))
        .background(Color(0xFF131722))
        .border(1.dp, Color(0xFF232B3E), RoundedCornerShape(8.dp))
        .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
      Text(
        text = "Welcome to Neonova Tunes DJ — Feel the beats, enjoy the rhythm, and experience music in a whole new vibe. 🔥",
        color = TextWhite,
        fontSize = 10.5.sp,
        fontWeight = FontWeight.Medium,
        fontFamily = FontFamily.Monospace,
        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
        lineHeight = 15.sp,
        modifier = Modifier.fillMaxWidth()
      )
    }

    Spacer(modifier = Modifier.height(8.dp))

    // User's exact tagline banner
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(8.dp))
        .background(NeonPink.copy(alpha = 0.15f))
        .border(1.2.dp, NeonPink, RoundedCornerShape(8.dp))
        .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
      Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Text(
          text = "✨ Modern Style • Music Vibes • DJ Experience",
          color = NeonPink,
          fontSize = 11.sp,
          fontWeight = FontWeight.Black,
          fontFamily = FontFamily.Monospace,
          textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
        Spacer(modifier = Modifier.height(3.dp))
        Text(
          text = "Neonova Tunes DJ — Feel the Beat, Live the Music! 🎵",
          color = TextWhite,
          fontSize = 10.sp,
          fontWeight = FontWeight.Bold,
          fontFamily = FontFamily.Monospace,
          textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
      }
    }

    Spacer(modifier = Modifier.height(10.dp))

    // Pro Feature Highlights Cards
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
      Box(
        modifier = Modifier
          .weight(1f)
          .clip(RoundedCornerShape(6.dp))
          .background(Color(0xFF10141D))
          .border(1.dp, Color(0xFF1F2738), RoundedCornerShape(6.dp))
          .padding(8.dp)
      ) {
        Column {
          Text(
            text = "TURNTABLE DSP",
            color = NeonCyan,
            fontSize = 9.sp,
            fontWeight = FontWeight.Black,
            fontFamily = FontFamily.Monospace
          )
          Spacer(modifier = Modifier.height(2.dp))
          Text(
            text = "• Directional Vinyl Scratch\n• Real-Time Needle Friction\n• Smooth Motor Spin-Down Brake\n• Spool-Up Acceleration",
            color = TextWhite,
            fontSize = 7.5.sp,
            fontFamily = FontFamily.Monospace,
            lineHeight = 11.sp
          )
        }
      }

      Box(
        modifier = Modifier
          .weight(1f)
          .clip(RoundedCornerShape(6.dp))
          .background(Color(0xFF10141D))
          .border(1.dp, Color(0xFF1F2738), RoundedCornerShape(6.dp))
          .padding(8.dp)
      ) {
        Column {
          Text(
            text = "PRO MIXING TOOLS",
            color = NeonPink,
            fontSize = 9.sp,
            fontWeight = FontWeight.Black,
            fontFamily = FontFamily.Monospace
          )
          Spacer(modifier = Modifier.height(2.dp))
          Text(
            text = "• Equal-Power Crossfader\n• 3-Band EQ + Kill Switches\n• XY Kaoss Pad FX & Filter\n• 8-Pad Performance Sampler",
            color = TextWhite,
            fontSize = 7.5.sp,
            fontFamily = FontFamily.Monospace,
            lineHeight = 11.sp
          )
        }
      }

      Box(
        modifier = Modifier
          .weight(1f)
          .clip(RoundedCornerShape(6.dp))
          .background(Color(0xFF10141D))
          .border(1.dp, Color(0xFF1F2738), RoundedCornerShape(6.dp))
          .padding(8.dp)
      ) {
        Column {
          Text(
            text = "STORAGE & PRIVACY",
            color = LedGreen,
            fontSize = 9.sp,
            fontWeight = FontWeight.Black,
            fontFamily = FontFamily.Monospace
          )
          Spacer(modifier = Modifier.height(2.dp))
          Text(
            text = "• Direct Phone Storage Scan\n• Notification Chime Filter\n• 100% Offline Air-Gapped\n• Live WAV Mix Recording",
            color = TextWhite,
            fontSize = 7.5.sp,
            fontFamily = FontFamily.Monospace,
            lineHeight = 11.sp
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(8.dp))

    // Version Footer
    Text(
      text = "NEONOVA TUNES DJ PRO • V2.5 • LOW-LATENCY AUDIO ENGINE",
      color = Color(0xFF53627A),
      fontSize = 8.sp,
      fontWeight = FontWeight.Bold,
      fontFamily = FontFamily.Monospace
    )
  }
}

private fun formatTime(ms: Int): String {
  val totalSec = ms / 1000
  val min = totalSec / 60
  val sec = totalSec % 60
  return String.format(Locale.US, "%02d:%02d", min, sec)
}
