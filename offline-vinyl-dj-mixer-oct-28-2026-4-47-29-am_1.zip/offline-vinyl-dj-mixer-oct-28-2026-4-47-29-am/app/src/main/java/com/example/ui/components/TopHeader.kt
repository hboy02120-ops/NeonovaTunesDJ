package com.example.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DeckState
import com.example.ui.theme.CarbonBlack
import com.example.ui.theme.LedRed
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPink
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import java.util.Locale
import kotlin.math.sin

@Composable
fun TopHeader(
  deckA: DeckState,
  deckB: DeckState,
  deckAColor: Color = NeonCyan,
  deckBColor: Color = NeonPink,
  isRecording: Boolean,
  recordingElapsedMs: Long,
  onMenuClick: () -> Unit,
  onOpenBrowserA: () -> Unit = {},
  onOpenBrowserB: () -> Unit = {},
  onTapA: () -> Unit,
  onTapB: () -> Unit,
  onScrubA: (Float) -> Unit,
  onScrubB: (Float) -> Unit,
  modifier: Modifier = Modifier
) {
  Row(
    modifier = modifier
      .fillMaxWidth()
      .height(56.dp)
      .background(CarbonBlack)
      .border(width = 1.dp, color = Color(0xFF1E222D))
      .padding(horizontal = 6.dp, vertical = 2.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    // 1. Left Deck A Info Box (Clickable to Load Track to Deck A)
    DeckInfoWidget(
      state = deckA,
      accentColor = deckAColor,
      isLeft = true,
      onTapBpm = onTapA,
      onClickLoad = onOpenBrowserA,
      modifier = Modifier.weight(1.15f)
    )

    Spacer(modifier = Modifier.width(6.dp))

    // 2. Center Continuous Dual Audio Waveform Visualizer + Clean Centered MENU pill
    DualWaveformVisualizer(
      deckA = deckA,
      deckB = deckB,
      deckAColor = deckAColor,
      deckBColor = deckBColor,
      isRecording = isRecording,
      onMenuClick = onMenuClick,
      onScrubA = onScrubA,
      onScrubB = onScrubB,
      modifier = Modifier
        .weight(1.9f)
        .fillMaxHeight()
    )

    Spacer(modifier = Modifier.width(6.dp))

    // 3. Right Deck B Info Box (Clickable to Load Track to Deck B)
    DeckInfoWidget(
      state = deckB,
      accentColor = deckBColor,
      isLeft = false,
      onTapBpm = onTapB,
      onClickLoad = onOpenBrowserB,
      modifier = Modifier.weight(1.15f)
    )
  }
}

@Composable
private fun DeckInfoWidget(
  state: DeckState,
  accentColor: Color,
  isLeft: Boolean,
  onTapBpm: () -> Unit,
  onClickLoad: () -> Unit,
  modifier: Modifier = Modifier
) {
  val effectiveBpm = state.bpm * (1.0 + state.pitchPercent / 100.0)
  val elapsedStr = formatTime(state.positionMs)
  val totalStr = formatTime(state.durationMs)

  Row(
    modifier = modifier
      .fillMaxHeight()
      .clip(RoundedCornerShape(6.dp))
      .background(Color(0xFF12151D))
      .border(1.dp, Color(0xFF222736), RoundedCornerShape(6.dp))
      .clickable { onClickLoad() }
      .padding(horizontal = 6.dp, vertical = 3.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = if (isLeft) Arrangement.Start else Arrangement.End
  ) {
    if (isLeft) {
      DeckBadge(label = "DECK A", color = accentColor, onClick = onClickLoad)
      Spacer(modifier = Modifier.width(6.dp))
    }

    Column(
      modifier = Modifier.weight(1f),
      verticalArrangement = Arrangement.Center,
      horizontalAlignment = if (isLeft) Alignment.Start else Alignment.End
    ) {
      Text(
        text = state.title,
        color = TextWhite,
        fontSize = 10.5.sp,
        fontWeight = FontWeight.Bold,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis
      )

      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = if (isLeft) Arrangement.Start else Arrangement.End
      ) {
        Text(
          text = String.format(Locale.US, "%.1f BPM", effectiveBpm),
          color = accentColor,
          fontSize = 11.sp,
          fontWeight = FontWeight.Black,
          fontFamily = FontFamily.Monospace
        )

        Spacer(modifier = Modifier.width(4.dp))

        // Mini TAP button
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(3.dp))
            .background(Color(0xFF1B202D))
            .border(0.8.dp, Color(0xFF323B4E), RoundedCornerShape(3.dp))
            .clickable { onTapBpm() }
            .padding(horizontal = 4.dp, vertical = 1.dp)
        ) {
          Text(
            text = "TAP",
            color = TextMuted,
            fontSize = 7.5.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
          )
        }

        Spacer(modifier = Modifier.width(4.dp))

        Text(
          text = "$elapsedStr / $totalStr",
          color = TextMuted,
          fontSize = 9.sp,
          fontFamily = FontFamily.Monospace
        )
      }
    }

    if (!isLeft) {
      Spacer(modifier = Modifier.width(6.dp))
      DeckBadge(label = "DECK B", color = accentColor, onClick = onClickLoad)
    }
  }
}

@Composable
private fun DeckBadge(label: String, color: Color, onClick: () -> Unit = {}) {
  Box(
    modifier = Modifier
      .clip(RoundedCornerShape(4.dp))
      .background(color.copy(alpha = 0.22f))
      .border(1.2.dp, color, RoundedCornerShape(4.dp))
      .clickable { onClick() }
      .padding(horizontal = 5.dp, vertical = 3.dp)
  ) {
    Text(
      text = label,
      color = color,
      fontSize = 8.5.sp,
      fontWeight = FontWeight.Black,
      fontFamily = FontFamily.Monospace
    )
  }
}

@Composable
private fun DualWaveformVisualizer(
  deckA: DeckState,
  deckB: DeckState,
  deckAColor: Color,
  deckBColor: Color,
  isRecording: Boolean,
  onMenuClick: () -> Unit,
  onScrubA: (Float) -> Unit,
  onScrubB: (Float) -> Unit,
  modifier: Modifier = Modifier
) {
  Box(
    modifier = modifier
      .clip(RoundedCornerShape(6.dp))
      .background(Color(0xFF0D0F14))
      .border(1.dp, Color(0xFF232838), RoundedCornerShape(6.dp))
  ) {
    Canvas(
      modifier = Modifier
        .fillMaxSize()
        .pointerInput(Unit) {
          detectTapGestures { offset ->
            val fraction = (offset.x / size.width).coerceIn(0f, 1f)
            if (offset.y < size.height / 2f) onScrubA(fraction) else onScrubB(fraction)
          }
        }
        .pointerInput(Unit) {
          detectDragGestures { change, _ ->
            change.consume()
            val fraction = (change.position.x / size.width).coerceIn(0f, 1f)
            if (change.position.y < size.height / 2f) onScrubA(fraction) else onScrubB(fraction)
          }
        }
    ) {
      val w = size.width
      val h = size.height
      val midY = h / 2f

      drawLine(
        color = Color(0xFF1F2432),
        start = Offset(0f, midY),
        end = Offset(w, midY),
        strokeWidth = 1.dp.toPx()
      )

      val gridSpacing = w / 16f
      for (i in 0..16) {
        val gx = i * gridSpacing
        drawLine(
          color = Color(0xFF1B202C),
          start = Offset(gx, 0f),
          end = Offset(gx, h),
          strokeWidth = 0.8.dp.toPx()
        )
      }

      val progressA = if (deckA.durationMs > 0) deckA.positionMs.toFloat() / deckA.durationMs else 0f
      drawContinuousWave(w, 2f, midY - 3f, progressA, deckAColor, deckA.isPlaying, 1337)

      val progressB = if (deckB.durationMs > 0) deckB.positionMs.toFloat() / deckB.durationMs else 0f
      drawContinuousWave(w, midY + 1f, midY - 3f, progressB, deckBColor, deckB.isPlaying, 4242)

      val playheadX = w / 2f
      drawLine(
        color = Color(0x66FF1744),
        start = Offset(playheadX, 0f),
        end = Offset(playheadX, h),
        strokeWidth = 4.dp.toPx()
      )
      drawLine(
        color = Color(0xFFFF1744),
        start = Offset(playheadX, 0f),
        end = Offset(playheadX, h),
        strokeWidth = 1.5.dp.toPx()
      )
    }

    // Centered Clean MENU Pill (Matching Neonova Tunes reference UI)
    Box(
      modifier = Modifier
        .align(Alignment.Center)
        .clip(RoundedCornerShape(12.dp))
        .background(Color(0xF0181D28))
        .border(1.2.dp, Color(0xFF4A5568), RoundedCornerShape(12.dp))
        .clickable { onMenuClick() }
        .padding(horizontal = 8.dp, vertical = 3.dp),
      contentAlignment = Alignment.Center
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        if (isRecording) {
          Box(
            modifier = Modifier
              .size(6.dp)
              .clip(CircleShape)
              .background(LedRed)
          )
          Spacer(modifier = Modifier.width(4.dp))
        }
        Icon(
          imageVector = Icons.Default.Menu,
          contentDescription = "Menu",
          tint = TextWhite,
          modifier = Modifier.size(12.dp)
        )
        Spacer(modifier = Modifier.width(3.dp))
        Text(
          text = "MENU",
          color = TextWhite,
          fontSize = 9.sp,
          fontWeight = FontWeight.Black,
          fontFamily = FontFamily.Monospace
        )
      }
    }
  }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawContinuousWave(
  w: Float,
  laneTop: Float,
  laneHeight: Float,
  progress: Float,
  accentColor: Color,
  isPlaying: Boolean,
  seed: Int
) {
  val barCount = 64
  val barWidth = w / barCount
  val playheadBar = barCount / 2

  for (i in 0 until barCount) {
    val barOffset = i - playheadBar
    val waveIndex = ((barOffset * 0.05f + progress * 8f) * 10f).toInt()
    val pseudoAmp = (sin(waveIndex * 0.4 + seed) * 0.35 +
        sin(waveIndex * 0.85 + seed * 2) * 0.25 +
        sin(waveIndex * 1.7) * 0.15 + 0.5).coerceIn(0.12, 0.95).toFloat()

    val barH = laneHeight * pseudoAmp
    val bx = i * barWidth
    val by = laneTop + (laneHeight - barH) / 2f

    val isPassed = i <= playheadBar
    val barColor = if (isPassed) accentColor else accentColor.copy(alpha = 0.38f)

    drawRect(
      color = barColor,
      topLeft = Offset(bx + 1f, by),
      size = Size((barWidth - 1.5f).coerceAtLeast(1f), barH)
    )
  }
}

private fun formatTime(ms: Int): String {
  val totalSec = ms / 1000
  val min = totalSec / 60
  val sec = totalSec % 60
  return String.format(Locale.US, "%02d:%02d", min, sec)
}
