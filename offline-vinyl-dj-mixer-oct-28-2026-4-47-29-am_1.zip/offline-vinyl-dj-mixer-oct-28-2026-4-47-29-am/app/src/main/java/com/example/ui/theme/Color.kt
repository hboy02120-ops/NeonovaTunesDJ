package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CarbonBlack = Color(0xFF090A0D)
val SurfaceDark = Color(0xFF12141A)
val SurfaceElevated = Color(0xFF1B1E26)
val SurfaceHighlight = Color(0xFF262B37)
val BorderDark = Color(0xFF2D3342)

// Deck A - Neon Cyan
val NeonCyan = Color(0xFF00E5FF)
val NeonCyanGlow = Color(0xFF80D8FF)
val NeonCyanDark = Color(0xFF004D5C)
val NeonCyanContainer = Color(0xFF00222B)

// Deck B - Neon Coral / Magenta Accent
val NeonPink = Color(0xFFFF2A6D)
val NeonPinkGlow = Color(0xFFFF7597)
val NeonPinkDark = Color(0xFF5A0820)
val NeonPinkContainer = Color(0xFF29030E)

// Sliders and Status
val LedGreen = Color(0xFF00E676)
val LedYellow = Color(0xFFFFD600)
val LedRed = Color(0xFFFF1744)
val TextMuted = Color(0xFF8E95A5)
val TextWhite = Color(0xFFF3F4F6)
val KnurledMetal = Color(0xFF323642)
