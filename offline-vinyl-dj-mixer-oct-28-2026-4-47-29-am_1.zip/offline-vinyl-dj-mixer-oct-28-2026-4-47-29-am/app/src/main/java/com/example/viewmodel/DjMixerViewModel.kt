package com.example.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.DjAudioEngine
import com.example.audio.RecordingManager
import com.example.audio.WavGenerator
import com.example.model.CrossfaderCurve
import com.example.model.DeckId
import com.example.model.DeckState
import com.example.model.HotCue
import com.example.model.SideTab
import com.example.model.SlipmatStyle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

class DjMixerViewModel(application: Application) : AndroidViewModel(application) {

  val audioEngine = DjAudioEngine(application.applicationContext)
  val recordingManager = RecordingManager(application.applicationContext)

  private val _deckA = MutableStateFlow(DeckState(deckId = DeckId.DECK_A))
  val deckA: StateFlow<DeckState> = _deckA.asStateFlow()

  private val _deckB = MutableStateFlow(DeckState(deckId = DeckId.DECK_B))
  val deckB: StateFlow<DeckState> = _deckB.asStateFlow()

  private val _crossfader = MutableStateFlow(0.5f)
  val crossfader: StateFlow<Float> = _crossfader.asStateFlow()

  private val _crossfaderCurve = MutableStateFlow(CrossfaderCurve.EQUAL_POWER)
  val crossfaderCurve: StateFlow<CrossfaderCurve> = _crossfaderCurve.asStateFlow()

  private val _currentSkin = MutableStateFlow(com.example.model.DjSkin.CYBER_NEON)
  val currentSkin: StateFlow<com.example.model.DjSkin> = _currentSkin.asStateFlow()

  private val _slipmatStyle = MutableStateFlow(SlipmatStyle.RAINBOW_TARGET)
  val slipmatStyle: StateFlow<SlipmatStyle> = _slipmatStyle.asStateFlow()

  fun setSkin(skin: com.example.model.DjSkin) {
    _currentSkin.value = skin
  }

  fun toggleSkin() {
    val allSkins = com.example.model.DjSkin.values()
    val nextIndex = (allSkins.indexOf(_currentSkin.value) + 1) % allSkins.size
    _currentSkin.value = allSkins[nextIndex]
  }

  private val _isSamplerOpen = MutableStateFlow(false)
  val isSamplerOpen: StateFlow<Boolean> = _isSamplerOpen.asStateFlow()

  private val _isMenuOpen = MutableStateFlow(false)
  val isMenuOpen: StateFlow<Boolean> = _isMenuOpen.asStateFlow()

  private val _activeSamplerPad = MutableStateFlow<Int?>(null)
  val activeSamplerPad: StateFlow<Int?> = _activeSamplerPad.asStateFlow()

  // Track Browser Modal
  private val _browserTargetDeck = MutableStateFlow<DeckId?>(null)
  val browserTargetDeck: StateFlow<DeckId?> = _browserTargetDeck.asStateFlow()

  // Live Mix Recording State
  private val _isRecording = MutableStateFlow(false)
  val isRecording: StateFlow<Boolean> = _isRecording.asStateFlow()

  private val _recordingElapsedMs = MutableStateFlow(0L)
  val recordingElapsedMs: StateFlow<Long> = _recordingElapsedMs.asStateFlow()

  private val _savedRecordings = MutableStateFlow<List<File>>(emptyList())
  val savedRecordings: StateFlow<List<File>> = _savedRecordings.asStateFlow()

  var demoTrackAFile: File? = null
    private set
  var demoTrackBFile: File? = null
    private set

  // BPM Tap Tempo lists
  private val tapTimesA = mutableListOf<Long>()
  private val tapTimesB = mutableListOf<Long>()

  // Track touch scratch state
  private var scratchLastAngleA: Float? = null
  private var scratchLastAngleB: Float? = null
  private var wasPlayingBeforeScratchA = false
  private var wasPlayingBeforeScratchB = false

  init {
    _savedRecordings.value = recordingManager.getSavedRecordings()

    viewModelScope.launch(Dispatchers.IO) {
      val dir = File(getApplication<Application>().cacheDir, "dj_samples").apply { mkdirs() }
      val fileA = File(dir, "demo_track_a.wav")
      val fileB = File(dir, "demo_track_b.wav")
      demoTrackAFile = fileA
      demoTrackBFile = fileB

      audioEngine.initializeDemoTracks { _, _ ->
        val durA = audioEngine.getDuration(DeckId.DECK_A)
        val durB = audioEngine.getDuration(DeckId.DECK_B)
        _deckA.update { it.copy(durationMs = if (durA > 0) durA else it.durationMs) }
        _deckB.update { it.copy(durationMs = if (durB > 0) durB else it.durationMs) }
      }
    }

    startPlaybackSyncLoop()
  }

  private fun startPlaybackSyncLoop() {
    viewModelScope.launch(Dispatchers.Main) {
      var lastTickTime = System.currentTimeMillis()
      while (true) {
        val now = System.currentTimeMillis()
        val dt = (now - lastTickTime).coerceIn(1, 50)
        lastTickTime = now

        updateDeckPlayback(DeckId.DECK_A, dt)
        updateDeckPlayback(DeckId.DECK_B, dt)

        if (_isRecording.value) {
          _recordingElapsedMs.value = recordingManager.getRecordingElapsedMs()
        }

        delay(16) // ~60 FPS
      }
    }
  }

  private fun updateDeckPlayback(deckId: DeckId, dtMs: Long) {
    val isDeckA = deckId == DeckId.DECK_A
    val currentFlow = if (isDeckA) _deckA else _deckB
    val state = currentFlow.value

    if (state.isScratching) {
      return
    }

    val isPlaying = audioEngine.isPlaying(deckId)
    val actualPos = audioEngine.getPosition(deckId)
    val actualDur = audioEngine.getDuration(deckId)

    var newPos = actualPos
    var newAngle = state.vinylAngleDegrees

    if (isPlaying) {
      val effectiveSpeed = (1.0f + state.pitchPercent / 100f)
      val degreesPerMs = (33.333f * 360f / 60000f) * effectiveSpeed
      newAngle = (state.vinylAngleDegrees + degreesPerMs * dtMs) % 360f

      // Check loop
      if (state.isLoopActive && state.loopEndMs > state.loopStartMs) {
        if (actualPos >= state.loopEndMs) {
          audioEngine.seekTo(deckId, state.loopStartMs)
          newPos = state.loopStartMs
        }
      }
    }

    val beatDurationMs = (60000.0 / state.bpm).toInt()
    val beatProgress = if (beatDurationMs > 0) (newPos % beatDurationMs).toFloat() / beatDurationMs else 0f
    val kickPulse = if (isPlaying && beatProgress < 0.25f) (1.0f - beatProgress / 0.25f) else 0.1f
    val targetVu = if (isPlaying) (state.channelVolume * (0.4f + 0.6f * kickPulse)) else 0f

    currentFlow.update {
      it.copy(
        isPlaying = isPlaying,
        positionMs = newPos,
        durationMs = if (actualDur > 0) actualDur else it.durationMs,
        vinylAngleDegrees = newAngle,
        vuLevel = targetVu
      )
    }
  }

  private var brakeJobA: kotlinx.coroutines.Job? = null
  private var brakeJobB: kotlinx.coroutines.Job? = null
  private var isBrakingA: Boolean = false
  private var isBrakingB: Boolean = false

  fun togglePlayPause(deckId: DeckId) {
    val isDeckA = deckId == DeckId.DECK_A
    val flow = if (isDeckA) _deckA else _deckB
    val currentlyPlaying = flow.value.isPlaying

    if (currentlyPlaying) {
      triggerVinylBrake(deckId)
    } else {
      triggerVinylStart(deckId)
    }
  }

  private fun triggerVinylBrake(deckId: DeckId) {
    val isDeckA = deckId == DeckId.DECK_A
    val flow = if (isDeckA) _deckA else _deckB

    if (isDeckA) {
      brakeJobA?.cancel()
      isBrakingA = true
    } else {
      brakeJobB?.cancel()
      isBrakingB = true
    }

    audioEngine.playVinylBrakeSound()

    val job = viewModelScope.launch {
      val totalSteps = 7
      val stepDelay = 50L // ~350ms smooth deceleration
      for (step in 1..totalSteps) {
        val t = step.toFloat() / totalSteps
        val speedDecel = ((1.0f - t * t) * 0.85f + 0.15f).coerceIn(0.15f, 1.0f)
        val volDecel = (1.0f - t * 0.85f).coerceIn(0.1f, 1.0f)

        audioEngine.setDeckSpeedMultiplier(deckId, speedDecel, flow.value.pitchPercent)
        audioEngine.setDeckVolumeMultiplier(deckId, volDecel)
        delay(stepDelay)
      }

      audioEngine.pause(deckId)
      audioEngine.setDeckSpeedMultiplier(deckId, 1.0f, flow.value.pitchPercent)
      audioEngine.setDeckVolumeMultiplier(deckId, 1.0f)

      if (isDeckA) isBrakingA = false else isBrakingB = false
      flow.update { it.copy(isPlaying = false) }
    }

    if (isDeckA) brakeJobA = job else brakeJobB = job
  }

  private fun triggerVinylStart(deckId: DeckId) {
    val isDeckA = deckId == DeckId.DECK_A
    val flow = if (isDeckA) _deckA else _deckB

    if (isDeckA) {
      brakeJobA?.cancel()
      isBrakingA = false
    } else {
      brakeJobB?.cancel()
      isBrakingB = false
    }

    audioEngine.setDeckVolumeMultiplier(deckId, 1.0f)
    audioEngine.play(deckId)
    flow.update { it.copy(isPlaying = true) }

    viewModelScope.launch {
      val steps = 4
      for (i in 1..steps) {
        val speed = 0.5f + (i.toFloat() / steps) * 0.5f
        audioEngine.setDeckSpeedMultiplier(deckId, speed, flow.value.pitchPercent)
        delay(35)
      }
      audioEngine.setDeckSpeedMultiplier(deckId, 1.0f, flow.value.pitchPercent)
    }
  }

  fun setCrossfader(value: Float) {
    val clamped = value.coerceIn(0f, 1f)
    _crossfader.value = clamped
    audioEngine.crossfaderPosition = clamped
    audioEngine.updateVolumes()
  }

  fun setCrossfaderCurve(curve: CrossfaderCurve) {
    _crossfaderCurve.value = curve
    audioEngine.crossfaderCurve = curve
    audioEngine.updateVolumes()
  }

  fun setSlipmatStyle(style: SlipmatStyle) {
    _slipmatStyle.value = style
  }

  fun setChannelVolume(deckId: DeckId, volume: Float) {
    val clamped = volume.coerceIn(0f, 1f)
    if (deckId == DeckId.DECK_A) {
      _deckA.update { it.copy(channelVolume = clamped) }
      audioEngine.volumeA = clamped
    } else {
      _deckB.update { it.copy(channelVolume = clamped) }
      audioEngine.volumeB = clamped
    }
    audioEngine.updateVolumes()
  }

  fun toggleCueHeadphone(deckId: DeckId) {
    if (deckId == DeckId.DECK_A) {
      _deckA.update { it.copy(cueHeadphone = !it.cueHeadphone) }
    } else {
      _deckB.update { it.copy(cueHeadphone = !it.cueHeadphone) }
    }
  }

  fun setPitchPercent(deckId: DeckId, percent: Float) {
    val clamped = percent.coerceIn(-16f, 16f)
    val flow = if (deckId == DeckId.DECK_A) _deckA else _deckB
    flow.update { it.copy(pitchPercent = clamped) }
    audioEngine.setPitch(deckId, clamped)
  }

  fun resetPitch(deckId: DeckId) {
    setPitchPercent(deckId, 0.0f)
  }

  fun nudgePitch(deckId: DeckId, delta: Float) {
    val flow = if (deckId == DeckId.DECK_A) _deckA else _deckB
    val current = flow.value.pitchPercent
    setPitchPercent(deckId, current + delta)
  }

  fun tapBpm(deckId: DeckId) {
    val now = System.currentTimeMillis()
    val tapList = if (deckId == DeckId.DECK_A) tapTimesA else tapTimesB
    tapList.removeAll { now - it > 2500 }
    tapList.add(now)

    if (tapList.size >= 3) {
      val intervals = mutableListOf<Long>()
      for (i in 1 until tapList.size) {
        intervals.add(tapList[i] - tapList[i - 1])
      }
      val avgIntervalMs = intervals.average()
      if (avgIntervalMs > 200 && avgIntervalMs < 1500) {
        val computedBpm = (60000.0 / avgIntervalMs).coerceIn(60.0, 200.0)
        val roundedBpm = (Math.round(computedBpm * 10.0) / 10.0)
        val flow = if (deckId == DeckId.DECK_A) _deckA else _deckB
        flow.update { it.copy(bpm = roundedBpm) }
      }
    }
  }

  fun syncDecks() {
    val targetBpm = _deckA.value.bpm
    val pitchNeeded = (((targetBpm / _deckB.value.bpm) - 1.0) * 100.0).toFloat().coerceIn(-16f, 16f)
    _deckB.update { it.copy(pitchPercent = pitchNeeded) }
    audioEngine.setPitch(DeckId.DECK_B, pitchNeeded)

    val beatDurationMsA = (60000.0 / targetBpm).toInt()
    if (beatDurationMsA > 0) {
      val phaseA = _deckA.value.positionMs % beatDurationMsA
      val currentPosB = _deckB.value.positionMs
      val currentPhaseB = currentPosB % beatDurationMsA
      val diff = phaseA - currentPhaseB
      val alignedPos = (currentPosB + diff).coerceAtLeast(0)
      audioEngine.seekTo(DeckId.DECK_B, alignedPos)
      _deckB.update { it.copy(positionMs = alignedPos) }
    }
  }

  fun cueSetOrJump(deckId: DeckId) {
    val flow = if (deckId == DeckId.DECK_A) _deckA else _deckB
    val state = flow.value
    if (state.isPlaying) {
      audioEngine.pause(deckId)
      audioEngine.seekTo(deckId, state.cuePositionMs)
      flow.update { it.copy(isPlaying = false, positionMs = state.cuePositionMs) }
    } else {
      val newCuePos = state.positionMs
      flow.update { it.copy(cuePositionMs = newCuePos) }
    }
  }

  fun toggleSideTab(deckId: DeckId, tab: SideTab) {
    val flow = if (deckId == DeckId.DECK_A) _deckA else _deckB
    flow.update {
      it.copy(activeTab = if (it.activeTab == tab) SideTab.NONE else tab)
    }
  }

  fun closeSideTab(deckId: DeckId) {
    val flow = if (deckId == DeckId.DECK_A) _deckA else _deckB
    flow.update { it.copy(activeTab = SideTab.NONE) }
  }

  // --- Hot Cues ---
  fun setHotCue(deckId: DeckId, index: Int) {
    val flow = if (deckId == DeckId.DECK_A) _deckA else _deckB
    val colors = listOf(0xFF00E5FF, 0xFFFF4081, 0xFFFFAB00, 0xFF00E676)
    val pos = flow.value.positionMs
    flow.update { state ->
      val updated = state.hotCues.filter { it.index != index }.toMutableList()
      updated.add(
        HotCue(
          index = index,
          positionMs = pos,
          label = "CUE ${index + 1}",
          colorHex = colors[index % colors.size]
        )
      )
      state.copy(hotCues = updated.sortedBy { it.index })
    }
  }

  fun jumpHotCue(deckId: DeckId, index: Int) {
    val flow = if (deckId == DeckId.DECK_A) _deckA else _deckB
    val cue = flow.value.hotCues.find { it.index == index }
    if (cue != null) {
      audioEngine.seekTo(deckId, cue.positionMs)
      flow.update { it.copy(positionMs = cue.positionMs) }
    } else {
      setHotCue(deckId, index)
    }
  }

  fun clearHotCue(deckId: DeckId, index: Int) {
    val flow = if (deckId == DeckId.DECK_A) _deckA else _deckB
    flow.update { state ->
      state.copy(hotCues = state.hotCues.filter { it.index != index })
    }
  }

  // --- Loop ---
  fun toggleLoop(deckId: DeckId, beats: Float) {
    val flow = if (deckId == DeckId.DECK_A) _deckA else _deckB
    val state = flow.value
    if (state.isLoopActive && state.loopBeats == beats) {
      flow.update { it.copy(isLoopActive = false) }
    } else {
      val beatDurationMs = (60000.0 / state.bpm)
      val loopLengthMs = (beatDurationMs * beats).toInt()
      val startMs = state.positionMs
      val endMs = min(state.durationMs, startMs + loopLengthMs)
      flow.update {
        it.copy(
          isLoopActive = true,
          loopBeats = beats,
          loopStartMs = startMs,
          loopEndMs = endMs
        )
      }
    }
  }

  // --- EQ ---
  fun setEq(deckId: DeckId, band: String, value: Float) {
    val flow = if (deckId == DeckId.DECK_A) _deckA else _deckB
    flow.update {
      when (band) {
        "HIGH" -> it.copy(eqHigh = value)
        "MID" -> it.copy(eqMid = value)
        "LOW" -> it.copy(eqLow = value)
        else -> it
      }
    }
  }

  fun toggleEqKill(deckId: DeckId, band: String) {
    val flow = if (deckId == DeckId.DECK_A) _deckA else _deckB
    flow.update {
      when (band) {
        "HIGH" -> it.copy(eqKillHigh = !it.eqKillHigh)
        "MID" -> it.copy(eqKillMid = !it.eqKillMid)
        "LOW" -> it.copy(eqKillLow = !it.eqKillLow)
        else -> it
      }
    }
  }

  // --- FX ---
  fun setFxPad(deckId: DeckId, x: Float, y: Float) {
    val flow = if (deckId == DeckId.DECK_A) _deckA else _deckB
    flow.update { it.copy(fxX = x.coerceIn(0f, 1f), fxY = y.coerceIn(0f, 1f)) }
  }

  fun toggleFx(deckId: DeckId) {
    val flow = if (deckId == DeckId.DECK_A) _deckA else _deckB
    flow.update { it.copy(fxEnabled = !it.fxEnabled) }
  }

  fun selectFxType(deckId: DeckId, type: String) {
    val flow = if (deckId == DeckId.DECK_A) _deckA else _deckB
    flow.update { it.copy(fxType = type) }
  }

  // --- Scratching Physics ---
  fun onVinylScratchStart(deckId: DeckId, initialAngleDeg: Float) {
    val isDeckA = deckId == DeckId.DECK_A
    val flow = if (isDeckA) _deckA else _deckB

    if (isDeckA) {
      wasPlayingBeforeScratchA = flow.value.isPlaying
      scratchLastAngleA = initialAngleDeg
    } else {
      wasPlayingBeforeScratchB = flow.value.isPlaying
      scratchLastAngleB = initialAngleDeg
    }

    audioEngine.pause(deckId)
    flow.update { it.copy(isScratching = true) }
  }

  fun onVinylScratchMove(deckId: DeckId, newAngleDeg: Float) {
    val isDeckA = deckId == DeckId.DECK_A
    val flow = if (isDeckA) _deckA else _deckB
    val lastAngle = if (isDeckA) scratchLastAngleA else scratchLastAngleB
    if (lastAngle == null) return

    var deltaDeg = newAngleDeg - lastAngle
    if (deltaDeg > 180f) deltaDeg -= 360f
    if (deltaDeg < -180f) deltaDeg += 360f

    if (isDeckA) scratchLastAngleA = newAngleDeg else scratchLastAngleB = newAngleDeg

    val state = flow.value
    val msDelta = (deltaDeg * (1800f / 360f)).toInt()
    val newPos = (state.positionMs + msDelta).coerceIn(0, state.durationMs)

    audioEngine.seekTo(deckId, newPos)
    flow.update {
      it.copy(
        positionMs = newPos,
        vinylAngleDegrees = (it.vinylAngleDegrees + deltaDeg) % 360f
      )
    }

    val isForward = deltaDeg >= 0f
    val absDelta = abs(deltaDeg)
    if (absDelta > 2.0f) {
      val velocity = (absDelta / 35f).coerceIn(0.1f, 2.5f)
      audioEngine.playScratchSound(velocity, isForward)
    }
  }

  fun onVinylScratchEnd(deckId: DeckId) {
    val isDeckA = deckId == DeckId.DECK_A
    val flow = if (isDeckA) _deckA else _deckB
    val shouldResume = if (isDeckA) wasPlayingBeforeScratchA else wasPlayingBeforeScratchB

    if (isDeckA) scratchLastAngleA = null else scratchLastAngleB = null
    flow.update { it.copy(isScratching = false) }

    if (shouldResume) {
      audioEngine.play(deckId)
      flow.update { it.copy(isPlaying = true) }
    }
  }

  // --- Sampler ---
  fun toggleSampler() {
    _isSamplerOpen.update { !it }
  }

  fun triggerSamplerPad(type: WavGenerator.SampleType, index: Int) {
    audioEngine.triggerSample(type)
    _activeSamplerPad.value = index
    viewModelScope.launch {
      delay(180)
      if (_activeSamplerPad.value == index) {
        _activeSamplerPad.value = null
      }
    }
  }

  // --- Track Browser ---
  fun openBrowser(deckId: DeckId) {
    _browserTargetDeck.value = deckId
  }

  fun closeBrowser() {
    _browserTargetDeck.value = null
  }

  // --- Live Mix Recording ---
  fun toggleRecording() {
    if (_isRecording.value) {
      recordingManager.stopRecording()
      _isRecording.value = false
      _recordingElapsedMs.value = 0L
      _savedRecordings.value = recordingManager.getSavedRecordings()
    } else {
      recordingManager.startRecording()
      _isRecording.value = true
    }
  }

  // --- Menu ---
  fun toggleMenu() {
    _isMenuOpen.update { !it }
  }

  // --- File loading from internal/external storage ---
  fun onAudioFilePicked(deckId: DeckId, uri: Uri) {
    val result = audioEngine.setupDeckPlayer(deckId, uri)
    if (result != null) {
      val (duration, trackInfo) = result
      val flow = if (deckId == DeckId.DECK_A) _deckA else _deckB
      flow.update {
        it.copy(
          title = trackInfo.title,
          artist = trackInfo.artist,
          durationMs = duration,
          positionMs = 0,
          isPlaying = false,
          hotCues = emptyList(),
          isLoopActive = false
        )
      }
    }
  }

  override fun onCleared() {
    super.onCleared()
    if (_isRecording.value) {
      recordingManager.stopRecording()
    }
    audioEngine.release()
  }
}
