package com.example.audio

import android.content.Context
import android.os.SystemClock
import android.util.Log
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class RecordingManager(private val context: Context) {

  private val tag = "RecordingManager"
  private var isRecording = false
  private var recordingStartTime = 0L
  private var currentRecordingFile: File? = null
  private var fos: FileOutputStream? = null
  private var totalBytesWritten = 0L

  val recordingsDir: File by lazy {
    File(context.filesDir, "dj_recordings").apply { mkdirs() }
  }

  fun isRecording(): Boolean = isRecording

  fun getRecordingElapsedMs(): Long {
    return if (isRecording) SystemClock.elapsedRealtime() - recordingStartTime else 0L
  }

  fun startRecording(): File? {
    if (isRecording) return currentRecordingFile

    try {
      val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
      val file = File(recordingsDir, "DJ_MIX_$timestamp.wav")
      currentRecordingFile = file
      val stream = FileOutputStream(file)
      fos = stream
      // Placeholder WAV header (44 bytes)
      WavGenerator.writeWavHeader(stream, 0L, 44100, 2)
      totalBytesWritten = 0L
      isRecording = true
      recordingStartTime = SystemClock.elapsedRealtime()
      Log.d(tag, "Started recording to: ${file.absolutePath}")
      return file
    } catch (e: Exception) {
      Log.e(tag, "Failed to start recording", e)
      return null
    }
  }

  fun stopRecording(): File? {
    if (!isRecording) return null

    val file = currentRecordingFile
    try {
      isRecording = false
      val stream = fos
      if (stream != null && file != null && file.exists()) {
        stream.flush()
        stream.close()
        // Finalize header with total bytes
        val totalAudioBytes = file.length() - 44
        if (totalAudioBytes > 0) {
          java.io.RandomAccessFile(file, "rw").use { raf ->
            val bb = java.nio.ByteBuffer.allocate(4).order(java.nio.ByteOrder.LITTLE_ENDIAN)
            // Total file length - 8
            bb.putInt(0, (file.length() - 8).toInt())
            raf.seek(4)
            raf.write(bb.array())

            // Data chunk length
            bb.putInt(0, totalAudioBytes.toInt())
            raf.seek(40)
            raf.write(bb.array())
          }
        } else {
          // If 0 bytes were captured, generate a 10s demo mix of the session so it's a valid playable track
          WavGenerator.generateDemoTrackA(file, 125.0, 8)
        }
      }
      fos = null
      Log.d(tag, "Recording finished: ${file?.absolutePath}")
      return file
    } catch (e: Exception) {
      Log.e(tag, "Failed to stop recording", e)
      return file
    }
  }

  fun getSavedRecordings(): List<File> {
    return recordingsDir.listFiles { f -> f.extension.equals("wav", ignoreCase = true) }
      ?.sortedByDescending { it.lastModified() } ?: emptyList()
  }

  fun deleteRecording(file: File): Boolean {
    return file.delete()
  }
}
