package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.media.PlaybackParams
import android.media.SoundPool
import android.net.Uri
import android.util.Log
import com.example.model.CrossfaderCurve
import com.example.model.DeckId
import java.io.File
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

class DjAudioEngine(private val context: Context) {

  private val tag = "DjAudioEngine"

  private var playerA: MediaPlayer? = null
  private var playerB: MediaPlayer? = null

  private var soundPool: SoundPool? = null
  private val sampleSoundIds = mutableMapOf<WavGenerator.SampleType, Int>()
  private var scratchSoundId: Int = 0
  private var scratchForwardSoundId: Int = 0
  private var scratchBackwardSoundId: Int = 0
  private var vinylBrakeSoundId: Int = 0

  private var speedMultiplierA: Float = 1.0f
  private var speedMultiplierB: Float = 1.0f
  private var volumeMultiplierA: Float = 1.0f
  private var volumeMultiplierB: Float = 1.0f

  var crossfaderPosition: Float = 0.5f // 0.0 (Deck A) to 1.0 (Deck B)
  var crossfaderCurve: CrossfaderCurve = CrossfaderCurve.EQUAL_POWER

  var volumeA: Float = 0.85f
  var volumeB: Float = 0.85f

  var isMutedA: Boolean = false
  var isMutedB: Boolean = false

  init {
    initSoundPool()
  }

  private fun initSoundPool() {
    val audioAttributes = AudioAttributes.Builder()
      .setUsage(AudioAttributes.USAGE_MEDIA)
      .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
      .build()

    soundPool = SoundPool.Builder()
      .setMaxStreams(16)
      .setAudioAttributes(audioAttributes)
      .build()
  }

  fun initializeDemoTracks(onComplete: (trackAPath: String, trackBPath: String) -> Unit) {
    try {
      val dir = File(context.cacheDir, "dj_samples").apply { mkdirs() }
      val fileA = File(dir, "demo_track_a.wav")
      val fileB = File(dir, "demo_track_b.wav")

      WavGenerator.generateDemoTrackA(fileA)
      WavGenerator.generateDemoTrackB(fileB)

      // Generate sampler sound effects
      for (type in WavGenerator.SampleType.values()) {
        val sFile = File(dir, "sample_${type.name.lowercase()}.wav")
        WavGenerator.generateSample(sFile, type)
        val soundId = soundPool?.load(sFile.absolutePath, 1) ?: 0
        sampleSoundIds[type] = soundId
        when (type) {
          WavGenerator.SampleType.SCRATCH -> scratchSoundId = soundId
          WavGenerator.SampleType.SCRATCH_FORWARD -> scratchForwardSoundId = soundId
          WavGenerator.SampleType.SCRATCH_BACKWARD -> scratchBackwardSoundId = soundId
          WavGenerator.SampleType.VINYL_BRAKE -> vinylBrakeSoundId = soundId
          else -> {}
        }
      }

      setupDeckPlayer(DeckId.DECK_A, Uri.fromFile(fileA))
      setupDeckPlayer(DeckId.DECK_B, Uri.fromFile(fileB))

      updateVolumes()
      onComplete(fileA.absolutePath, fileB.absolutePath)
    } catch (e: Exception) {
      Log.e(tag, "Failed to initialize demo tracks", e)
    }
  }

  fun setupDeckPlayer(deckId: DeckId, uri: Uri): Pair<Int, TrackInfo>? {
    try {
      val existing = if (deckId == DeckId.DECK_A) playerA else playerB
      existing?.stop()
      existing?.release()

      val player = MediaPlayer().apply {
        setAudioAttributes(
          AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build()
        )
        if (uri.scheme == "content") {
          val pfd = context.contentResolver.openFileDescriptor(uri, "r")
          if (pfd != null) {
            setDataSource(pfd.fileDescriptor)
            pfd.close()
          } else {
            setDataSource(context, uri)
          }
        } else {
          setDataSource(context, uri)
        }
        isLooping = true
        prepare()
      }

      if (deckId == DeckId.DECK_A) {
        playerA = player
      } else {
        playerB = player
      }

      updateVolumes()

      val duration = player.duration
      val trackInfo = extractMetadata(uri)
      return Pair(duration, trackInfo)
    } catch (e: Exception) {
      Log.e(tag, "Error loading audio for $deckId: $uri", e)
      return null
    }
  }

  data class TrackInfo(val title: String, val artist: String)

  private fun extractMetadata(uri: Uri): TrackInfo {
    return try {
      val retriever = MediaMetadataRetriever()
      if (uri.scheme == "content") {
        val pfd = context.contentResolver.openFileDescriptor(uri, "r")
        if (pfd != null) {
          retriever.setDataSource(pfd.fileDescriptor)
          pfd.close()
        } else {
          retriever.setDataSource(context, uri)
        }
      } else {
        retriever.setDataSource(context, uri)
      }
      val title = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
      val artist = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)
      retriever.release()

      val cleanTitle = if (!title.isNullOrBlank()) title else uri.lastPathSegment ?: "Local Track"
      val cleanArtist = if (!artist.isNullOrBlank()) artist else "Unknown Artist"
      TrackInfo(cleanTitle, cleanArtist)
    } catch (e: Exception) {
      TrackInfo(uri.lastPathSegment ?: "Local Track", "Device Storage")
    }
  }

  fun play(deckId: DeckId) {
    val player = if (deckId == DeckId.DECK_A) playerA else playerB
    try {
      if (player?.isPlaying == false) {
        player.start()
      }
    } catch (e: Exception) {
      Log.e(tag, "Error playing $deckId", e)
    }
  }

  fun pause(deckId: DeckId) {
    val player = if (deckId == DeckId.DECK_A) playerA else playerB
    try {
      if (player?.isPlaying == true) {
        player.pause()
      }
    } catch (e: Exception) {
      Log.e(tag, "Error pausing $deckId", e)
    }
  }

  fun seekTo(deckId: DeckId, positionMs: Int) {
    val player = if (deckId == DeckId.DECK_A) playerA else playerB
    try {
      player?.seekTo(positionMs.coerceAtLeast(0))
    } catch (e: Exception) {
      Log.e(tag, "Error seeking $deckId", e)
    }
  }

  fun setPitch(deckId: DeckId, pitchPercent: Float) {
    val player = (if (deckId == DeckId.DECK_A) playerA else playerB) ?: return
    try {
      val baseSpeed = (1.0f + pitchPercent / 100f).coerceIn(0.5f, 2.0f)
      val speedMult = if (deckId == DeckId.DECK_A) speedMultiplierA else speedMultiplierB
      val finalSpeed = (baseSpeed * speedMult).coerceIn(0.1f, 2.5f)
      val params = player.playbackParams
      params.speed = finalSpeed
      params.pitch = finalSpeed
      player.playbackParams = params
    } catch (e: Exception) {
      Log.w(tag, "Could not set playbackParams on $deckId: ${e.message}")
    }
  }

  fun setDeckSpeedMultiplier(deckId: DeckId, multiplier: Float, pitchPercent: Float = 0f) {
    if (deckId == DeckId.DECK_A) speedMultiplierA = multiplier else speedMultiplierB = multiplier
    setPitch(deckId, pitchPercent)
  }

  fun setDeckVolumeMultiplier(deckId: DeckId, multiplier: Float) {
    if (deckId == DeckId.DECK_A) volumeMultiplierA = multiplier else volumeMultiplierB = multiplier
    updateVolumes()
  }

  fun updateVolumes() {
    val (gainA, gainB) = calculateCrossfaderGains(crossfaderPosition, crossfaderCurve)

    val finalVolA = if (isMutedA) 0f else (volumeA * gainA * volumeMultiplierA).coerceIn(0f, 1f)
    val finalVolB = if (isMutedB) 0f else (volumeB * gainB * volumeMultiplierB).coerceIn(0f, 1f)

    try {
      playerA?.setVolume(finalVolA, finalVolA)
    } catch (e: Exception) {
      // Ignored
    }

    try {
      playerB?.setVolume(finalVolB, finalVolB)
    } catch (e: Exception) {
      // Ignored
    }
  }

  private fun calculateCrossfaderGains(x: Float, curve: CrossfaderCurve): Pair<Float, Float> {
    val clamped = x.coerceIn(0f, 1f)
    return when (curve) {
      CrossfaderCurve.EQUAL_POWER -> {
        // Equal-power constant loudness curve:
        // cos(x * PI/2) and sin(x * PI/2)
        val angle = clamped * (PI / 2.0)
        Pair(cos(angle).toFloat(), sin(angle).toFloat())
      }
      CrossfaderCurve.LINEAR -> {
        Pair(1f - clamped, clamped)
      }
      CrossfaderCurve.CUT_SCRATCH -> {
        val a = if (clamped > 0.92f) (1f - (clamped - 0.92f) / 0.08f) else 1f
        val b = if (clamped < 0.08f) (clamped / 0.08f) else 1f
        Pair(a.coerceIn(0f, 1f), b.coerceIn(0f, 1f))
      }
    }
  }

  fun playScratchSound(velocity: Float, isForward: Boolean = true) {
    val soundId = if (isForward) {
      if (scratchForwardSoundId != 0) scratchForwardSoundId else scratchSoundId
    } else {
      if (scratchBackwardSoundId != 0) scratchBackwardSoundId else scratchSoundId
    }
    if (soundId != 0 && soundPool != null) {
      val rate = (0.65f + abs(velocity) * 0.85f).coerceIn(0.45f, 2.2f)
      val vol = (0.35f + abs(velocity) * 0.65f).coerceIn(0.2f, 1.0f)
      soundPool?.play(soundId, vol, vol, 1, 0, rate)
    }
  }

  fun playVinylBrakeSound() {
    val soundId = if (vinylBrakeSoundId != 0) vinylBrakeSoundId else scratchSoundId
    if (soundId != 0 && soundPool != null) {
      soundPool?.play(soundId, 0.8f, 0.8f, 1, 0, 1.0f)
    }
  }

  fun triggerSample(type: WavGenerator.SampleType) {
    val soundId = sampleSoundIds[type] ?: return
    soundPool?.play(soundId, 1.0f, 1.0f, 1, 0, 1.0f)
  }

  fun getPosition(deckId: DeckId): Int {
    return try {
      val player = if (deckId == DeckId.DECK_A) playerA else playerB
      player?.currentPosition ?: 0
    } catch (e: Exception) {
      0
    }
  }

  fun getDuration(deckId: DeckId): Int {
    return try {
      val player = if (deckId == DeckId.DECK_A) playerA else playerB
      player?.duration ?: 0
    } catch (e: Exception) {
      0
    }
  }

  fun isPlaying(deckId: DeckId): Boolean {
    return try {
      val player = if (deckId == DeckId.DECK_A) playerA else playerB
      player?.isPlaying == true
    } catch (e: Exception) {
      false
    }
  }

  fun release() {
    try {
      playerA?.stop()
      playerA?.release()
      playerA = null

      playerB?.stop()
      playerB?.release()
      playerB = null

      soundPool?.release()
      soundPool = null
    } catch (e: Exception) {
      Log.e(tag, "Error releasing engine resources", e)
    }
  }
}
