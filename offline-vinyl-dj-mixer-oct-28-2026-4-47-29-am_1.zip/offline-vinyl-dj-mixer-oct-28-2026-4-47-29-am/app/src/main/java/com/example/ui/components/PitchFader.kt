package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DeckId
import com.example.ui.theme.CarbonBlack
import com.example.ui.theme.LedGreen
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPink
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import java.util.Locale

@Composable
fun VerticalPitchFader(
  deckId: DeckId,
  pitchPercent: Float, // -16f to +16f
  customAccentColor: Color? = null,
  onPitchChange: (Float) -> Unit,
  onReset: () -> Unit,
  modifier: Modifier = Modifier
) {
  val isDeckA = deckId == DeckId.DECK_A
  val accentColor = customAccentColor ?: (if (isDeckA) NeonCyan else NeonPink)
  val tagPrefix = if (isDeckA) "deck_a_" else "deck_b_"

  // Map pitch (-16 .. +16) to normalized 0.0 (bottom, -16%) to 1.0 (top, +16%)
  val maxRange = 16f
  val normalized = ((pitchPercent + maxRange) / (maxRange * 2f)).coerceIn(0f, 1f)
  val isZero = kotlin.math.abs(pitchPercent) < 0.1f

  Column(
    modifier = modifier
      .width(36.dp)
      .fillMaxHeight()
      .padding(vertical = 4.dp, horizontal = 2.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.SpaceBetween
  ) {
    // Current Pitch readout badge (tap to reset to 0%)
    Box(
      modifier = Modifier
        .clip(RoundedCornerShape(4.dp))
        .background(if (isZero) LedGreen.copy(alpha = 0.2f) else accentColor.copy(alpha = 0.2f))
        .border(
          width = 1.dp,
          color = if (isZero) LedGreen else accentColor,
          shape = RoundedCornerShape(4.dp)
        )
        .clickable { onReset() }
        .testTag("${tagPrefix}pitch_badge")
        .padding(horizontal = 3.dp, vertical = 2.dp),
      contentAlignment = Alignment.Center
    ) {
      Text(
        text = String.format(Locale.US, "%+.1f%%", pitchPercent),
        color = if (isZero) LedGreen else accentColor,
        fontSize = 8.sp,
        fontWeight = FontWeight.Black,
        fontFamily = FontFamily.Monospace
      )
    }

    Spacer(modifier = Modifier.height(2.dp))

    // Vertical Track & Physical Fader Cap
    BoxWithConstraints(
      modifier = Modifier
        .fillMaxWidth()
        .weight(1f),
      contentAlignment = Alignment.Center
    ) {
      Box(
        modifier = Modifier
          .fillMaxSize()
          .pointerInput(Unit) {
            detectDragGestures { change, _ ->
              change.consume()
              // Invert Y: top is 1.0 (+16%), bottom is 0.0 (-16%)
              val frac = 1.0f - (change.position.y / size.height).coerceIn(0f, 1f)
              val newPitch = (frac * (maxRange * 2f)) - maxRange
              onPitchChange(newPitch)
            }
          }
          .testTag("${tagPrefix}pitch_fader"),
        contentAlignment = Alignment.BottomCenter
      ) {
        // Center Scale Ticks (+16, +8, 0, -8, -16)
        Column(
          modifier = Modifier
            .fillMaxHeight()
            .align(Alignment.CenterStart),
          verticalArrangement = Arrangement.SpaceBetween
        ) {
          Text("+", color = TextMuted, fontSize = 7.sp, fontFamily = FontFamily.Monospace)
          Text("-", color = TextMuted, fontSize = 7.sp, fontFamily = FontFamily.Monospace)
        }

        // Fader Track Slot
        Box(
          modifier = Modifier
            .width(5.dp)
            .fillMaxHeight()
            .clip(RoundedCornerShape(2.5.dp))
            .background(Color(0xFF0C0E14))
            .border(0.8.dp, Color(0xFF262C3A), RoundedCornerShape(2.5.dp))
            .align(Alignment.Center)
        ) {
          // Center 0% Detent line
          Box(
            modifier = Modifier
              .align(Alignment.Center)
              .width(5.dp)
              .height(2.dp)
              .background(if (isZero) LedGreen else Color(0xFF4A5568))
          )
        }

        // Fader Knob Cap
        Box(
          modifier = Modifier
            .fillMaxHeight()
            .fillMaxWidth()
        ) {
          Box(
            modifier = Modifier
              .align(Alignment.BottomCenter)
              .fillMaxHeight(normalized)
          ) {
            Box(
              modifier = Modifier
                .align(Alignment.TopCenter)
                .size(width = 24.dp, height = 16.dp)
                .clip(RoundedCornerShape(3.dp))
                .background(
                  Brush.verticalGradient(
                    colors = listOf(Color(0xFF64748B), Color(0xFF334155), Color(0xFF1E293B))
                  )
                )
                .border(1.dp, Color(0xFF94A3B8), RoundedCornerShape(3.dp))
            ) {
              // Center knurl
              Box(
                modifier = Modifier
                  .align(Alignment.Center)
                  .width(16.dp)
                  .height(1.5.dp)
                  .background(if (isZero) LedGreen else accentColor)
              )
            }
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(2.dp))

    // 0% Reset button
    Box(
      modifier = Modifier
        .clip(RoundedCornerShape(3.dp))
        .background(Color(0xFF151922))
        .border(1.dp, Color(0xFF282F40), RoundedCornerShape(3.dp))
        .clickable { onReset() }
        .testTag("${tagPrefix}pitch_reset")
        .padding(horizontal = 4.dp, vertical = 2.dp),
      contentAlignment = Alignment.Center
    ) {
      Text(
        text = "RESET",
        color = TextMuted,
        fontSize = 7.sp,
        fontWeight = FontWeight.Bold,
        fontFamily = FontFamily.Monospace
      )
    }
  }
}
