package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DjDarkColorScheme = darkColorScheme(
  primary = NeonCyan,
  onPrimary = CarbonBlack,
  primaryContainer = NeonCyanContainer,
  onPrimaryContainer = NeonCyanGlow,
  secondary = NeonPink,
  onSecondary = CarbonBlack,
  secondaryContainer = NeonPinkContainer,
  onSecondaryContainer = NeonPinkGlow,
  tertiary = LedGreen,
  background = CarbonBlack,
  onBackground = TextWhite,
  surface = SurfaceDark,
  onSurface = TextWhite,
  surfaceVariant = SurfaceElevated,
  onSurfaceVariant = TextMuted,
  outline = BorderDark
)

@Composable
fun MyApplicationTheme(
  content: @Composable () -> Unit
) {
  MaterialTheme(
    colorScheme = DjDarkColorScheme,
    typography = Typography,
    content = content
  )
}
