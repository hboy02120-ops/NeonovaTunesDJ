package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.GridOn
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DeckState
import com.example.ui.theme.BorderDark
import com.example.ui.theme.CarbonBlack
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonCyanGlow
import com.example.ui.theme.NeonPink
import com.example.ui.theme.NeonPinkGlow
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite

@Composable
fun BottomConsole(
  deckA: DeckState,
  deckB: DeckState,
  deckAColor: Color = NeonCyan,
  deckAGlow: Color = NeonCyanGlow,
  deckBColor: Color = NeonPink,
  deckBGlow: Color = NeonPinkGlow,
  crossfader: Float,
  onPlayPauseA: () -> Unit,
  onPlayPauseB: () -> Unit,
  onCueSetA: () -> Unit,
  onCueSetB: () -> Unit,
  onNudgeA: (Float) -> Unit,
  onNudgeB: (Float) -> Unit,
  onSamplerToggle: () -> Unit,
  onCrossfaderChange: (Float) -> Unit,
  modifier: Modifier = Modifier
) {
  Row(
    modifier = modifier
      .fillMaxWidth()
      .height(64.dp)
      .background(CarbonBlack)
      .border(1.dp, Color(0xFF1E222D))
      .padding(horizontal = 8.dp, vertical = 4.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    // 1. Deck A Bottom Controls (Play/Pause, SET/CUE, SAMPLER, Nudge)
    DeckPlaybackGroup(
      state = deckA,
      accentColor = deckAColor,
      glowColor = deckAGlow,
      isLeft = true,
      onPlayPause = onPlayPauseA,
      onCueSet = onCueSetA,
      onNudge = onNudgeA,
      onSamplerClick = onSamplerToggle,
      modifier = Modifier.weight(1.4f)
    )

    Spacer(modifier = Modifier.width(6.dp))

    // 2. Compact Horizontal Equal-Power Crossfader Console
    HorizontalCrossfader(
      crossfader = crossfader,
      deckAColor = deckAColor,
      deckBColor = deckBColor,
      onCrossfaderChange = onCrossfaderChange,
      modifier = Modifier
        .weight(1.0f)
        .fillMaxHeight()
    )

    Spacer(modifier = Modifier.width(6.dp))

    // 3. Deck B Bottom Controls (Sampler, SET/CUE, Play/Pause, Nudge)
    DeckPlaybackGroup(
      state = deckB,
      accentColor = deckBColor,
      glowColor = deckBGlow,
      isLeft = false,
      onPlayPause = onPlayPauseB,
      onCueSet = onCueSetB,
      onNudge = onNudgeB,
      onSamplerClick = onSamplerToggle,
      modifier = Modifier.weight(1.4f)
    )
  }
}

@Composable
private fun DeckPlaybackGroup(
  state: DeckState,
  accentColor: Color,
  glowColor: Color,
  isLeft: Boolean,
  onPlayPause: () -> Unit,
  onCueSet: () -> Unit,
  onNudge: (Float) -> Unit,
  onSamplerClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  val tagPrefix = if (isLeft) "deck_a_" else "deck_b_"

  Row(
    modifier = modifier
      .fillMaxHeight()
      .clip(RoundedCornerShape(8.dp))
      .background(Color(0xFF11141B))
      .border(1.dp, Color(0xFF222735), RoundedCornerShape(8.dp))
      .padding(horizontal = 6.dp, vertical = 4.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = if (isLeft) Arrangement.Start else Arrangement.End
  ) {
    if (isLeft) {
      // Glow Play/Pause Button
      PlayPauseButton(
        isPlaying = state.isPlaying,
        accentColor = accentColor,
        glowColor = glowColor,
        onClick = onPlayPause,
        testTag = "${tagPrefix}play_pause_button"
      )

      Spacer(modifier = Modifier.width(6.dp))

      // SET / CUE Button
      TactileButton(
        label = "SET",
        subLabel = "CUE",
        onClick = onCueSet,
        testTag = "${tagPrefix}cue_button"
      )

      Spacer(modifier = Modifier.width(6.dp))

      // SAMPLER trigger
      TactileButton(
        label = "SAMPLER",
        subLabel = "PADS",
        onClick = onSamplerClick,
        testTag = "${tagPrefix}sampler_button"
      )

      Spacer(modifier = Modifier.width(6.dp))

      // Pitch Nudge (- / +)
      PitchNudgeButtons(onNudge = onNudge, tagPrefix = tagPrefix)
    } else {
      // Pitch Nudge (- / +)
      PitchNudgeButtons(onNudge = onNudge, tagPrefix = tagPrefix)

      Spacer(modifier = Modifier.width(6.dp))

      // SAMPLER trigger
      TactileButton(
        label = "SAMPLER",
        subLabel = "PADS",
        onClick = onSamplerClick,
        testTag = "${tagPrefix}sampler_button"
      )

      Spacer(modifier = Modifier.width(6.dp))

      // SET / CUE Button
      TactileButton(
        label = "SET",
        subLabel = "CUE",
        onClick = onCueSet,
        testTag = "${tagPrefix}cue_button"
      )

      Spacer(modifier = Modifier.width(6.dp))

      // Glow Play/Pause Button
      PlayPauseButton(
        isPlaying = state.isPlaying,
        accentColor = accentColor,
        glowColor = glowColor,
        onClick = onPlayPause,
        testTag = "${tagPrefix}play_pause_button"
      )
    }
  }
}

@Composable
private fun PlayPauseButton(
  isPlaying: Boolean,
  accentColor: Color,
  glowColor: Color,
  onClick: () -> Unit,
  testTag: String
) {
  Box(
    modifier = Modifier
      .size(46.dp)
      .clip(CircleShape)
      .background(
        if (isPlaying) Brush.radialGradient(
          colors = listOf(accentColor, accentColor.copy(alpha = 0.8f), Color(0xFF0D1B22))
        )
        else Brush.radialGradient(
          colors = listOf(Color(0xFF262C3A), Color(0xFF141822))
        )
      )
      .border(
        width = 2.dp,
        color = if (isPlaying) glowColor else Color(0xFF3E475A),
        shape = CircleShape
      )
      .clickable { onClick() }
      .testTag(testTag),
    contentAlignment = Alignment.Center
  ) {
    Icon(
      imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
      contentDescription = if (isPlaying) "Pause" else "Play",
      tint = if (isPlaying) CarbonBlack else TextWhite,
      modifier = Modifier.size(24.dp)
    )
  }
}

@Composable
private fun TactileButton(
  label: String,
  subLabel: String,
  onClick: () -> Unit,
  testTag: String
) {
  Box(
    modifier = Modifier
      .size(width = 44.dp, height = 40.dp)
      .clip(RoundedCornerShape(6.dp))
      .background(
        Brush.verticalGradient(
          colors = listOf(Color(0xFF2B313F), Color(0xFF1A1D27))
        )
      )
      .border(1.dp, Color(0xFF3E4658), RoundedCornerShape(6.dp))
      .clickable { onClick() }
      .testTag(testTag),
    contentAlignment = Alignment.Center
  ) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
      Text(
        text = label,
        color = TextWhite,
        fontSize = 8.5.sp,
        fontWeight = FontWeight.ExtraBold,
        fontFamily = FontFamily.Monospace
      )
      Text(
        text = subLabel,
        color = TextMuted,
        fontSize = 7.sp,
        fontFamily = FontFamily.Monospace
      )
    }
  }
}

@Composable
private fun PitchNudgeButtons(
  onNudge: (Float) -> Unit,
  tagPrefix: String
) {
  Row(verticalAlignment = Alignment.CenterVertically) {
    Box(
      modifier = Modifier
        .size(width = 24.dp, height = 36.dp)
        .clip(RoundedCornerShape(4.dp))
        .background(Color(0xFF1A1D27))
        .border(1.dp, Color(0xFF2E3545), RoundedCornerShape(4.dp))
        .clickable { onNudge(-0.5f) }
        .testTag("${tagPrefix}nudge_minus"),
      contentAlignment = Alignment.Center
    ) {
      Icon(
        imageVector = Icons.Default.Remove,
        contentDescription = "Nudge Minus",
        tint = TextMuted,
        modifier = Modifier.size(14.dp)
      )
    }
    Spacer(modifier = Modifier.width(2.dp))
    Box(
      modifier = Modifier
        .size(width = 24.dp, height = 36.dp)
        .clip(RoundedCornerShape(4.dp))
        .background(Color(0xFF1A1D27))
        .border(1.dp, Color(0xFF2E3545), RoundedCornerShape(4.dp))
        .clickable { onNudge(0.5f) }
        .testTag("${tagPrefix}nudge_plus"),
      contentAlignment = Alignment.Center
    ) {
      Icon(
        imageVector = Icons.Default.Add,
        contentDescription = "Nudge Plus",
        tint = TextMuted,
        modifier = Modifier.size(14.dp)
      )
    }
  }
}

@Composable
private fun HorizontalCrossfader(
  crossfader: Float,
  deckAColor: Color = NeonCyan,
  deckBColor: Color = NeonPink,
  onCrossfaderChange: (Float) -> Unit,
  modifier: Modifier = Modifier
) {
  BoxWithConstraints(
    modifier = modifier
      .clip(RoundedCornerShape(8.dp))
      .background(Color(0xFF0F1218))
      .border(1.dp, Color(0xFF252B3A), RoundedCornerShape(8.dp))
      .padding(horizontal = 8.dp, vertical = 4.dp),
    contentAlignment = Alignment.Center
  ) {
    val totalWidth = maxWidth

    Column(
      modifier = Modifier.fillMaxSize(),
      verticalArrangement = Arrangement.SpaceBetween,
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      // Labels: DECK A - CENTER - DECK B
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Text(
          text = "DECK A",
          color = deckAColor,
          fontSize = 9.sp,
          fontWeight = FontWeight.Bold,
          fontFamily = FontFamily.Monospace
        )
        Text(
          text = "CROSSFADER",
          color = TextMuted,
          fontSize = 8.sp,
          fontWeight = FontWeight.SemiBold,
          fontFamily = FontFamily.Monospace
        )
        Text(
          text = "DECK B",
          color = deckBColor,
          fontSize = 9.sp,
          fontWeight = FontWeight.Bold,
          fontFamily = FontFamily.Monospace
        )
      }

      // Horizontal Crossfader Track & Slider
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(26.dp)
          .pointerInput(Unit) {
            detectDragGestures { change, _ ->
              change.consume()
              val fraction = (change.position.x / size.width).coerceIn(0f, 1f)
              onCrossfaderChange(fraction)
            }
          }
          .testTag("crossfader_slider"),
        contentAlignment = Alignment.CenterStart
      ) {
        // Track Slot with Dual Color Gradient matching the reference skins!
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(5.dp)
            .clip(RoundedCornerShape(2.5.dp))
            .background(
              Brush.horizontalGradient(
                listOf(
                  deckAColor.copy(alpha = 0.85f),
                  deckAColor.copy(alpha = 0.85f),
                  deckBColor.copy(alpha = 0.85f),
                  deckBColor.copy(alpha = 0.85f)
                )
              )
            )
            .border(0.8.dp, Color(0xFF2D3446), RoundedCornerShape(2.5.dp))
        ) {
          // Center tick notch
          Box(
            modifier = Modifier
              .align(Alignment.Center)
              .width(2.dp)
              .fillMaxHeight()
              .background(Color(0xFFFFFFFF))
          )
        }

        // Heavy Metal Crossfader Knob Cap
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .fillMaxHeight()
        ) {
          Box(
            modifier = Modifier
              .fillMaxWidth(crossfader.coerceIn(0f, 1f))
              .align(Alignment.CenterStart)
          ) {
            // The Knob itself
            Box(
              modifier = Modifier
                .align(Alignment.CenterEnd)
                .size(width = 24.dp, height = 20.dp)
                .clip(RoundedCornerShape(3.dp))
                .background(
                  Brush.verticalGradient(
                    colors = listOf(Color(0xFF6B7280), Color(0xFF374151), Color(0xFF1F2937))
                  )
                )
                .border(1.dp, Color(0xFF9CA3AF), RoundedCornerShape(3.dp))
            ) {
              // Center vertical line marker
              Box(
                modifier = Modifier
                  .align(Alignment.Center)
                  .width(1.5.dp)
                  .height(12.dp)
                  .background(TextWhite)
              )
            }
          }
        }
      }
    }
  }
}
