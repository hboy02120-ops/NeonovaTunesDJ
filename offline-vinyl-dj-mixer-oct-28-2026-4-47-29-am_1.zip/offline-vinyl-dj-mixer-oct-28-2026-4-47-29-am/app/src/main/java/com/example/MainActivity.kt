package com.example

import android.content.pm.ActivityInfo
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.model.DeckId
import com.example.model.SideTab
import com.example.ui.components.BottomConsole
import com.example.ui.components.CenterMixerColumn
import com.example.ui.components.DeckDrawer
import com.example.ui.components.MenuDialog
import com.example.ui.components.SamplerDrawer
import com.example.ui.components.SideNavTabs
import com.example.ui.components.TopHeader
import com.example.ui.components.TrackBrowserDialog
import com.example.ui.components.TurntableDeck
import com.example.ui.components.VerticalPitchFader
import com.example.ui.screens.MusicLibraryScreen
import com.example.ui.theme.CarbonBlack
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.DjMixerViewModel

class MainActivity : ComponentActivity() {

  private val viewModel: DjMixerViewModel by viewModels()

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
    enableEdgeToEdge()

    setContent {
      MyApplicationTheme {
        DjMixerScreen(viewModel = viewModel)
      }
    }
  }
}

@Composable
fun DjMixerScreen(viewModel: DjMixerViewModel) {
  val deckA by viewModel.deckA.collectAsState()
  val deckB by viewModel.deckB.collectAsState()
  val currentSkin by viewModel.currentSkin.collectAsState()
  val crossfader by viewModel.crossfader.collectAsState()
  val crossfaderCurve by viewModel.crossfaderCurve.collectAsState()
  val slipmatStyle by viewModel.slipmatStyle.collectAsState()
  val isSamplerOpen by viewModel.isSamplerOpen.collectAsState()
  val isMenuOpen by viewModel.isMenuOpen.collectAsState()
  val activeSamplerPad by viewModel.activeSamplerPad.collectAsState()
  val browserTargetDeck by viewModel.browserTargetDeck.collectAsState()
  val isRecording by viewModel.isRecording.collectAsState()
  val recordingElapsedMs by viewModel.recordingElapsedMs.collectAsState()
  val savedRecordings by viewModel.savedRecordings.collectAsState()

  // Dynamic Skin Colors derived from the selected skin (Cyber Neon vs Toxic Gold)
  val skinColorA = Color(currentSkin.deckAColorHex)
  val skinGlowA = Color(currentSkin.deckAGlowHex)
  val skinColorB = Color(currentSkin.deckBColorHex)
  val skinGlowB = Color(currentSkin.deckBGlowHex)

  // When user opens music library, transition to the dedicated full-screen Music Vault
  if (browserTargetDeck != null) {
    MusicLibraryScreen(
      initialTargetDeckId = browserTargetDeck!!,
      currentSkin = currentSkin,
      demoTrackAFile = viewModel.demoTrackAFile,
      demoTrackBFile = viewModel.demoTrackBFile,
      savedRecordings = savedRecordings,
      onLoadToDeck = { targetDeck, uri ->
        viewModel.onAudioFilePicked(targetDeck, uri)
      },
      onClose = {
        viewModel.closeBrowser()
      }
    )
  } else {
    Box(
      modifier = Modifier
        .fillMaxSize()
        .background(CarbonBlack)
        .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
      Column(modifier = Modifier.fillMaxSize()) {
        // 1. Top Header with Continuous Waveforms, Clean MENU pill, Clickable Deck A & B Load boxes
        TopHeader(
        deckA = deckA,
        deckB = deckB,
        deckAColor = skinColorA,
        deckBColor = skinColorB,
        isRecording = isRecording,
        recordingElapsedMs = recordingElapsedMs,
        onMenuClick = { viewModel.toggleMenu() },
        onOpenBrowserA = { viewModel.openBrowser(DeckId.DECK_A) },
        onOpenBrowserB = { viewModel.openBrowser(DeckId.DECK_B) },
        onTapA = { viewModel.tapBpm(DeckId.DECK_A) },
        onTapB = { viewModel.tapBpm(DeckId.DECK_B) },
        onScrubA = { frac ->
          val pos = (frac * deckA.durationMs).toInt()
          viewModel.audioEngine.seekTo(DeckId.DECK_A, pos)
        },
        onScrubB = { frac ->
          val pos = (frac * deckB.durationMs).toInt()
          viewModel.audioEngine.seekTo(DeckId.DECK_B, pos)
        }
      )

      // 2. Twin Turntable Decks, Dedicated Vertical Pitch Faders & Center Mixer Column
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .weight(1f),
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Left Side Nav Tabs (Deck A)
        SideNavTabs(
          deckId = DeckId.DECK_A,
          activeTab = deckA.activeTab,
          customAccentColor = skinColorA,
          onTabClick = { tab -> viewModel.toggleSideTab(DeckId.DECK_A, tab) }
        )

        // Deck A Turntable Area + Overlay Drawer
        Box(
          modifier = Modifier
            .weight(1f)
            .fillMaxHeight(),
          contentAlignment = Alignment.Center
        ) {
          TurntableDeck(
            state = deckA,
            slipmatStyle = slipmatStyle,
            customAccentColor = skinColorA,
            onScratchStart = { angle -> viewModel.onVinylScratchStart(DeckId.DECK_A, angle) },
            onScratchMove = { angle -> viewModel.onVinylScratchMove(DeckId.DECK_A, angle) },
            onScratchEnd = { viewModel.onVinylScratchEnd(DeckId.DECK_A) }
          )

          // Deck A Drawer (FX, LOOP, EQ, HOT CUES)
          if (deckA.activeTab != SideTab.NONE) {
            DeckDrawer(
              deckState = deckA,
              onClose = { viewModel.closeSideTab(DeckId.DECK_A) },
              onLoopToggle = { beats -> viewModel.toggleLoop(DeckId.DECK_A, beats) },
              onSetHotCue = { idx -> viewModel.setHotCue(DeckId.DECK_A, idx) },
              onJumpHotCue = { idx -> viewModel.jumpHotCue(DeckId.DECK_A, idx) },
              onClearHotCue = { idx -> viewModel.clearHotCue(DeckId.DECK_A, idx) },
              onEqChange = { band, val_ -> viewModel.setEq(DeckId.DECK_A, band, val_) },
              onEqKillToggle = { band -> viewModel.toggleEqKill(DeckId.DECK_A, band) },
              onFxPadChange = { x, y -> viewModel.setFxPad(DeckId.DECK_A, x, y) },
              onFxToggle = { viewModel.toggleFx(DeckId.DECK_A) },
              onFxTypeSelect = { type -> viewModel.selectFxType(DeckId.DECK_A, type) },
              modifier = Modifier.fillMaxSize(0.92f)
            )
          }
        }

        // Deck A Vertical Pitch Fader (±16%)
        VerticalPitchFader(
          deckId = DeckId.DECK_A,
          pitchPercent = deckA.pitchPercent,
          customAccentColor = skinColorA,
          onPitchChange = { p -> viewModel.setPitchPercent(DeckId.DECK_A, p) },
          onReset = { viewModel.resetPitch(DeckId.DECK_A) }
        )

        // Center Mixer Column (Load buttons, vertical volume faders with VU, SYNC, CUE monitors)
        CenterMixerColumn(
          deckA = deckA,
          deckB = deckB,
          deckAColor = skinColorA,
          deckBColor = skinColorB,
          onVolumeAChange = { vol -> viewModel.setChannelVolume(DeckId.DECK_A, vol) },
          onVolumeBChange = { vol -> viewModel.setChannelVolume(DeckId.DECK_B, vol) },
          onCueHeadphoneAToggle = { viewModel.toggleCueHeadphone(DeckId.DECK_A) },
          onCueHeadphoneBToggle = { viewModel.toggleCueHeadphone(DeckId.DECK_B) },
          onSyncClick = { viewModel.syncDecks() },
          onLoadTrackAClick = { viewModel.openBrowser(DeckId.DECK_A) },
          onLoadTrackBClick = { viewModel.openBrowser(DeckId.DECK_B) }
        )

        // Deck B Vertical Pitch Fader (±16%)
        VerticalPitchFader(
          deckId = DeckId.DECK_B,
          pitchPercent = deckB.pitchPercent,
          customAccentColor = skinColorB,
          onPitchChange = { p -> viewModel.setPitchPercent(DeckId.DECK_B, p) },
          onReset = { viewModel.resetPitch(DeckId.DECK_B) }
        )

        // Deck B Turntable Area + Overlay Drawer
        Box(
          modifier = Modifier
            .weight(1f)
            .fillMaxHeight(),
          contentAlignment = Alignment.Center
        ) {
          TurntableDeck(
            state = deckB,
            slipmatStyle = slipmatStyle,
            customAccentColor = skinColorB,
            onScratchStart = { angle -> viewModel.onVinylScratchStart(DeckId.DECK_B, angle) },
            onScratchMove = { angle -> viewModel.onVinylScratchMove(DeckId.DECK_B, angle) },
            onScratchEnd = { viewModel.onVinylScratchEnd(DeckId.DECK_B) }
          )

          // Deck B Drawer (FX, LOOP, EQ, HOT CUES)
          if (deckB.activeTab != SideTab.NONE) {
            DeckDrawer(
              deckState = deckB,
              onClose = { viewModel.closeSideTab(DeckId.DECK_B) },
              onLoopToggle = { beats -> viewModel.toggleLoop(DeckId.DECK_B, beats) },
              onSetHotCue = { idx -> viewModel.setHotCue(DeckId.DECK_B, idx) },
              onJumpHotCue = { idx -> viewModel.jumpHotCue(DeckId.DECK_B, idx) },
              onClearHotCue = { idx -> viewModel.clearHotCue(DeckId.DECK_B, idx) },
              onEqChange = { band, val_ -> viewModel.setEq(DeckId.DECK_B, band, val_) },
              onEqKillToggle = { band -> viewModel.toggleEqKill(DeckId.DECK_B, band) },
              onFxPadChange = { x, y -> viewModel.setFxPad(DeckId.DECK_B, x, y) },
              onFxToggle = { viewModel.toggleFx(DeckId.DECK_B) },
              onFxTypeSelect = { type -> viewModel.selectFxType(DeckId.DECK_B, type) },
              modifier = Modifier.fillMaxSize(0.92f)
            )
          }
        }

        // Right Side Nav Tabs (Deck B)
        SideNavTabs(
          deckId = DeckId.DECK_B,
          activeTab = deckB.activeTab,
          customAccentColor = skinColorB,
          onTabClick = { tab -> viewModel.toggleSideTab(DeckId.DECK_B, tab) }
        )
      }

      // 3. Bottom Playback Console with Compact Dual-Colored Equal-Power Crossfader
      BottomConsole(
        deckA = deckA,
        deckB = deckB,
        deckAColor = skinColorA,
        deckAGlow = skinGlowA,
        deckBColor = skinColorB,
        deckBGlow = skinGlowB,
        crossfader = crossfader,
        onPlayPauseA = { viewModel.togglePlayPause(DeckId.DECK_A) },
        onPlayPauseB = { viewModel.togglePlayPause(DeckId.DECK_B) },
        onCueSetA = { viewModel.cueSetOrJump(DeckId.DECK_A) },
        onCueSetB = { viewModel.cueSetOrJump(DeckId.DECK_B) },
        onNudgeA = { delta -> viewModel.nudgePitch(DeckId.DECK_A, delta) },
        onNudgeB = { delta -> viewModel.nudgePitch(DeckId.DECK_B, delta) },
        onSamplerToggle = { viewModel.toggleSampler() },
        onCrossfaderChange = { frac -> viewModel.setCrossfader(frac) }
      )
    }

    // Sampler Floating Drawer (Toggled from bottom console)
    if (isSamplerOpen) {
      SamplerDrawer(
        activePadIndex = activeSamplerPad,
        onTriggerSample = { type, idx -> viewModel.triggerSamplerPad(type, idx) },
        onClose = { viewModel.toggleSampler() },
        modifier = Modifier.align(Alignment.BottomCenter)
      )
    }

    // Menu Modal Dialog (Houses all 6 skins and live recording controls)
    if (isMenuOpen) {
      MenuDialog(
        currentCurve = crossfaderCurve,
        currentSlipmat = slipmatStyle,
        currentSkin = currentSkin,
        isRecording = isRecording,
        recordingElapsedMs = recordingElapsedMs,
        onToggleRecording = { viewModel.toggleRecording() },
        onCurveSelect = { curve -> viewModel.setCrossfaderCurve(curve) },
        onSlipmatSelect = { style -> viewModel.setSlipmatStyle(style) },
        onSkinSelect = { skin -> viewModel.setSkin(skin) },
        onDismiss = { viewModel.toggleMenu() }
      )
    }
  }
}
}
