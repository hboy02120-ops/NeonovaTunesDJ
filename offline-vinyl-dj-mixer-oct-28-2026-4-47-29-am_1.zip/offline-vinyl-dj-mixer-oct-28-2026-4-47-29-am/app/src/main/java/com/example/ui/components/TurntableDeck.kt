package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.model.DeckId
import com.example.model.DeckState
import com.example.model.SlipmatStyle
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPink
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

@Composable
fun TurntableDeck(
  state: DeckState,
  slipmatStyle: SlipmatStyle,
  customAccentColor: Color? = null,
  onScratchStart: (Float) -> Unit,
  onScratchMove: (Float) -> Unit,
  onScratchEnd: () -> Unit,
  modifier: Modifier = Modifier
) {
  val isDeckA = state.deckId == DeckId.DECK_A
  val accentColor = customAccentColor ?: (if (isDeckA) NeonCyan else NeonPink)

  BoxWithConstraints(
    modifier = modifier
      .fillMaxSize()
      .padding(4.dp),
    contentAlignment = Alignment.Center
  ) {
    val deckSize = min(maxWidth.value, maxHeight.value).dp

    Box(
      modifier = Modifier
        .aspectRatio(1f)
        .fillMaxSize()
        .testTag(if (isDeckA) "turntable_deck_a" else "turntable_deck_b")
        .pointerInput(state.deckId) {
          detectDragGestures(
            onDragStart = { offset ->
              val cx = size.width / 2f
              val cy = size.height / 2f
              val dx = offset.x - cx
              val dy = offset.y - cy
              val r = sqrt(dx * dx + dy * dy)
              val platterRadius = size.width * 0.46f

              if (r <= platterRadius) {
                val angleDeg = (atan2(dy, dx) * (180f / PI.toFloat()))
                onScratchStart(angleDeg)
              }
            },
            onDrag = { change, _ ->
              change.consume()
              val cx = size.width / 2f
              val cy = size.height / 2f
              val dx = change.position.x - cx
              val dy = change.position.y - cy
              val angleDeg = (atan2(dy, dx) * (180f / PI.toFloat()))
              onScratchMove(angleDeg)
            },
            onDragEnd = { onScratchEnd() },
            onDragCancel = { onScratchEnd() }
          )
        }
    ) {
      Canvas(modifier = Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val cx = w / 2f
        val cy = h / 2f
        val radius = min(cx, cy) * 0.94f

        // 1. Brushed Dark Platter Base Plate
        drawCircle(
          brush = Brush.radialGradient(
            colors = listOf(Color(0xFF222631), Color(0xFF13151C), Color(0xFF0C0E12)),
            center = Offset(cx, cy),
            radius = radius * 1.05f
          ),
          radius = radius * 1.04f,
          center = Offset(cx, cy)
        )

        // Strobe Dots Rim around the platter
        val strobeCount = 48
        val strobeRadius = radius * 0.99f
        for (i in 0 until strobeCount) {
          val theta = (i * 2.0 * PI / strobeCount).toFloat()
          val sx = cx + strobeRadius * cos(theta)
          val sy = cy + strobeRadius * sin(theta)
          drawCircle(
            color = if (i % 4 == 0) Color(0xFF8E95A5) else Color(0xFF3B404D),
            radius = radius * 0.012f,
            center = Offset(sx, sy)
          )
        }

        // Platter Outer Ring Accent
        drawCircle(
          color = accentColor.copy(alpha = if (state.isPlaying) 0.85f else 0.35f),
          radius = radius * 0.96f,
          center = Offset(cx, cy),
          style = Stroke(width = 3.dp.toPx())
        )

        // 2. Vinyl Record Discs (Rotates smoothly or by touch scratch)
        rotate(degrees = state.vinylAngleDegrees, pivot = Offset(cx, cy)) {
          // Vinyl Black Body
          drawCircle(
            brush = Brush.radialGradient(
              colors = listOf(Color(0xFF151820), Color(0xFF0F1116), Color(0xFF07080B)),
              center = Offset(cx, cy),
              radius = radius * 0.95f
            ),
            radius = radius * 0.94f,
            center = Offset(cx, cy)
          )

          // Vinyl Microgrooves (concentric subtle arcs)
          val grooveSteps = 16
          val innerGroove = radius * 0.44f
          val outerGroove = radius * 0.91f
          for (g in 0 until grooveSteps) {
            val gr = innerGroove + (outerGroove - innerGroove) * (g.toFloat() / grooveSteps)
            drawCircle(
              color = Color(0xFF252B38).copy(alpha = if (g % 3 == 0) 0.45f else 0.22f),
              radius = gr,
              center = Offset(cx, cy),
              style = Stroke(width = 1.2.dp.toPx())
            )
          }

          // Subtle Anisotropic Light Sheen (Two opposing triangular reflections)
          drawSheenReflection(cx, cy, radius * 0.94f)

          // Center Slipmat / Psychedelic Album Artwork
          val slipmatRadius = radius * 0.40f
          drawSlipmat(cx, cy, slipmatRadius, slipmatStyle, accentColor)

          // Spindle Hole & Chrome Center Cap
          drawCircle(
            brush = Brush.radialGradient(
              colors = listOf(Color(0xFFE0E0E0), Color(0xFF9E9E9E), Color(0xFF424242)),
              center = Offset(cx, cy),
              radius = radius * 0.08f
            ),
            radius = radius * 0.075f,
            center = Offset(cx, cy)
          )
          drawCircle(
            color = Color(0xFF090A0D),
            radius = radius * 0.026f,
            center = Offset(cx, cy)
          )
        }

        // 3. Realistic Tonearm Needle Stylus
        val progress = if (state.durationMs > 0) {
          (state.positionMs.toFloat() / state.durationMs.toFloat()).coerceIn(0f, 1f)
        } else 0f

        drawTonearm(
          w = w,
          h = h,
          cx = cx,
          cy = cy,
          radius = radius,
          progress = progress,
          isPlaying = state.isPlaying,
          isDeckA = isDeckA,
          accentColor = accentColor
        )
      }
    }
  }
}

private fun DrawScope.drawSheenReflection(cx: Float, cy: Float, radius: Float) {
  // Opposing sheen triangles mimicking light hitting vinyl grooves
  val sheenPath = Path().apply {
    moveTo(cx, cy)
    lineTo(cx - radius * 0.85f, cy - radius * 0.5f)
    lineTo(cx - radius * 0.5f, cy - radius * 0.85f)
    close()
    moveTo(cx, cy)
    lineTo(cx + radius * 0.85f, cy + radius * 0.5f)
    lineTo(cx + radius * 0.5f, cy + radius * 0.85f)
    close()
  }
  drawPath(
    path = sheenPath,
    brush = Brush.radialGradient(
      colors = listOf(Color(0x33FFFFFF), Color(0x05FFFFFF), Color.Transparent),
      center = Offset(cx, cy),
      radius = radius
    )
  )
}

private fun DrawScope.drawSlipmat(
  cx: Float,
  cy: Float,
  radius: Float,
  style: SlipmatStyle,
  accentColor: Color
) {
  // Slipmat border
  drawCircle(
    color = Color(0xFF222836),
    radius = radius,
    center = Offset(cx, cy)
  )

  when (style) {
    SlipmatStyle.RAINBOW_TARGET -> {
      // Concentric rainbow bands matching the reference screenshots
      val bands = listOf(
        Pair(0.95f, Color(0xFF00E5FF)), // Cyan
        Pair(0.80f, Color(0xFF00E676)), // Emerald Green
        Pair(0.65f, Color(0xFFFFD600)), // Yellow
        Pair(0.50f, Color(0xFFFF6D00)), // Orange
        Pair(0.35f, Color(0xFFFF007F))  // Hot Pink
      )
      bands.forEach { (scale, col) ->
        drawCircle(
          color = col,
          radius = radius * scale,
          center = Offset(cx, cy)
        )
      }
      drawCircle(
        color = Color(0xFF141720),
        radius = radius * 0.22f,
        center = Offset(cx, cy)
      )
    }
    SlipmatStyle.PSYCHEDELIC -> {
      // Hypnotic multicolor spiral swirls
      val spiralColors = listOf(
        Color(0xFFFF007F),
        Color(0xFF7928CA),
        Color(0xFF00DFD8),
        Color(0xFFFFBE0B),
        Color(0xFFFF007F)
      )
      drawCircle(
        brush = Brush.sweepGradient(spiralColors, center = Offset(cx, cy)),
        radius = radius * 0.95f,
        center = Offset(cx, cy)
      )
      // Inner spiral rings
      for (r in listOf(0.75f, 0.55f, 0.35f)) {
        drawCircle(
          color = Color.Black.copy(alpha = 0.5f),
          radius = radius * r,
          center = Offset(cx, cy),
          style = Stroke(width = 3.dp.toPx())
        )
      }
    }
    SlipmatStyle.NEON_CYBER -> {
      drawCircle(
        brush = Brush.radialGradient(
          colors = listOf(accentColor, Color(0xFF002830), Color(0xFF06090E)),
          center = Offset(cx, cy),
          radius = radius
        ),
        radius = radius * 0.95f,
        center = Offset(cx, cy)
      )
      // Cyber grid lines
      for (angle in 0 until 12) {
        val aRad = (angle * 30.0 * PI / 180.0).toFloat()
        drawLine(
          color = accentColor.copy(alpha = 0.6f),
          start = Offset(cx, cy),
          end = Offset(cx + radius * 0.9f * cos(aRad), cy + radius * 0.9f * sin(aRad)),
          strokeWidth = 1.5.dp.toPx()
        )
      }
    }
    SlipmatStyle.ACID_SUN -> {
      val sunColors = listOf(
        Color(0xFFFF3366),
        Color(0xFFFF6600),
        Color(0xFFFFCC00),
        Color(0xFFFF3366)
      )
      drawCircle(
        brush = Brush.sweepGradient(sunColors, center = Offset(cx, cy)),
        radius = radius * 0.95f,
        center = Offset(cx, cy)
      )
      drawCircle(
        color = Color(0xFF11141A),
        radius = radius * 0.45f,
        center = Offset(cx, cy)
      )
    }
    SlipmatStyle.VINTAGE_VINYL -> {
      drawCircle(
        brush = Brush.radialGradient(
          colors = listOf(Color(0xFF8B1E1E), Color(0xFF4A0A0A), Color(0xFF220000)),
          center = Offset(cx, cy),
          radius = radius
        ),
        radius = radius * 0.95f,
        center = Offset(cx, cy)
      )
      // Classic Gold Foil lettering ring
      drawCircle(
        color = Color(0xFFFFD700).copy(alpha = 0.7f),
        radius = radius * 0.75f,
        center = Offset(cx, cy),
        style = Stroke(width = 1.5.dp.toPx())
      )
    }
  }

  // Inner ring around hole
  drawCircle(
    color = Color.White.copy(alpha = 0.85f),
    radius = radius * 0.18f,
    center = Offset(cx, cy),
    style = Stroke(width = 2.dp.toPx())
  )
}

private fun DrawScope.drawTonearm(
  w: Float,
  h: Float,
  cx: Float,
  cy: Float,
  radius: Float,
  progress: Float,
  isPlaying: Boolean,
  isDeckA: Boolean,
  accentColor: Color
) {
  // Pivot base sits at top outer corner
  val pivotX = if (isDeckA) cx - radius * 0.82f else cx + radius * 0.82f
  val pivotY = cy - radius * 0.82f

  // Angular range: resting position when off/start, slowly sweeps across vinyl track
  // Outer vinyl edge to inner run-out groove
  val baseAngleDeg = if (isDeckA) {
    if (isPlaying) (32f + progress * 24f) else 14f
  } else {
    if (isPlaying) (-32f - progress * 24f) else -14f
  }

  rotate(degrees = baseAngleDeg, pivot = Offset(pivotX, pivotY)) {
    // 1. Pivot Gimbal Base & Chrome Ring
    drawCircle(
      brush = Brush.radialGradient(
        colors = listOf(Color(0xFF565F73), Color(0xFF2C313C), Color(0xFF16181E)),
        center = Offset(pivotX, pivotY),
        radius = radius * 0.16f
      ),
      radius = radius * 0.15f,
      center = Offset(pivotX, pivotY)
    )
    drawCircle(
      color = Color(0xFF8E95A5),
      radius = radius * 0.15f,
      center = Offset(pivotX, pivotY),
      style = Stroke(width = 2.dp.toPx())
    )

    // 2. Counterweight (Cylinder behind pivot)
    val cwY = pivotY - radius * 0.18f
    drawLine(
      brush = Brush.horizontalGradient(
        colors = listOf(Color(0xFF222630), Color(0xFF9EABB8), Color(0xFF222630)),
        startX = pivotX - radius * 0.08f,
        endX = pivotX + radius * 0.08f
      ),
      start = Offset(pivotX, pivotY - radius * 0.04f),
      end = Offset(pivotX, cwY),
      strokeWidth = radius * 0.13f,
      cap = StrokeCap.Round
    )

    // 3. Metallic Tonearm Pipe (Graceful S-curved tube)
    val armLength = radius * 1.08f
    val armPath = Path().apply {
      moveTo(pivotX, pivotY)
      val p1x = if (isDeckA) pivotX + radius * 0.14f else pivotX - radius * 0.14f
      val p1y = pivotY + armLength * 0.45f
      val p2x = if (isDeckA) pivotX - radius * 0.04f else pivotX + radius * 0.04f
      val p2y = pivotY + armLength * 0.78f
      val endX = if (isDeckA) pivotX + radius * 0.08f else pivotX - radius * 0.08f
      val endY = pivotY + armLength
      cubicTo(p1x, p1y, p2x, p2y, endX, endY)
    }

    drawPath(
      path = armPath,
      brush = Brush.linearGradient(
        colors = listOf(Color(0xFFE2E8F0), Color(0xFF94A3B8), Color(0xFF475569)),
        start = Offset(pivotX, pivotY),
        end = Offset(pivotX, pivotY + armLength)
      ),
      style = Stroke(width = 4.5.dp.toPx(), cap = StrokeCap.Round)
    )

    // 4. Headshell & Cartridge Body
    val headX = if (isDeckA) pivotX + radius * 0.08f else pivotX - radius * 0.08f
    val headY = pivotY + armLength
    val cartAngle = if (isDeckA) 24f else -24f

    rotate(degrees = cartAngle, pivot = Offset(headX, headY)) {
      // Cartridge rectangle
      val cw = radius * 0.07f
      val ch = radius * 0.14f
      drawRect(
        color = Color(0xFF1E232E),
        topLeft = Offset(headX - cw / 2f, headY),
        size = Size(cw, ch)
      )
      // Finger lift hook
      drawLine(
        color = Color(0xFFCBD5E1),
        start = Offset(headX + (if (isDeckA) cw * 0.4f else -cw * 0.4f), headY + ch * 0.3f),
        end = Offset(headX + (if (isDeckA) cw * 1.1f else -cw * 1.1f), headY + ch * 0.1f),
        strokeWidth = 2.dp.toPx(),
        cap = StrokeCap.Round
      )
      // Stylus Needle Tip with bright glowing micro-LED
      val needleTip = Offset(headX, headY + ch)
      drawCircle(
        color = Color(0xFFFFFFFF),
        radius = radius * 0.016f,
        center = needleTip
      )
      drawCircle(
        color = accentColor.copy(alpha = if (isPlaying) 0.9f else 0.4f),
        radius = radius * 0.035f,
        center = needleTip
      )
    }
  }
}
