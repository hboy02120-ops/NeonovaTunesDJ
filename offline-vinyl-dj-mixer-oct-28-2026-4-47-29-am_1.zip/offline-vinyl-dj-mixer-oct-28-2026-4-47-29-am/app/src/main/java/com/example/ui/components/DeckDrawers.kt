package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DeckId
import com.example.model.DeckState
import com.example.model.SideTab
import com.example.ui.theme.BorderDark
import com.example.ui.theme.CarbonBlack
import com.example.ui.theme.LedGreen
import com.example.ui.theme.LedRed
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPink
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import java.util.Locale

@Composable
fun DeckDrawer(
  deckState: DeckState,
  onClose: () -> Unit,
  onLoopToggle: (Float) -> Unit,
  onSetHotCue: (Int) -> Unit,
  onJumpHotCue: (Int) -> Unit,
  onClearHotCue: (Int) -> Unit,
  onEqChange: (String, Float) -> Unit,
  onEqKillToggle: (String) -> Unit,
  onFxPadChange: (Float, Float) -> Unit,
  onFxToggle: () -> Unit,
  onFxTypeSelect: (String) -> Unit,
  modifier: Modifier = Modifier
) {
  val isDeckA = deckState.deckId == DeckId.DECK_A
  val accentColor = if (isDeckA) NeonCyan else NeonPink

  Box(
    modifier = modifier
      .clip(RoundedCornerShape(10.dp))
      .background(Color(0xF012151E))
      .border(1.5.dp, accentColor.copy(alpha = 0.8f), RoundedCornerShape(10.dp))
      .padding(8.dp)
  ) {
    Column(modifier = Modifier.fillMaxSize()) {
      // Header with Title and Close Button
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "${if (isDeckA) "DECK A" else "DECK B"} • ${deckState.activeTab.name}",
          color = accentColor,
          fontSize = 11.sp,
          fontWeight = FontWeight.Black,
          fontFamily = FontFamily.Monospace
        )
        Box(
          modifier = Modifier
            .size(24.dp)
            .clip(CircleShape)
            .background(Color(0xFF1E2330))
            .clickable { onClose() },
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Default.Close,
            contentDescription = "Close",
            tint = TextWhite,
            modifier = Modifier.size(14.dp)
          )
        }
      }

      Spacer(modifier = Modifier.height(4.dp))

      // Content based on active tab
      Box(modifier = Modifier.fillMaxSize()) {
        when (deckState.activeTab) {
          SideTab.FX -> FxPanel(
            state = deckState,
            accentColor = accentColor,
            onPadChange = onFxPadChange,
            onToggle = onFxToggle,
            onTypeSelect = onFxTypeSelect
          )
          SideTab.LOOP -> LoopPanel(
            state = deckState,
            accentColor = accentColor,
            onLoopToggle = onLoopToggle
          )
          SideTab.EQ -> EqPanel(
            state = deckState,
            accentColor = accentColor,
            onEqChange = onEqChange,
            onKillToggle = onEqKillToggle
          )
          SideTab.HOT_CUES -> HotCuesPanel(
            state = deckState,
            accentColor = accentColor,
            onSetCue = onSetHotCue,
            onJumpCue = onJumpHotCue,
            onClearCue = onClearHotCue
          )
          SideTab.NONE -> Unit
        }
      }
    }
  }
}

// 1. FX Panel (Filter / Flanger / Echo / Reverb + Interactive 2D Kaoss XY Touchpad)
@Composable
private fun FxPanel(
  state: DeckState,
  accentColor: Color,
  onPadChange: (Float, Float) -> Unit,
  onToggle: () -> Unit,
  onTypeSelect: (String) -> Unit
) {
  Column(
    modifier = Modifier.fillMaxSize(),
    verticalArrangement = Arrangement.SpaceBetween
  ) {
    // FX Selector Row + On/Off Button
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        listOf("FILTER", "FLANGER", "ECHO", "REVERB").forEach { type ->
          val isSelected = state.fxType == type
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(4.dp))
              .background(if (isSelected) accentColor.copy(alpha = 0.25f) else Color(0xFF181C26))
              .border(1.dp, if (isSelected) accentColor else Color(0xFF2C3345), RoundedCornerShape(4.dp))
              .clickable { onTypeSelect(type) }
              .padding(horizontal = 6.dp, vertical = 3.dp)
          ) {
            Text(
              text = type,
              color = if (isSelected) accentColor else TextMuted,
              fontSize = 9.sp,
              fontWeight = FontWeight.Bold,
              fontFamily = FontFamily.Monospace
            )
          }
        }
      }

      // FX Enable Toggle
      Box(
        modifier = Modifier
          .clip(RoundedCornerShape(4.dp))
          .background(if (state.fxEnabled) LedGreen.copy(alpha = 0.3f) else Color(0xFF242A38))
          .border(1.dp, if (state.fxEnabled) LedGreen else Color(0xFF3E475A), RoundedCornerShape(4.dp))
          .clickable { onToggle() }
          .padding(horizontal = 8.dp, vertical = 3.dp)
      ) {
        Text(
          text = if (state.fxEnabled) "FX ON" else "FX OFF",
          color = if (state.fxEnabled) LedGreen else TextMuted,
          fontSize = 9.sp,
          fontWeight = FontWeight.Black,
          fontFamily = FontFamily.Monospace
        )
      }
    }

    Spacer(modifier = Modifier.height(4.dp))

    // Interactive 2D XY Touchpad
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .weight(1f)
        .clip(RoundedCornerShape(6.dp))
        .background(Color(0xFF0A0C11))
        .border(1.dp, Color(0xFF262C3D), RoundedCornerShape(6.dp))
        .pointerInput(Unit) {
          detectDragGestures { change, _ ->
            change.consume()
            val x = (change.position.x / size.width).coerceIn(0f, 1f)
            val y = (change.position.y / size.height).coerceIn(0f, 1f)
            onPadChange(x, y)
          }
        }
    ) {
      Canvas(modifier = Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height

        // Crosshairs
        drawLine(
          color = Color(0xFF1D2230),
          start = Offset(w / 2f, 0f),
          end = Offset(w / 2f, h),
          strokeWidth = 1.dp.toPx()
        )
        drawLine(
          color = Color(0xFF1D2230),
          start = Offset(0f, h / 2f),
          end = Offset(w, h / 2f),
          strokeWidth = 1.dp.toPx()
        )

        // Indicator node
        val nodeX = state.fxX * w
        val nodeY = state.fxY * h
        drawCircle(
          color = accentColor.copy(alpha = 0.35f),
          radius = 16.dp.toPx(),
          center = Offset(nodeX, nodeY)
        )
        drawCircle(
          color = accentColor,
          radius = 6.dp.toPx(),
          center = Offset(nodeX, nodeY)
        )
      }

      Text(
        text = "CUTOFF: ${(state.fxX * 100).toInt()}% • RES: ${(state.fxY * 100).toInt()}%",
        color = TextMuted,
        fontSize = 8.sp,
        fontFamily = FontFamily.Monospace,
        modifier = Modifier
          .align(Alignment.BottomStart)
          .padding(4.dp)
      )
    }
  }
}

// 2. LOOP Panel (1/8 to 16 beats)
@Composable
private fun LoopPanel(
  state: DeckState,
  accentColor: Color,
  onLoopToggle: (Float) -> Unit
) {
  val loopBeats = listOf(0.125f, 0.25f, 0.5f, 1f, 2f, 4f, 8f, 16f)
  val beatLabels = listOf("1/8", "1/4", "1/2", "1", "2", "4", "8", "16")

  Column(
    modifier = Modifier.fillMaxSize(),
    verticalArrangement = Arrangement.SpaceEvenly
  ) {
    Text(
      text = if (state.isLoopActive) "ACTIVE LOOP: ${state.loopBeats.toInt()} BEATS" else "SELECT LOOP LENGTH",
      color = if (state.isLoopActive) LedGreen else TextMuted,
      fontSize = 9.sp,
      fontWeight = FontWeight.Bold,
      fontFamily = FontFamily.Monospace
    )

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
      for (i in 0 until 4) {
        val b = loopBeats[i]
        val lbl = beatLabels[i]
        val isCurrent = state.isLoopActive && state.loopBeats == b
        LoopButton(
          label = lbl,
          isActive = isCurrent,
          accentColor = accentColor,
          onClick = { onLoopToggle(b) },
          modifier = Modifier.weight(1f)
        )
      }
    }

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
      for (i in 4 until 8) {
        val b = loopBeats[i]
        val lbl = beatLabels[i]
        val isCurrent = state.isLoopActive && state.loopBeats == b
        LoopButton(
          label = lbl,
          isActive = isCurrent,
          accentColor = accentColor,
          onClick = { onLoopToggle(b) },
          modifier = Modifier.weight(1f)
        )
      }
    }
  }
}

@Composable
private fun LoopButton(
  label: String,
  isActive: Boolean,
  accentColor: Color,
  onClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  Box(
    modifier = modifier
      .height(34.dp)
      .clip(RoundedCornerShape(6.dp))
      .background(if (isActive) accentColor.copy(alpha = 0.35f) else Color(0xFF161A24))
      .border(
        width = if (isActive) 1.5.dp else 1.dp,
        color = if (isActive) accentColor else Color(0xFF2C3242),
        shape = RoundedCornerShape(6.dp)
      )
      .clickable { onClick() },
    contentAlignment = Alignment.Center
  ) {
    Text(
      text = label,
      color = if (isActive) accentColor else TextWhite,
      fontSize = 11.sp,
      fontWeight = FontWeight.Black,
      fontFamily = FontFamily.Monospace
    )
  }
}

// 3. EQ Panel (High, Mid, Low sliders + Kill buttons)
@Composable
private fun EqPanel(
  state: DeckState,
  accentColor: Color,
  onEqChange: (String, Float) -> Unit,
  onKillToggle: (String) -> Unit
) {
  Row(
    modifier = Modifier.fillMaxSize(),
    horizontalArrangement = Arrangement.SpaceEvenly,
    verticalAlignment = Alignment.CenterVertically
  ) {
    EqBandColumn(
      label = "HIGH",
      value = state.eqHigh,
      isKilled = state.eqKillHigh,
      accentColor = accentColor,
      onValueChange = { onEqChange("HIGH", it) },
      onKillToggle = { onKillToggle("HIGH") },
      modifier = Modifier.weight(1f)
    )
    EqBandColumn(
      label = "MID",
      value = state.eqMid,
      isKilled = state.eqKillMid,
      accentColor = accentColor,
      onValueChange = { onEqChange("MID", it) },
      onKillToggle = { onKillToggle("MID") },
      modifier = Modifier.weight(1f)
    )
    EqBandColumn(
      label = "LOW",
      value = state.eqLow,
      isKilled = state.eqKillLow,
      accentColor = accentColor,
      onValueChange = { onEqChange("LOW", it) },
      onKillToggle = { onKillToggle("LOW") },
      modifier = Modifier.weight(1f)
    )
  }
}

@Composable
private fun EqBandColumn(
  label: String,
  value: Float,
  isKilled: Boolean,
  accentColor: Color,
  onValueChange: (Float) -> Unit,
  onKillToggle: () -> Unit,
  modifier: Modifier = Modifier
) {
  Column(
    modifier = modifier.fillMaxHeight(),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.SpaceBetween
  ) {
    Text(
      text = label,
      color = TextWhite,
      fontSize = 9.sp,
      fontWeight = FontWeight.Bold,
      fontFamily = FontFamily.Monospace
    )

    // Vertical slider track
    Box(
      modifier = Modifier
        .width(16.dp)
        .weight(1f)
        .padding(vertical = 4.dp)
        .pointerInput(Unit) {
          detectDragGestures { change, _ ->
            change.consume()
            val fraction = 1.0f - (change.position.y / size.height).coerceIn(0f, 1f)
            onValueChange(fraction * 2.0f) // 0.0 to 2.0
          }
        },
      contentAlignment = Alignment.BottomCenter
    ) {
      Box(
        modifier = Modifier
          .width(4.dp)
          .fillMaxHeight()
          .clip(RoundedCornerShape(2.dp))
          .background(Color(0xFF0C0E14))
      ) {
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .fillMaxHeight((value / 2f).coerceIn(0f, 1f))
            .align(Alignment.BottomCenter)
            .background(if (isKilled) LedRed else accentColor)
        )
      }
    }

    // KILL Button
    Box(
      modifier = Modifier
        .clip(RoundedCornerShape(4.dp))
        .background(if (isKilled) LedRed else Color(0xFF222838))
        .border(1.dp, if (isKilled) LedRed else Color(0xFF3B4356), RoundedCornerShape(4.dp))
        .clickable { onKillToggle() }
        .padding(horizontal = 6.dp, vertical = 2.dp),
      contentAlignment = Alignment.Center
    ) {
      Text(
        text = "KILL",
        color = if (isKilled) CarbonBlack else TextMuted,
        fontSize = 8.sp,
        fontWeight = FontWeight.Black,
        fontFamily = FontFamily.Monospace
      )
    }
  }
}

// 4. HOT CUES Panel (4 Responsive Colored Pads)
@Composable
private fun HotCuesPanel(
  state: DeckState,
  accentColor: Color,
  onSetCue: (Int) -> Unit,
  onJumpCue: (Int) -> Unit,
  onClearCue: (Int) -> Unit
) {
  val cueColors = listOf(Color(0xFF00E5FF), Color(0xFFFF2A6D), Color(0xFFFFAB00), Color(0xFF00E676))

  Row(
    modifier = Modifier.fillMaxSize(),
    horizontalArrangement = Arrangement.spacedBy(6.dp),
    verticalAlignment = Alignment.CenterVertically
  ) {
    for (i in 0..3) {
      val existingCue = state.hotCues.find { it.index == i }
      val isAssigned = existingCue != null
      val padColor = cueColors[i]

      Column(
        modifier = Modifier
          .weight(1f)
          .fillMaxHeight(),
        verticalArrangement = Arrangement.SpaceBetween,
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        // Main Trigger Pad
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .weight(1f)
            .clip(RoundedCornerShape(6.dp))
            .background(if (isAssigned) padColor.copy(alpha = 0.35f) else Color(0xFF161A25))
            .border(
              width = if (isAssigned) 2.dp else 1.dp,
              color = if (isAssigned) padColor else Color(0xFF2E3547),
              shape = RoundedCornerShape(6.dp)
            )
            .clickable {
              if (isAssigned) onJumpCue(i) else onSetCue(i)
            },
          contentAlignment = Alignment.Center
        ) {
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
              text = "CUE ${i + 1}",
              color = if (isAssigned) padColor else TextMuted,
              fontSize = 10.sp,
              fontWeight = FontWeight.Black,
              fontFamily = FontFamily.Monospace
            )
            if (isAssigned) {
              val sec = existingCue.positionMs / 1000
              Text(
                text = String.format(Locale.US, "%02d:%02d", sec / 60, sec % 60),
                color = TextWhite,
                fontSize = 8.sp,
                fontFamily = FontFamily.Monospace
              )
            } else {
              Text(
                text = "TAP TO SET",
                color = Color(0xFF6B7280),
                fontSize = 7.sp,
                fontFamily = FontFamily.Monospace
              )
            }
          }
        }

        // Delete/Clear Button if assigned
        if (isAssigned) {
          Spacer(modifier = Modifier.height(2.dp))
          Box(
            modifier = Modifier
              .size(20.dp)
              .clip(CircleShape)
              .background(Color(0xFF221518))
              .clickable { onClearCue(i) },
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Default.Delete,
              contentDescription = "Clear Cue",
              tint = LedRed,
              modifier = Modifier.size(11.dp)
            )
          }
        }
      }
    }
  }
}
