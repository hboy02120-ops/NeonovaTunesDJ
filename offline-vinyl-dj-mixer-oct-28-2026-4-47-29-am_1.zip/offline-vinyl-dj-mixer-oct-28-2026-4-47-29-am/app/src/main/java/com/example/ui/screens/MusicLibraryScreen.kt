package com.example.ui.screens

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.ui.res.painterResource
import com.example.R
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.audio.DeviceAudioScanner
import com.example.audio.ScannedAudioTrack
import com.example.model.DeckId
import com.example.model.DjSkin
import com.example.ui.theme.CarbonBlack
import com.example.ui.theme.LedGreen
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPink
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale

@Composable
fun MusicLibraryScreen(
  initialTargetDeckId: DeckId,
  currentSkin: DjSkin,
  demoTrackAFile: File?,
  demoTrackBFile: File?,
  savedRecordings: List<File>,
  onLoadToDeck: (DeckId, Uri) -> Unit,
  onClose: () -> Unit
) {
  // Support Hardware & System Back navigation
  BackHandler {
    onClose()
  }

  val context = LocalContext.current
  val coroutineScope = rememberCoroutineScope()

  val deckAColor = Color(currentSkin.deckAColorHex)
  val deckBColor = Color(currentSkin.deckBColorHex)

  // Track target deck: defaults to whichever deck initiated the open
  var activeTargetDeck by remember { mutableStateOf(initialTargetDeckId) }

  // Search & Filtering
  var searchQuery by remember { mutableStateOf("") }
  var selectedTab by remember { mutableStateOf(0) } // 0: ALL SONGS, 1: DOWNLOADS & MUSIC, 2: IMPORTED, 3: DEMO LOOPS, 4: RECORDINGS
  var minSizeFilterMb by remember { mutableStateOf(1) } // Default 1 MB: excludes ringtones & notification chimes
  var hideShortChimes by remember { mutableStateOf(true) }

  // Scanned tracks state
  val deviceTracks = remember { mutableStateListOf<ScannedAudioTrack>() }
  var isScanning by remember { mutableStateOf(false) }

  // Preview Player
  var previewPlayer by remember { mutableStateOf<MediaPlayer?>(null) }
  var currentlyPreviewingTrackId by remember { mutableStateOf<String?>(null) }

  fun stopPreview() {
    try {
      previewPlayer?.stop()
      previewPlayer?.release()
    } catch (e: Exception) {
      // Ignored
    }
    previewPlayer = null
    currentlyPreviewingTrackId = null
  }

  fun playPreview(track: ScannedAudioTrack) {
    if (currentlyPreviewingTrackId == track.id) {
      stopPreview()
      return
    }

    stopPreview()
    try {
      val mp = MediaPlayer().apply {
        setAudioAttributes(
          AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build()
        )
        if (track.uri.scheme == "content") {
          val pfd = context.contentResolver.openFileDescriptor(track.uri, "r")
          if (pfd != null) {
            setDataSource(pfd.fileDescriptor)
            pfd.close()
          } else {
            setDataSource(context, track.uri)
          }
        } else {
          setDataSource(context, track.uri)
        }
        setOnCompletionListener {
          stopPreview()
        }
        prepare()
        start()
      }
      previewPlayer = mp
      currentlyPreviewingTrackId = track.id
    } catch (e: Exception) {
      stopPreview()
    }
  }

  DisposableEffect(Unit) {
    onDispose {
      stopPreview()
    }
  }

  // Storage permission handling
  val requiredPermission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
    Manifest.permission.READ_MEDIA_AUDIO
  } else {
    Manifest.permission.READ_EXTERNAL_STORAGE
  }

  var hasStoragePermission by remember {
    mutableStateOf(
      ContextCompat.checkSelfPermission(context, requiredPermission) == PackageManager.PERMISSION_GRANTED
    )
  }

  fun triggerScan() {
    isScanning = true
    coroutineScope.launch(Dispatchers.IO) {
      val scanned = DeviceAudioScanner.scanAllAudio(context)
      withContext(Dispatchers.Main) {
        deviceTracks.clear()
        deviceTracks.addAll(scanned)
        isScanning = false
      }
    }
  }

  val permissionLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.RequestPermission()
  ) { isGranted ->
    hasStoragePermission = isGranted
    if (isGranted) {
      triggerScan()
    }
  }

  // System SAF File Picker (imports selected files permanently into app library)
  val systemPickerLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.GetContent()
  ) { uri: Uri? ->
    if (uri != null) {
      coroutineScope.launch(Dispatchers.IO) {
        val importedTrack = DeviceAudioScanner.importPickedAudioToAppStorage(context, uri)
        withContext(Dispatchers.Main) {
          if (importedTrack != null) {
            val exists = deviceTracks.indexOfFirst { it.id == importedTrack.id }
            if (exists >= 0) {
              deviceTracks[exists] = importedTrack
            } else {
              deviceTracks.add(0, importedTrack)
            }
            // Auto-load to the currently selected target deck!
            stopPreview()
            onLoadToDeck(activeTargetDeck, importedTrack.uri)
          } else {
            // Direct load if copy failed
            stopPreview()
            onLoadToDeck(activeTargetDeck, uri)
          }
        }
      }
    }
  }

  // Auto-scan on launch
  LaunchedEffect(Unit) {
    triggerScan()
    if (!hasStoragePermission) {
      permissionLauncher.launch(requiredPermission)
    }
  }

  // Built-in EDM demo loops
  val demoTracks = remember(demoTrackAFile, demoTrackBFile) {
    val list = mutableListOf<ScannedAudioTrack>()
    if (demoTrackAFile != null && demoTrackAFile.exists()) {
      list.add(
        ScannedAudioTrack(
          id = "demo_a",
          title = "Midnight Rush [Demo Deck A]",
          artist = "DJ Cyberpulse • 128 BPM Peak Electro",
          durationMs = 30720,
          bpm = 125.0,
          uri = Uri.fromFile(demoTrackAFile),
          folderName = "Built-in EDM",
          fileExtension = "WAV",
          isBuiltIn = true
        )
      )
    }
    if (demoTrackBFile != null && demoTrackBFile.exists()) {
      list.add(
        ScannedAudioTrack(
          id = "demo_b",
          title = "Neon Cyberbeat [Demo Deck B]",
          artist = "Groove Architect • Synthwave Anthem",
          durationMs = 30720,
          bpm = 125.0,
          uri = Uri.fromFile(demoTrackBFile),
          folderName = "Built-in EDM",
          fileExtension = "WAV",
          isBuiltIn = true
        )
      )
    }
    list
  }

  // Recorded live mixes
  val recordingTracks = remember(savedRecordings) {
    savedRecordings.map { file ->
      ScannedAudioTrack(
        id = file.name,
        title = file.nameWithoutExtension,
        artist = "Live Mix Recording • ${file.length() / 1024} KB",
        durationMs = 30000,
        bpm = 125.0,
        uri = Uri.fromFile(file),
        filePath = file.absolutePath,
        folderName = "Recordings",
        fileExtension = "WAV",
        isRecording = true
      )
    }
  }

  // Filtered tracks based on selected tab and search query
  val tabFilteredTracks = when (selectedTab) {
    0 -> {
      // All tracks (device + demo + recordings)
      val all = mutableListOf<ScannedAudioTrack>()
      all.addAll(deviceTracks)
      all.addAll(demoTracks)
      all.addAll(recordingTracks)
      all
    }
    1 -> {
      // Storage folders (Music, Downloads, SD card)
      deviceTracks.filter { !it.isImported }
    }
    2 -> {
      // Imported songs
      deviceTracks.filter { it.isImported }
    }
    3 -> demoTracks
    else -> recordingTracks
  }

  val minBytes = (minSizeFilterMb * 1024L * 1024L)

  val sizeAndDurationFilteredTracks = tabFilteredTracks.filter { track ->
    if (track.isBuiltIn || track.isRecording) {
      true
    } else {
      val passesSize = minSizeFilterMb <= 0 || track.sizeBytes >= minBytes
      val passesDuration = !hideShortChimes || track.durationMs >= 20000
      passesSize && passesDuration
    }
  }

  val finalTracks = sizeAndDurationFilteredTracks.filter { track ->
    if (searchQuery.isBlank()) true
    else {
      val q = searchQuery.trim()
      track.title.contains(q, ignoreCase = true) ||
          track.artist.contains(q, ignoreCase = true) ||
          track.folderName.contains(q, ignoreCase = true) ||
          track.fileExtension.contains(q, ignoreCase = true)
    }
  }

  val activeColor = if (activeTargetDeck == DeckId.DECK_A) deckAColor else deckBColor

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(CarbonBlack)
      .windowInsetsPadding(WindowInsets.safeDrawing)
      .testTag("music_library_screen")
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
      // 1. TOP APP BAR
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(10.dp))
          .background(Color(0xFF10131A))
          .border(1.dp, Color(0xFF222938), RoundedCornerShape(10.dp))
          .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          // Back to DJ Console Button
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(8.dp))
              .background(Color(0xFF1A1F2C))
              .border(1.dp, Color(0xFF384358), RoundedCornerShape(8.dp))
              .clickable {
                stopPreview()
                onClose()
              }
              .padding(horizontal = 10.dp, vertical = 6.dp),
            contentAlignment = Alignment.Center
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "Back",
                tint = TextWhite,
                modifier = Modifier.size(16.dp)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "BACK TO CONSOLE",
                color = TextWhite,
                fontSize = 10.sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace
              )
            }
          }

          Spacer(modifier = Modifier.width(10.dp))

          Image(
            painter = painterResource(R.drawable.ic_neonova_logo),
            contentDescription = "Neonova Logo",
            modifier = Modifier
              .size(24.dp)
              .clip(RoundedCornerShape(6.dp))
              .border(1.dp, NeonCyan, RoundedCornerShape(6.dp))
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "NEONOVA TUNES DJ",
            color = NeonCyan,
            fontSize = 11.sp,
            fontWeight = FontWeight.Black,
            fontFamily = FontFamily.Monospace
          )
        }

        // Center: Target Deck Selector Segment
        Row(
          modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF0C0E14))
            .border(1.dp, Color(0xFF222836), RoundedCornerShape(8.dp))
            .padding(2.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          // Deck A pill
          val isASelected = activeTargetDeck == DeckId.DECK_A
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(6.dp))
              .background(if (isASelected) deckAColor else Color.Transparent)
              .clickable { activeTargetDeck = DeckId.DECK_A }
              .padding(horizontal = 12.dp, vertical = 5.dp),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = "◄ TARGET: DECK A (LEFT)",
              color = if (isASelected) CarbonBlack else deckAColor,
              fontSize = 10.sp,
              fontWeight = FontWeight.Black,
              fontFamily = FontFamily.Monospace
            )
          }

          Spacer(modifier = Modifier.width(4.dp))

          // Deck B pill
          val isBSelected = activeTargetDeck == DeckId.DECK_B
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(6.dp))
              .background(if (isBSelected) deckBColor else Color.Transparent)
              .clickable { activeTargetDeck = DeckId.DECK_B }
              .padding(horizontal = 12.dp, vertical = 5.dp),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = "TARGET: DECK B (RIGHT) ►",
              color = if (isBSelected) CarbonBlack else deckBColor,
              fontSize = 10.sp,
              fontWeight = FontWeight.Black,
              fontFamily = FontFamily.Monospace
            )
          }
        }

        // Right side: Rescan button & File Manager Import button
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          // Rescan storage button
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(8.dp))
              .background(Color(0xFF1A1F2C))
              .border(1.dp, Color(0xFF384358), RoundedCornerShape(8.dp))
              .clickable(enabled = !isScanning) { triggerScan() }
              .padding(horizontal = 8.dp, vertical = 6.dp),
            contentAlignment = Alignment.Center
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              if (isScanning) {
                CircularProgressIndicator(
                  modifier = Modifier.size(13.dp),
                  color = LedGreen,
                  strokeWidth = 2.dp
                )
              } else {
                Icon(
                  imageVector = Icons.Default.Refresh,
                  contentDescription = "Rescan",
                  tint = LedGreen,
                  modifier = Modifier.size(14.dp)
                )
              }
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = if (isScanning) "SCANNING..." else "RESCAN",
                color = LedGreen,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
              )
            }
          }

          // Pick from device folder
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(8.dp))
              .background(
                Brush.horizontalGradient(
                  listOf(Color(0xFF1E3A8A), Color(0xFF2563EB))
                )
              )
              .border(1.dp, Color(0xFF60A5FA), RoundedCornerShape(8.dp))
              .clickable {
                systemPickerLauncher.launch("audio/*")
              }
              .padding(horizontal = 10.dp, vertical = 6.dp),
            contentAlignment = Alignment.Center
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Default.FolderOpen,
                contentDescription = "Pick File",
                tint = TextWhite,
                modifier = Modifier.size(15.dp)
              )
              Spacer(modifier = Modifier.width(5.dp))
              Text(
                text = "+ IMPORT FROM FILES",
                color = TextWhite,
                fontSize = 10.sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(6.dp))

      // 2. PERMISSION BANNER / STATUS CARD
      if (!hasStoragePermission) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF261E14))
            .border(1.2.dp, Color(0xFFFFB300), RoundedCornerShape(8.dp))
            .padding(horizontal = 12.dp, vertical = 6.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(
            modifier = Modifier.weight(1f),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(
              imageVector = Icons.Default.Security,
              contentDescription = "Permission Alert",
              tint = Color(0xFFFFB300),
              modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column {
              Text(
                text = "STORAGE PERMISSION REQUIRED FOR AUTOMATIC SCAN",
                color = Color(0xFFFFB300),
                fontSize = 10.sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace
              )
              Text(
                text = "Grant permission so the app can list all songs in your Music and Download folders, or use '+ IMPORT FROM FILES' directly.",
                color = TextWhite,
                fontSize = 8.5.sp,
                fontFamily = FontFamily.Monospace
              )
            }
          }

          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(6.dp))
              .background(Color(0xFFFFB300))
              .clickable { permissionLauncher.launch(requiredPermission) }
              .padding(horizontal = 10.dp, vertical = 6.dp)
          ) {
            Text(
              text = "GRANT ACCESS",
              color = CarbonBlack,
              fontSize = 9.5.sp,
              fontWeight = FontWeight.Black,
              fontFamily = FontFamily.Monospace
            )
          }
        }

        Spacer(modifier = Modifier.height(6.dp))
      }

      // 3. SEARCH BAR & CATEGORY TABS
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        // Search Input Box
        Box(
          modifier = Modifier
            .weight(1f)
            .height(36.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF141822))
            .border(1.dp, Color(0xFF262F42), RoundedCornerShape(8.dp))
            .padding(horizontal = 10.dp),
          contentAlignment = Alignment.CenterStart
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(
              imageVector = Icons.Default.Search,
              contentDescription = "Search",
              tint = TextMuted,
              modifier = Modifier.size(15.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            androidx.compose.foundation.text.BasicTextField(
              value = searchQuery,
              onValueChange = { searchQuery = it },
              textStyle = androidx.compose.ui.text.TextStyle(
                color = TextWhite,
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace
              ),
              modifier = Modifier.weight(1f),
              decorationBox = { innerTextField ->
                if (searchQuery.isEmpty()) {
                  Text(
                    text = "Search tracks by title, artist, folder...",
                    color = Color(0xFF5E6B82),
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                  )
                }
                innerTextField()
              }
            )
            if (searchQuery.isNotEmpty()) {
              Icon(
                imageVector = Icons.Default.Clear,
                contentDescription = "Clear",
                tint = TextMuted,
                modifier = Modifier
                  .size(16.dp)
                  .clickable { searchQuery = "" }
              )
            }
          }
        }

        // Category Tabs
        val tabs = listOf(
          "ALL SONGS (${deviceTracks.size + demoTracks.size + recordingTracks.size})",
          "STORAGE FOLDERS (${deviceTracks.count { !it.isImported }})",
          "IMPORTED (${deviceTracks.count { it.isImported }})",
          "DEMO TRACKS (${demoTracks.size})",
          "RECORDED MIXES (${recordingTracks.size})"
        )

        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
          tabs.forEachIndexed { idx, label ->
            val isSelected = selectedTab == idx
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(6.dp))
                .background(if (isSelected) activeColor.copy(alpha = 0.22f) else Color(0xFF141722))
                .border(
                  width = 1.dp,
                  color = if (isSelected) activeColor else Color(0xFF262C3D),
                  shape = RoundedCornerShape(6.dp)
                )
                .clickable { selectedTab = idx }
                .padding(horizontal = 8.dp, vertical = 8.dp)
            ) {
              Text(
                text = label,
                color = if (isSelected) activeColor else TextMuted,
                fontSize = 9.sp,
                fontWeight = if (isSelected) FontWeight.Black else FontWeight.Bold,
                fontFamily = FontFamily.Monospace
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(4.dp))

      // 3.5. NOTIFICATION SOUND & SIZE FILTER CHIPS
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(6.dp))
          .background(Color(0xFF0F121A))
          .border(1.dp, Color(0xFF1E2536), RoundedCornerShape(6.dp))
          .padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
          Text(
            text = "SIZE FILTER:",
            color = Color(0xFF7A889B),
            fontSize = 8.5.sp,
            fontWeight = FontWeight.Black,
            fontFamily = FontFamily.Monospace
          )

          val sizeOptions = listOf(
            Pair(1, "> 1 MB (Skip Chimes)"),
            Pair(3, "> 3 MB"),
            Pair(5, "> 5 MB"),
            Pair(0, "All Audio (0 MB+)")
          )

          sizeOptions.forEach { (mb, label) ->
            val isSelected = minSizeFilterMb == mb
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(4.dp))
                .background(if (isSelected) activeColor.copy(alpha = 0.25f) else Color(0xFF171B26))
                .border(1.dp, if (isSelected) activeColor else Color(0xFF2A3347), RoundedCornerShape(4.dp))
                .clickable { minSizeFilterMb = mb }
                .padding(horizontal = 6.dp, vertical = 3.dp),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = label,
                color = if (isSelected) activeColor else TextWhite,
                fontSize = 8.sp,
                fontWeight = if (isSelected) FontWeight.Black else FontWeight.Normal,
                fontFamily = FontFamily.Monospace
              )
            }
          }
        }

        // Toggle short audio (<20s)
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(if (hideShortChimes) LedGreen.copy(alpha = 0.2f) else Color(0xFF171B26))
            .border(1.dp, if (hideShortChimes) LedGreen else Color(0xFF2A3347), RoundedCornerShape(4.dp))
            .clickable { hideShortChimes = !hideShortChimes }
            .padding(horizontal = 6.dp, vertical = 3.dp),
          contentAlignment = Alignment.Center
        ) {
          Text(
            text = if (hideShortChimes) "✓ HIDE NOTIFS (<20s): ON" else "HIDE NOTIFS: OFF",
            color = if (hideShortChimes) LedGreen else TextMuted,
            fontSize = 8.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
          )
        }
      }

      Spacer(modifier = Modifier.height(6.dp))

      // 4. TRACK LIST / EMPTY STATE
      if (finalTracks.isEmpty()) {
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .weight(1f)
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF0D1017))
            .border(1.dp, Color(0xFF1B2230), RoundedCornerShape(8.dp)),
          contentAlignment = Alignment.Center
        ) {
          Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(20.dp)
          ) {
            Icon(
              imageVector = Icons.Default.MusicNote,
              contentDescription = "No Tracks",
              tint = Color(0xFF3B4861),
              modifier = Modifier.size(44.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
              text = if (isScanning) "Scanning phone storage for music files..."
              else if (!hasStoragePermission) "No tracks found yet. Tap 'GRANT ACCESS' above to auto-scan your storage."
              else "No audio tracks matched your filter.",
              color = TextWhite,
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold,
              fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = "You can tap '+ IMPORT FROM FILES' at top right to pick any song directly from your File Manager.",
              color = TextMuted,
              fontSize = 9.5.sp,
              fontFamily = FontFamily.Monospace
            )
          }
        }
      } else {
        LazyColumn(
          modifier = Modifier
            .fillMaxWidth()
            .weight(1f),
          verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
          items(finalTracks, key = { it.id }) { track ->
            val isPreviewingThis = currentlyPreviewingTrackId == track.id
            TrackCardItem(
              track = track,
              deckAColor = deckAColor,
              deckBColor = deckBColor,
              isPreviewing = isPreviewingThis,
              onPreviewToggle = { playPreview(track) },
              onLoadDeckA = {
                stopPreview()
                onLoadToDeck(DeckId.DECK_A, track.uri)
                onClose()
              },
              onLoadDeckB = {
                stopPreview()
                onLoadToDeck(DeckId.DECK_B, track.uri)
                onClose()
              }
            )
          }
        }
      }
    }
  }
}

@Composable
private fun TrackCardItem(
  track: ScannedAudioTrack,
  deckAColor: Color,
  deckBColor: Color,
  isPreviewing: Boolean,
  onPreviewToggle: () -> Unit,
  onLoadDeckA: () -> Unit,
  onLoadDeckB: () -> Unit
) {
  val totalSec = track.durationMs / 1000
  val durationStr = String.format(Locale.US, "%02d:%02d", totalSec / 60, totalSec % 60)

  Row(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(8.dp))
      .background(if (isPreviewing) Color(0xFF1B2338) else Color(0xFF111520))
      .border(
        width = 1.dp,
        color = if (isPreviewing) deckAColor else Color(0xFF222938),
        shape = RoundedCornerShape(8.dp)
      )
      .padding(horizontal = 10.dp, vertical = 6.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    // Left: Audio format badge + Title/Artist/Details
    Row(
      modifier = Modifier.weight(1f),
      verticalAlignment = Alignment.CenterVertically
    ) {
      // Audio Format Disc Icon / Badge
      Box(
        modifier = Modifier
          .size(36.dp)
          .clip(CircleShape)
          .background(Color(0xFF1C2230))
          .border(1.dp, Color(0xFF384358), CircleShape),
        contentAlignment = Alignment.Center
      ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Icon(
            imageVector = Icons.Default.MusicNote,
            contentDescription = "Format",
            tint = if (track.isBuiltIn) LedGreen else TextWhite,
            modifier = Modifier.size(14.dp)
          )
          Text(
            text = track.fileExtension,
            color = if (track.isBuiltIn) LedGreen else TextMuted,
            fontSize = 7.5.sp,
            fontWeight = FontWeight.Black,
            fontFamily = FontFamily.Monospace
          )
        }
      }

      Spacer(modifier = Modifier.width(10.dp))

      Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            text = track.title,
            color = TextWhite,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
          )
          if (track.isImported) {
            Spacer(modifier = Modifier.width(6.dp))
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(3.dp))
                .background(Color(0xFF1E3A8A))
                .padding(horizontal = 4.dp, vertical = 1.dp)
            ) {
              Text(
                text = "SAVED",
                color = Color(0xFF93C5FD),
                fontSize = 7.5.sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(2.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            text = track.artist,
            color = TextMuted,
            fontSize = 9.5.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
          )
          Text(
            text = " • $durationStr • ${track.folderName}",
            color = Color(0xFF6B7280),
            fontSize = 8.5.sp,
            fontFamily = FontFamily.Monospace
          )
          if (track.fileSizeFormatted.isNotEmpty()) {
            Text(
              text = " (${track.fileSizeFormatted})",
              color = Color(0xFF4B5563),
              fontSize = 8.sp,
              fontFamily = FontFamily.Monospace
            )
          }
        }
      }
    }

    // Right Action Buttons: [PREVIEW] + [LOAD DECK A] + [LOAD DECK B]
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
      // Audio Preview Button
      Box(
        modifier = Modifier
          .clip(RoundedCornerShape(6.dp))
          .background(if (isPreviewing) LedGreen else Color(0xFF1E2433))
          .border(1.dp, if (isPreviewing) LedGreen else Color(0xFF384358), RoundedCornerShape(6.dp))
          .clickable { onPreviewToggle() }
          .padding(horizontal = 8.dp, vertical = 5.dp),
        contentAlignment = Alignment.Center
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = if (isPreviewing) Icons.Default.Stop else Icons.Default.PlayArrow,
            contentDescription = "Preview",
            tint = if (isPreviewing) CarbonBlack else TextWhite,
            modifier = Modifier.size(13.dp)
          )
          Spacer(modifier = Modifier.width(3.dp))
          Text(
            text = if (isPreviewing) "STOP" else "PREVIEW",
            color = if (isPreviewing) CarbonBlack else TextWhite,
            fontSize = 8.5.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
          )
        }
      }

      // LOAD DECK A
      Box(
        modifier = Modifier
          .clip(RoundedCornerShape(6.dp))
          .background(deckAColor)
          .clickable { onLoadDeckA() }
          .padding(horizontal = 10.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center
      ) {
        Text(
          text = "LOAD DECK A",
          color = CarbonBlack,
          fontSize = 9.sp,
          fontWeight = FontWeight.Black,
          fontFamily = FontFamily.Monospace
        )
      }

      // LOAD DECK B
      Box(
        modifier = Modifier
          .clip(RoundedCornerShape(6.dp))
          .background(deckBColor)
          .clickable { onLoadDeckB() }
          .padding(horizontal = 10.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center
      ) {
        Text(
          text = "LOAD DECK B",
          color = CarbonBlack,
          fontSize = 9.sp,
          fontWeight = FontWeight.Black,
          fontFamily = FontFamily.Monospace
        )
      }
    }
  }
}
