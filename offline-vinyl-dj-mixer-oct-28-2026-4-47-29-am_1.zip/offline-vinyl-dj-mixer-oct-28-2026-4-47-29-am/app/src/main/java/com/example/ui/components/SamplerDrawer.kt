package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.WavGenerator
import com.example.ui.theme.CarbonBlack
import com.example.ui.theme.LedGreen
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPink
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite

@Composable
fun SamplerDrawer(
  activePadIndex: Int?,
  onTriggerSample: (WavGenerator.SampleType, Int) -> Unit,
  onClose: () -> Unit,
  modifier: Modifier = Modifier
) {
  val pads = listOf(
    Triple(WavGenerator.SampleType.AIRHORN, "AIRHORN", Color(0xFFFFD600)),
    Triple(WavGenerator.SampleType.KICK, "808 KICK", Color(0xFFFF2A6D)),
    Triple(WavGenerator.SampleType.SNARE, "SNARE", Color(0xFF00E5FF)),
    Triple(WavGenerator.SampleType.HIHAT, "HI-HAT", Color(0xFF00E676)),
    Triple(WavGenerator.SampleType.SCRATCH, "SCRATCH", Color(0xFFFF6D00)),
    Triple(WavGenerator.SampleType.LASER, "LASER", Color(0xFFE040FB)),
    Triple(WavGenerator.SampleType.SUB_DROP, "SUB DROP", Color(0xFF2979FF)),
    Triple(WavGenerator.SampleType.SIREN, "SIREN", Color(0xFFFF1744))
  )

  Box(
    modifier = modifier
      .fillMaxWidth(0.72f)
      .height(130.dp)
      .clip(RoundedCornerShape(12.dp))
      .background(Color(0xF50D1017))
      .border(1.5.dp, Color(0xFF2E364A), RoundedCornerShape(12.dp))
      .padding(8.dp)
  ) {
    Column(
      modifier = Modifier.fillMaxSize(),
      verticalArrangement = Arrangement.SpaceBetween
    ) {
      // Header
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Default.VolumeUp,
            contentDescription = "Sampler",
            tint = NeonCyan,
            modifier = Modifier.size(14.dp)
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = "TACTILE DJ SAMPLER • 8 LOW-LATENCY PADS",
            color = TextWhite,
            fontSize = 9.sp,
            fontWeight = FontWeight.Black,
            fontFamily = FontFamily.Monospace
          )
        }

        Box(
          modifier = Modifier
            .size(22.dp)
            .clip(CircleShape)
            .background(Color(0xFF1E2330))
            .clickable { onClose() },
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Default.Close,
            contentDescription = "Close",
            tint = TextWhite,
            modifier = Modifier.size(13.dp)
          )
        }
      }

      Spacer(modifier = Modifier.height(4.dp))

      // 4x2 Pad Grid
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .weight(1f),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        for (i in 0 until 4) {
          val (sampleType, name, color) = pads[i]
          SamplerPad(
            index = i,
            label = name,
            accentColor = color,
            isTriggered = activePadIndex == i,
            onClick = { onTriggerSample(sampleType, i) },
            modifier = Modifier.weight(1f)
          )
        }
      }

      Spacer(modifier = Modifier.height(4.dp))

      Row(
        modifier = Modifier
          .fillMaxWidth()
          .weight(1f),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        for (i in 4 until 8) {
          val (sampleType, name, color) = pads[i]
          SamplerPad(
            index = i,
            label = name,
            accentColor = color,
            isTriggered = activePadIndex == i,
            onClick = { onTriggerSample(sampleType, i) },
            modifier = Modifier.weight(1f)
          )
        }
      }
    }
  }
}

@Composable
private fun SamplerPad(
  index: Int,
  label: String,
  accentColor: Color,
  isTriggered: Boolean,
  onClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  Box(
    modifier = modifier
      .fillMaxSize()
      .clip(RoundedCornerShape(6.dp))
      .background(
        if (isTriggered) Brush.radialGradient(
          colors = listOf(accentColor, accentColor.copy(alpha = 0.5f), Color(0xFF131722))
        )
        else androidx.compose.ui.graphics.SolidColor(Color(0xFF171B26))
      )
      .border(
        width = if (isTriggered) 2.dp else 1.dp,
        color = if (isTriggered) accentColor else Color(0xFF2C3345),
        shape = RoundedCornerShape(6.dp)
      )
      .clickable { onClick() }
      .testTag("sampler_pad_$index"),
    contentAlignment = Alignment.Center
  ) {
    Text(
      text = label,
      color = if (isTriggered) CarbonBlack else TextWhite,
      fontSize = 9.sp,
      fontWeight = FontWeight.Black,
      fontFamily = FontFamily.Monospace
    )
  }
}
