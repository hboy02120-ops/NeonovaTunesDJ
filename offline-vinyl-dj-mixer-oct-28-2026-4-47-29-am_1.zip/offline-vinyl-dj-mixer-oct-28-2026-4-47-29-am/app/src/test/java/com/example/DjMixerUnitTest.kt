package com.example

import com.example.audio.WavGenerator
import com.example.model.CrossfaderCurve
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

class DjMixerUnitTest {

  @Test
  fun testEqualPowerCrossfaderCenter() {
    // At center crossfader (0.5), equal-power gains should be cos(pi/4) = sin(pi/4) ~ 0.7071
    val x = 0.5f
    val angle = x * (PI / 2.0)
    val gainA = cos(angle).toFloat()
    val gainB = sin(angle).toFloat()

    assertEquals(0.7071f, gainA, 0.01f)
    assertEquals(0.7071f, gainB, 0.01f)

    // Total power = gainA^2 + gainB^2 = 1.0 (constant acoustic power)
    val totalPower = gainA * gainA + gainB * gainB
    assertEquals(1.0f, totalPower, 0.01f)
  }

  @Test
  fun testEqualPowerCrossfaderExtremes() {
    // Extreme Left (0.0): Deck A full (1.0), Deck B silent (0.0)
    val angleA = 0.0 * (PI / 2.0)
    assertEquals(1.0f, cos(angleA).toFloat(), 0.001f)
    assertEquals(0.0f, sin(angleA).toFloat(), 0.001f)

    // Extreme Right (1.0): Deck A silent (0.0), Deck B full (1.0)
    val angleB = 1.0 * (PI / 2.0)
    assertEquals(0.0f, cos(angleB).toFloat(), 0.001f)
    assertEquals(1.0f, sin(angleB).toFloat(), 0.001f)
  }

  @Test
  fun testWavHeaderFormat() {
    val tempFile = File.createTempFile("test_audio", ".wav")
    tempFile.deleteOnExit()

    val dummyAudioBytes = 44100L * 2 * 2 // 1 second 16-bit stereo
    FileOutputStream(tempFile).use { fos ->
      WavGenerator.writeWavHeader(fos, dummyAudioBytes, 44100, 2)
    }

    assertTrue(tempFile.exists())
    assertEquals(44L, tempFile.length()) // 44-byte standard RIFF WAVE header
  }

  @Test
  fun testPitchTempoSpeedCalculation() {
    val baseBpm = 125.0
    val pitchPercent = 4.0f // +4%
    val effectiveBpm = baseBpm * (1.0 + pitchPercent / 100.0)
    assertEquals(130.0, effectiveBpm, 0.01)

    val playbackSpeed = 1.0f + pitchPercent / 100f
    assertEquals(1.04f, playbackSpeed, 0.001f)
  }
}
